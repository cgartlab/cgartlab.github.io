/**
 * cloud.js —— 薄客户端云授权（CEP 面板，浏览器侧）
 * 激活码 → /v1/activate → 令牌 → /v1/spec → 注入宿主引擎。
 * 全量规格不再随包分发；所有鉴权请求都带 X-Machine，服务端会校验机器与许可状态。
 *
 * 0.3.0 变化：
 *   - 激活码先本地校验（格式 + 校验位），格式错不联网
 *   - 有令牌时先 /v1/refresh（同时拿到套餐/座位/试用剩余），再取规格
 *   - 试用到期由服务端判定（TRIAL_EXPIRED），客户端不再自己算
 *   - 停用本机会调用 /v1/deactivate 释放座位
 *   - 错误码统一映射为中文提示（FuiCloud.message）
 */
(function (root) {
    "use strict";

    var API_BASE = "https://api.cgartlab.com";
    var TOKEN_KEY = "fui_cloud_token";
    // 客服入口（面板提示里用；换机/丢码/退款都引导到这里）
    var SUPPORT = "淘宝旺旺 CGArtLab 或邮箱 support@cgartlab.com";
    // 客户端版本（docs.test 会校验它与 VERSION 一致）
    var CLIENT_VERSION = "0.3.0";
    var SITE_BASE = "https://cgartlab.com";
    var MANIFEST_URL = SITE_BASE + "/downloads/CGArtLab-FUI-Data.json";
    var DOWNLOAD_URL = SITE_BASE + "/downloads/CGArtLab-FUI-Data-win.zip";

    var ALPHABET = "0123456789ABCDEFGHJKMNPQRSTVWXYZ";
    var PREFIX = "FUIF";
    var BODY_LEN = 20;

    function ci() { return (typeof CSInterface !== "undefined") ? new CSInterface() : null; }
    function evalHost(script, cb) { var c = ci(); if (!c) { cb(""); return; } c.evalScript(script, cb); }

    /* ---------------- 激活码：本地校验（与服务端 keygen.js 同规则） ---------------- */

    function charValue(ch) { var i = ALPHABET.indexOf(ch); return i < 0 ? -1 : i; }

    function normalizeKey(raw) {
        var s = String(raw || "").toUpperCase().replace(/[^0-9A-Z]/g, "");
        if (s.indexOf(PREFIX) === 0) { s = s.slice(PREFIX.length); }
        return s.replace(/O/g, "0").replace(/[IL]/g, "1");
    }

    function checksumChar(payload) {
        var h = 0;
        for (var i = 0; i < payload.length; i++) {
            var v = charValue(payload.charAt(i));
            if (v < 0) { return null; }
            h = (((h << 5) - h) + v * (i + 7)) & 0x7fffffff;
        }
        return ALPHABET.charAt(h % 32);
    }

    function displayOf(body) {
        return PREFIX + "-" + body.slice(0, 5) + "-" + body.slice(5, 10) + "-" +
            body.slice(10, 15) + "-" + body.slice(15, 20);
    }

    function validateKey(raw) {
        var body = normalizeKey(raw);
        if (body.length !== BODY_LEN) { return { ok: false, reason: "BAD_FORMAT" }; }
        for (var i = 0; i < body.length; i++) {
            if (charValue(body.charAt(i)) < 0) { return { ok: false, reason: "BAD_FORMAT" }; }
        }
        if (checksumChar(body.slice(0, BODY_LEN - 1)) !== body.charAt(BODY_LEN - 1)) {
            return { ok: false, reason: "BAD_FORMAT" };
        }
        return { ok: true, key: PREFIX + body, display: displayOf(body) };
    }

    /* ---------------- 网络 ---------------- */

    function xhr(method, path, body, token, machine, cb) {
        try {
            var x = new XMLHttpRequest();
            x.open(method, API_BASE + path, true);
            x.setRequestHeader("content-type", "application/json");
            if (token) { x.setRequestHeader("authorization", "Bearer " + token); }
            if (machine) { x.setRequestHeader("x-machine", machine); }
            x.timeout = 20000;
            x.onreadystatechange = function () {
                if (x.readyState === 4) {
                    var j = null;
                    try { j = JSON.parse(x.responseText); } catch (e) { j = null; }
                    cb(x.status, j);
                }
            };
            x.ontimeout = function () { cb(0, null); };
            x.onerror = function () { cb(0, null); };
            x.send(body ? JSON.stringify(body) : null);
        } catch (e) { cb(0, null); }
    }

    /* ---------------- 机器码与令牌 ---------------- */

    function getMachine(cb) {
        evalHost("fuiLicenseFingerprint()", function (res) {
            var o = null;
            try { o = JSON.parse(res); } catch (e) { o = null; }
            cb(o && o.ok ? o : null);
        });
    }

    function readToken() { try { return localStorage.getItem(TOKEN_KEY) || ""; } catch (e) { return ""; } }
    function storeToken(t) { try { if (t) { localStorage.setItem(TOKEN_KEY, t); } } catch (e) { } }
    function clearToken() { try { localStorage.removeItem(TOKEN_KEY); } catch (e) { } }

    function setStatus(obj) {
        root.FUI_CLOUD = obj;
        try {
            if (root.document && root.document.dispatchEvent) {
                root.document.dispatchEvent(new Event("fui-cloud-updated"));
            }
        } catch (e) { }
    }

    /* ---------------- 版本检查（新版本提示） ---------------- */

    function parseVer(v) {
        var p = String(v || "").replace(/^v/i, "").split(".");
        var out = [];
        for (var i = 0; i < 3; i++) { out.push(parseInt(p[i], 10) || 0); }
        return out;
    }

    function isNewer(a, b) {
        var A = parseVer(a), B = parseVer(b);
        for (var i = 0; i < 3; i++) {
            if (A[i] > B[i]) { return true; }
            if (A[i] < B[i]) { return false; }
        }
        return false;
    }

    function fetchLatestManifest(cb) {
        try {
            var x = new XMLHttpRequest();
            x.open("GET", MANIFEST_URL, true);
            x.timeout = 8000;
            x.onreadystatechange = function () {
                if (x.readyState !== 4) { return; }
                if (x.status !== 200) { cb(null); return; }
                var j = null;
                try { j = JSON.parse(x.responseText); } catch (e) { j = null; }
                cb(j);
            };
            x.ontimeout = function () { cb(null); };
            x.onerror = function () { cb(null); };
            x.send(null);
        } catch (e) { cb(null); }
    }

    function checkUpdate() {
        fetchLatestManifest(function (m) {
            if (!m || !m.version) { return; }
            var newer = isNewer(m.version, CLIENT_VERSION);
            var s = root.FUI_CLOUD || {};
            s.latestVersion = m.version;
            s.updateAvailable = newer;
            s.clientVersion = CLIENT_VERSION;
            s.downloadUrl = m.file ? (SITE_BASE + m.file) : DOWNLOAD_URL;
            if (newer) { setStatus(s); }
        });
    }

    /* ---------------- 业务 ---------------- */

    function errorMessage(code) {
        var map = {
            BAD_FORMAT: "激活码格式不对，请从淘宝消息里完整复制（FUIF-XXXXX-XXXXX-XXXXX-XXXXX）",
            KEY_REQUIRED: "请先粘贴激活码",
            INVALID_KEY: "激活码不存在或输入有误，请核对后重试",
            KEY_DISABLED: "该激活码已停用（退款/违规），请联系客服（" + SUPPORT + "）",
            LICENSE_DISABLED: "该授权已停用，请联系客服（" + SUPPORT + "）",
            DEVICE_LIMIT: "这个激活码已绑定 2 台设备；换机请把机器码发给客服解绑（" + SUPPORT + "）",
            LICENSE_EXPIRED: "授权已到期（试用结束/服务到期），请输入激活码或续费（" + SUPPORT + "）",
            TRIAL_EXPIRED: "试用已结束，输入激活码即可继续使用全部 34 类",
            TOO_MANY_ATTEMPTS: "激活码连续输错，请 10 分钟后再试；多次失败请联系客服（" + SUPPORT + "）",
            RATE_LIMITED: "操作太频繁，请稍后再试",
            MACHINE_REQUIRED: "读不到机器码：请到 AE 首选项 > 脚本与表达式，勾选「允许脚本写入文件和访问网络」后重启 AE",
            NO_MACHINE: "读不到机器码：请到 AE 首选项 > 脚本与表达式，勾选「允许脚本写入文件和访问网络」后重启 AE",
            TOKEN_EXPIRED: "登录已过期，请重新输入激活码",
            NO_TOKEN: "尚未激活，请输入激活码",
            NETWORK: "联网失败：请确认能访问 api.cgartlab.com（公司代理/防火墙可能拦截）",
            SERVER_ERROR: "服务端异常，请稍后重试",
            TIMEOUT: "联网超时，请稍后重试"
        };
        return map[code] || ("激活失败：" + (code || "未知错误"));
    }

    function injectSpec(spec, meta, cb) {
        var specStr = JSON.stringify(spec);
        var plan = meta.plan || "trial";
        var hostCall = "fuiSetDatatypeSpec(" + JSON.stringify(specStr) + "," + JSON.stringify(plan) + ")";
        evalHost(hostCall, function (r) {
            var okHost = false;
            try { okHost = JSON.parse(r).ok === true; } catch (e) { okHost = false; }
            var n = 0, k, t = (spec && spec.types) ? spec.types : {};
            for (k in t) { if (t.hasOwnProperty(k)) { n++; } }
            setStatus({
                licensed: true, plan: plan, hostInjected: okHost, types: n,
                machineCode: meta.machineCode || "", weakMachine: !!meta.weakMachine,
                trialDaysLeft: meta.trialDaysLeft || 0,
                seatsUsed: meta.seatsUsed || 0, seatsTotal: meta.seatsTotal || 0,
                watermark: meta.watermark || ""
            });
            cb({ ok: true, plan: plan, hostInjected: okHost, types: n, trialDaysLeft: meta.trialDaysLeft || 0 });
        });
    }

    function fetchSpec(token, meta, cb) {
        xhr("GET", "/v1/spec", null, token, meta.machineCode, function (st, j) {
            if (st === 200 && j && j.ok) { injectSpec(j.spec, meta, cb); return; }
            if (st === 401 || st === 403) { clearToken(); }
            cb({ ok: false, error: (j && j.error) || (st === 0 ? "NETWORK" : "HTTP_" + st) });
        });
    }

    function activateTrial(machineInfo, cb) {
        var meta = { machineCode: machineInfo.code, weakMachine: !!machineInfo.weak };
        xhr("POST", "/v1/activate", { trial: true, machine: machineInfo.code }, null, machineInfo.code, function (st, j) {
            if (st === 0) { cb({ ok: false, error: "NETWORK" }); return; }
            if (st === 200 && j && j.ok) {
                storeToken(j.token);
                meta.plan = j.plan || "trial";
                meta.trialDaysLeft = j.trial_days_left || 0;
                meta.seatsUsed = j.seats_used || 0;
                meta.seatsTotal = j.seats_total || 0;
                meta.watermark = j.watermark || "";
                fetchSpec(j.token, meta, cb);
                return;
            }
            var code = (j && j.error) || ("HTTP_" + st);
            if (code === "TRIAL_EXPIRED") {
                setStatus({
                    licensed: false, trialExpired: true, reason: "TRIAL_EXPIRED",
                    machineCode: machineInfo.code, weakMachine: !!machineInfo.weak
                });
            }
            cb({ ok: false, error: code });
        });
    }

    /** 买断激活：激活码 → 激活 → 取规格注入 */
    function activate(rawKey, done) {
        var v = validateKey(rawKey);
        if (!v.ok) { done({ ok: false, error: v.reason || "BAD_FORMAT" }); return; }
        getMachine(function (machineInfo) {
            if (!machineInfo || !machineInfo.code) { done({ ok: false, error: "NO_MACHINE" }); return; }
            var meta = { machineCode: machineInfo.code, weakMachine: !!machineInfo.weak };
            xhr("POST", "/v1/activate", { key: v.key, machine: machineInfo.code }, null, machineInfo.code, function (st, j) {
                if (st === 0) { done({ ok: false, error: "NETWORK" }); return; }
                if (st === 200 && j && j.ok) {
                    storeToken(j.token);
                    meta.plan = j.plan || "buyout";
                    meta.trialDaysLeft = j.trial_days_left || 0;
                    meta.seatsUsed = j.seats_used || 0;
                    meta.seatsTotal = j.seats_total || 0;
                    meta.watermark = j.watermark || "";
                    fetchSpec(j.token, meta, done);
                    return;
                }
                var code = (j && j.error) || (st === 0 ? "NETWORK" : "HTTP_" + st);
                if (code === "INVALID_KEY" || code === "BAD_FORMAT") { /* 保持现有状态，只报错 */ }
                done({ ok: false, error: code });
            });
        });
    }

    /** 面板启动：有令牌先 refresh（拿套餐/座位/试用天数），失败再走试用 */
    function bootstrap(done) {
        // 每次打开面板做一次轻量版本检查（失败静默，不影响授权）
        var finish = function (r) {
            try { checkUpdate(); } catch (eU) { }
            if (done) { done(r); }
        };
        getMachine(function (machineInfo) {
            if (!machineInfo || !machineInfo.code) { finish({ ok: false, error: "NO_MACHINE" }); return; }
            var meta = { machineCode: machineInfo.code, weakMachine: !!machineInfo.weak };
            var token = readToken();
            if (!token) { activateTrial(machineInfo, finish); return; }
            xhr("POST", "/v1/refresh", {}, token, machineInfo.code, function (st, j) {
                if (st === 200 && j && j.ok) {
                    storeToken(j.token);
                    meta.plan = j.plan || "buyout";
                    meta.trialDaysLeft = j.trial_days_left || 0;
                    meta.seatsUsed = j.seats_used || 0;
                    meta.seatsTotal = j.seats_total || 0;
                    meta.watermark = j.watermark || "";
                    fetchSpec(j.token, meta, finish);
                    return;
                }
                if (st === 0) { cbNetwork(machineInfo, finish); return; }
                // 令牌失效/许可停用/换机：清掉令牌，回到试用判定
                clearToken();
                activateTrial(machineInfo, finish);
            });
        });
    }

    function cbNetwork(machineInfo, done) {
        setStatus({
            licensed: false, reason: "NETWORK",
            machineCode: machineInfo.code, weakMachine: !!machineInfo.weak
        });
        done({ ok: false, error: "NETWORK" });
    }

    /** 停用本机：云端释放座位 + 清本地令牌 */
    function deactivate(done) {
        var token = readToken();
        if (!token) { clearToken(); if (done) { done({ ok: true }); } return; }
        getMachine(function (machineInfo) {
            var code = machineInfo && machineInfo.code ? machineInfo.code : "";
            xhr("POST", "/v1/deactivate", {}, token, code, function (st, j) {
                clearToken();
                setStatus({ licensed: false, machineCode: code, machineLabel: "" });
                if (done) { done({ ok: true, remote: st === 200 && !!(j && j.ok) }); }
            });
        });
    }

    function status() { return root.FUI_CLOUD || { licensed: false }; }

    root.FuiCloud = {
        bootstrap: bootstrap,
        activate: activate,
        deactivate: deactivate,
        status: status,
        validateKey: validateKey,
        message: errorMessage,
        checkUpdate: checkUpdate,
        compareVersions: isNewer,
        openDownload: function () {
            try {
                var u = (root.FUI_CLOUD && root.FUI_CLOUD.downloadUrl) || DOWNLOAD_URL;
                if (root.cep && root.cep.util && root.cep.util.openURLInDefaultBrowser) {
                    root.cep.util.openURLInDefaultBrowser(u);
                } else if (root.open) { root.open(u); }
            } catch (e) { }
        },
        activateTrial: function (d) { getMachine(function (m) { if (!m) { if (d) { d({ ok: false, error: "NO_MACHINE" }); } return; } activateTrial(m, d || function () { }); }); }
    };
})(typeof globalThis !== "undefined" ? globalThis :
    (typeof window !== "undefined" ? window : this));
