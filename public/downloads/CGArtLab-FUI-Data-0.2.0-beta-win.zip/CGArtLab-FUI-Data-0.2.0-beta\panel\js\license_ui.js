/**
 * license_ui.js —— 授权状态条 + 激活对话框（自包含，不依赖面板现有 DOM）
 * © 2026 CGArtLab · https://cgartlab.com · CGArtLab FUI Data
 *
 * 面板启动时自动 init；右上角显示状态，点开可看到机器码并粘贴许可证。
 */
(function (root) {
    if (!root.FuiLicense) { return; }
    var doc = root.document;
    if (!doc) { return; }

    var ID = "cgartlab-license-ui";
    var mounted = null;

    var CSS = [
        "#" + ID + "-chip{position:fixed;top:6px;right:8px;z-index:9998;font:11px/1.6 -apple-system,'Segoe UI',sans-serif;",
        "padding:2px 8px;border-radius:9px;cursor:pointer;user-select:none;border:1px solid rgba(255,255,255,.18);",
        "background:rgba(20,22,26,.82);color:#b9c3cf;white-space:nowrap}",
        "#" + ID + "-chip.ok{color:#7ee0a6;border-color:rgba(126,224,166,.45)}",
        "#" + ID + "-chip.trial{color:#ffc258;border-color:rgba(255,194,88,.45)}",
        "#" + ID + "-chip.warn{color:#ff8f7a;border-color:rgba(255,143,122,.45)}",
        "#" + ID + "-mask{position:fixed;inset:0;z-index:9999;background:rgba(0,0,0,.55);display:none}",
        "#" + ID + "-box{position:fixed;z-index:10000;left:50%;top:50%;transform:translate(-50%,-50%);width:340px;",
        "background:#15181d;border:1px solid rgba(255,255,255,.14);border-radius:10px;padding:16px 18px;",
        "font:12px/1.7 -apple-system,'Segoe UI',sans-serif;color:#d6dde6;display:none;box-shadow:0 18px 50px rgba(0,0,0,.6)}",
        "#" + ID + "-box h3{margin:0 0 10px;font-size:13px;font-weight:600;color:#fff;letter-spacing:.02em}",
        "#" + ID + "-box .row{margin:8px 0;display:flex;gap:8px;align-items:center}",
        "#" + ID + "-box code{flex:1;background:#0e1116;border:1px solid rgba(255,255,255,.1);border-radius:6px;",
        "padding:5px 8px;color:#9fd0ff;font-family:Consolas,monospace;letter-spacing:.06em}",
        "#" + ID + "-box textarea{width:100%;height:96px;resize:vertical;background:#0e1116;color:#d6dde6;",
        "border:1px solid rgba(255,255,255,.1);border-radius:6px;padding:6px 8px;font:11px/1.5 Consolas,monospace}",
        "#" + ID + "-box button{cursor:pointer;border-radius:6px;border:1px solid rgba(255,255,255,.16);",
        "background:#242a33;color:#d6dde6;padding:5px 12px;font-size:12px}",
        "#" + ID + "-box button.primary{background:#2a6ef0;border-color:#2a6ef0;color:#fff}",
        "#" + ID + "-box button:hover{filter:brightness(1.12)}",
        "#" + ID + "-box .hint{color:#7d8794;font-size:11px;margin-top:6px}",
        "#" + ID + "-box .msg{min-height:18px;margin-top:8px;font-size:11px}",
        "#" + ID + "-box .msg.err{color:#ff8f7a}#" + ID + "-box .msg.ok{color:#7ee0a6}"
    ].join("");

    function el(tag, attrs, text) {
        var n = doc.createElement(tag);
        if (attrs) { for (var k in attrs) { if (attrs.hasOwnProperty(k)) { n.setAttribute(k, attrs[k]); } } }
        if (text !== undefined) { n.textContent = text; }
        return n;
    }

    function chipText(s) {
        if (s.status === "active") { return "已授权 · " + (s.plan || ""); }
        if (s.status === "trial") { return "试用 · 全功能 · 剩 " + s.trialDaysLeft + " 天"; }
        if (s.status === "trial-expired") { return "试用已结束 · 激活"; }
        if (s.status === "mismatch") { return "许可证与机器不符"; }
        if (s.status === "invalid") { return "许可证无效"; }
        if (s.status === "no-host") { return "预览模式"; }
        return "未授权";
    }

    function chipClass(s) {
        if (s.status === "active") { return "ok"; }
        if (s.status === "trial") { return "trial"; }
        if (s.status === "trial-expired" || s.status === "mismatch" || s.status === "invalid") { return "warn"; }
        return "";
    }

    function mount() {
        if (mounted) { return mounted; }
        var style = el("style");
        style.textContent = CSS;
        doc.head.appendChild(style);

        var chip = el("div", { id: ID + "-chip" });
        var mask = el("div", { id: ID + "-mask" });
        var box = el("div", { id: ID + "-box", role: "dialog", "aria-modal": "true", "aria-labelledby": ID + "-title" });

        var h = el("h3", { id: ID + "-title" }, "授权 / 激活");
        var rowCode = el("div", { class: "row" });
        var code = el("code", null, "—");
        var btnCopy = el("button", null, "复制");
        rowCode.appendChild(code);
        rowCode.appendChild(btnCopy);

        var ta = el("textarea", { placeholder: "把 license.json 的全部内容粘贴到这里" });
        var rowBtn = el("div", { class: "row" });
        var btnAct = el("button", { class: "primary" }, "激活");
        var btnClose = el("button", { "aria-label": "关闭授权对话框" }, "关闭");
        var btnOff = el("button", null, "停用");
        rowBtn.appendChild(btnAct);
        rowBtn.appendChild(btnOff);
        rowBtn.appendChild(btnClose);

        var msg = el("div", { class: "msg" });
        var hint = el("div", { class: "hint" },
            "机器码绑定本机；换机器请重新申请。许可证文件由 CGArtLab 签发。");
        var weakWarn = el("div", { class: "hint", style: "color:#e0a83a;display:none;" },
            "当前机器码来自主机名兜底（没读到 BIOS UUID），改主机名或换系统会变。" +
            "请到 AE 首选项 > 脚本与表达式，勾选「允许脚本写入文件和访问网络」，重启 AE 后再复制机器码。");

        box.appendChild(h);
        box.appendChild(rowCode);
        box.appendChild(ta);
        box.appendChild(rowBtn);
        box.appendChild(msg);
        box.appendChild(hint);
        box.appendChild(weakWarn);
        doc.body.appendChild(chip);
        doc.body.appendChild(mask);
        doc.body.appendChild(box);

        function open() {
            mask.style.display = "block";
            box.style.display = "block";
            // 打开后把焦点放进粘贴框，Esc 关闭（避免只能靠鼠标点关闭）
            try { ta.focus(); } catch (eF) { }
        }
        function close() {
            mask.style.display = "none";
            box.style.display = "none";
            msg.textContent = "";
            msg.className = "msg";
        }

        chip.addEventListener("click", open);
        chip.setAttribute("role", "button");
        chip.setAttribute("tabindex", "0");
        chip.setAttribute("aria-label", "授权状态：点击查看机器码并激活");
        chip.addEventListener("keydown", function (ev) { if (ev.key === "Enter" || ev.key === " ") { ev.preventDefault(); open(); } });
        doc.addEventListener("keydown", function (ev) {
            if (ev.key === "Escape" && box.style.display === "block") { ev.preventDefault(); close(); }
        });
        btnClose.addEventListener("click", close);
        mask.addEventListener("click", close);

        btnCopy.addEventListener("click", function () {
            var txt = code.textContent;
            try {
                if (root.navigator && root.navigator.clipboard) {
                    root.navigator.clipboard.writeText(txt);
                } else {
                    var t = el("textarea");
                    t.value = txt;
                    doc.body.appendChild(t);
                    t.select();
                    doc.execCommand("copy");
                    doc.body.removeChild(t);
                }
                msg.className = "msg ok";
                msg.textContent = "机器码已复制";
            } catch (e) {
                msg.className = "msg err";
                msg.textContent = "复制失败，请手动选中";
            }
        });

        btnAct.addEventListener("click", function () {
            var key = (ta.value || "").replace(/^\s+|\s+$/g, "");
            function finish(ok, plan, reason) {
                if (ok) {
                    msg.className = "msg ok";
                    msg.textContent = "激活成功：" + (plan || "") + "，正在重载面板…";
                    ta.value = "";
                    setTimeout(function () { try { root.location.reload(); } catch (e) { } }, 700);
                } else {
                    msg.className = "msg err";
                    msg.textContent = "激活失败：" + (reason || "unknown");
                }
            }
            if (root.FuiCloud && root.FuiCloud.activate) {
                msg.className = "msg"; msg.textContent = "正在联网激活…";
                root.FuiCloud.activate(key, function (r) { finish(r && r.ok, r && r.plan, r && r.error); });
            } else {
                var r = root.FuiLicense.activate(key);
                finish(r && r.ok, r && r.plan, r && r.reason);
            }
        });

        btnOff.addEventListener("click", function () {
            root.FuiLicense.deactivate();
            msg.className = "msg";
            msg.textContent = "已停用本机许可证";
        });

        mounted = {
            render: function (s) {
                chip.className = chipClass(s);
                chip.textContent = chipText(s);
                code.textContent = s.machineCode || "—";
                chip.title = "点击查看授权状态 / 激活";
                try { weakWarn.style.display = (s && s.weakMachine) ? "" : "none"; } catch (eW) { }
            }
        };
        return mounted;
    }

    function start() {
        var ui = mount();
        root.FuiLicense.init({ onChange: function (s) { ui.render(s); } });
        ui.render(root.FuiLicense.state());
    }

    if (doc.readyState === "loading") {
        doc.addEventListener("DOMContentLoaded", start);
    } else {
        start();
    }
})(typeof globalThis !== "undefined" ? globalThis :
    (typeof window !== "undefined" ? window : this));





