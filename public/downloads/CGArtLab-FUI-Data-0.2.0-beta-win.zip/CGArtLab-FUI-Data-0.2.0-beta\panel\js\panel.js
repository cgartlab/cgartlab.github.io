/**
 * panel.js —— CEP 面板交互层（DATA & UNIT 重构版）
 * © 2026 CGArtLab · https://cgartlab.com · CGArtLab FUI Data
 * ------------------------------------------------------------------
 * 主流程：选中图层 → [检测选中图层] → 显示 文字/数字/当前值/疑似单位/建议量纲 →
 *         设置量纲/单位/格式 → [应用到选中图层]（单层优先，可切批量）。
 * 依赖 config_builder.js(提供 window.FUI) 与 CSInterface.js。
 * 与宿主的桥：evalScript fuiDetectLayer / fuiApplyData / fuiGetLayerListJSON /
 *            fuiGetDatatypeSpecJSON / fuiGetActiveCompName。
 */
(function () {
    "use strict";

    var FUI = window.FUI;
    var csInterface = (typeof CSInterface !== "undefined") ? new CSInterface() : null;

    var state = null;          // FUI.defaultDataState() 的扩展实例
    var layerList = [];        // 当前合成图层名
    var registry = null;       // 量纲注册表（优先用宿主返回的 datatype_spec.json）
    var batchDetections = [];  // 多选时每个图层的识别结果
    var batchMixed = {};       // 多选时哪些参数存在多个值
    var batchDetectToken = 0;  // 防止过期异步检测回填
    var previewEditing = false; // 预览数值编辑中，避免轮询覆盖输入
    var previewInputTimer = null; // 纯文本预览输入防抖
    var panelActiveFlag = true; // 面板是否处于前台；AE 文本编辑期间停止脚本轮询
    var lastPanelInteraction = 0; // 最近一次面板鼠标/键盘交互时间（不使用不可靠的 CEP focus）
    var KF_CONTROL_MAP = {
        decimals: "decimals", padding: "padding", prefixSpace: "prefixSpace",
        unitSpace: "unitSpace", suffixSpace: "suffixSpace", thousands: "thousands",
        timerMs: "timerMs", timerMode: "timerMode", numColor: "numColor"
    };
    var compName = "";

    function $(id) { return document.getElementById(id); }
    function clone(v) { return JSON.parse(JSON.stringify(v)); }
    function isArray(v) { return Object.prototype.toString.call(v) === "[object Array]"; }
    function setHidden(el, hidden) { if (el) { el.style.display = hidden ? "none" : ""; } }
    function setText(id, v) { var el = $(id); if (el) { el.textContent = (v === undefined || v === null) ? "" : String(v); } }

    /* ================= 日志 ================= */
    function log(msg, kind) {
        var el = $("log");
        if (!el) { return; }
        // 只保留最近 300 行：日志会随每次操作增长，无限追加会让面板越用越卡
        while (el.childNodes.length >= 300) { el.removeChild(el.firstChild); }
        var line = document.createElement("div");
        line.className = "log-line" + (kind ? " log-" + kind : "");
        var t = new Date();
        var hh = ("0" + t.getHours()).slice(-2);
        var mm = ("0" + t.getMinutes()).slice(-2);
        var ss = ("0" + t.getSeconds()).slice(-2);
        line.textContent = "[" + hh + ":" + mm + ":" + ss + "] " + msg;
        el.appendChild(line);
        el.scrollTop = el.scrollHeight;
    }
    function short(s) {
        if (s === null || s === undefined) { return String(s); }
        s = String(s);
        return s.length > 200 ? s.slice(0, 200) + " …" : s;
    }
    /* 宿主有两类返回值：JSON 字符串（fuiPanelJson）或直接对象。
     * 面板侧又常包一层 JSON.stringify(...)，于是可能拿到「字符串的字符串」。
     * 统一在这里解到对象，避免批量应用出现「成功也报失败」。 */
    function parseHostResult(res) {
        var v = res;
        for (var i = 0; i < 3; i++) {
            if (typeof v !== "string") { break; }
            var t = v.replace(/^\s+|\s+$/g, "");
            if (!t) { return null; }
            if (t.charAt(0) !== "{" && t.charAt(0) !== "[" && t.charAt(0) !== '"') { return null; }
            try { v = JSON.parse(t); } catch (e) { return null; }
        }
        return (v && typeof v === "object") ? v : null;
    }
    /* 把宿主返回的英文许可错误码翻译成可执行的中文提示 */
    function humanizeLicenseError(msg) {
        var s = String(msg || "");
        if (s.indexOf("LICENSE_REQUIRED") >= 0) {
            return "此功能需要激活：点右上角授权状态条，复制机器码并粘贴许可证后再试";
        }
        return s;
    }

    /* ================= 量纲注册表访问 ================= */
    function getRegistry() { return registry || FUI.DATATYPE_DEFAULTS; }
    /* ---- 授权档位对「类型下拉」的过滤 ----
     * 未激活（试用/免费档）时只允许 license_core 定义的免费类型；
     * 已激活时返回 null 表示不限制。
     * 这一层是必需的：开发版 format_core.js 内联了全量注册表，
     * 若不做过滤，试用状态下也会出现全部 34 类，等于绕过授权。 */
    /* 「功能全开」：正式授权或试用期内。试用到期后只留免费类型。 */
    function isLicensedActive() {
        try {
            if (window.FUI_CLOUD && window.FUI_CLOUD.licensed) { return true; }
            if (window.FuiLicense && window.FuiLicense.state) {
                var s = window.FuiLicense.state();
                return !!(s && (s.status === "active" || s.status === "trial"));
            }
        } catch (eLic) { }
        return false;
    }
    function freeTypeIds() {
        try {
            if (window.FuiLicenseCore && window.FuiLicenseCore.FREE_TYPE_IDS) {
                return window.FuiLicenseCore.FREE_TYPE_IDS.slice(0);
            }
        } catch (eFree) { }
        return ["generic", "temperature", "percent"];
    }
    function allowedTypeIdSet() {
        if (isLicensedActive()) { return null; }
        var ids = freeTypeIds(), set = {};
        for (var i = 0; i < ids.length; i++) { set[ids[i]] = true; }
        return set;
    }
    function getType(typeId) {
        var r = getRegistry();
        if (r && r[typeId]) { return r[typeId]; }
        return (FUI.DATATYPE_DEFAULTS.generic);
    }
    function typeList() {
        var r = getRegistry();
        var allowed = allowedTypeIdSet();
        var out = [];
        for (var k in r) {
            if (Object.prototype.hasOwnProperty.call(r, k)) {
                if (allowed && !allowed[k]) { continue; }
                out.push({ id: k, label: (r[k] && r[k].label) ? r[k].label : k });
            }
        }
        return out;
    }
    /* 从当前注册表计算某量纲字段默认值（与 config_builder 一致；支持宿主 spec 覆盖） */
    function typeDefaults(typeId) {
        var t = getType(typeId) || {};
        var baseUnit = t.baseUnit || (isArray(t.units) && t.units.length ? t.units[0].id : "");
        var rng = t.range || {};
        return {
            unitId: baseUnit,
            decimals: (t.decimals === undefined ? 1 : t.decimals),
            thousands: !!t.thousands,
            forceSign: !!t.forceSign,
            allowNegative: (t.allowNegative !== false),
            format: t.format || "number",
            behavior: t.behavior || "smooth",
            timerMode: t.timerMode || "format",
            rangeMin: (rng.min === null || rng.min === undefined) ? "" : rng.min,
            rangeMax: (rng.max === null || rng.max === undefined) ? "" : rng.max,
            clamp: !!rng.clamp,
            thresholds: clone(t.thresholds || []),
            prefix: t.prefix || "",
            suffix: t.suffix || ""
        };
    }
    function applyTypeDefaults(typeId) {
        var d = typeDefaults(typeId);
        state.typeId = typeId;
        for (var k in d) {
            if (Object.prototype.hasOwnProperty.call(d, k)) { state[k] = d[k]; }
        }
        // 单位与数字之间默认空一格：以注册表里该单位的 space 声明为准（用户改过就不再覆盖）
        if (!state.__unitSpaceTouched) { state.unitSpace = unitSpaceDefault(); }
        // 缓动已简化为手动/平滑/匀速/保持，类型自带的其他值一律回落到“手动”
        if (["manual", "smooth", "linear", "hold"].indexOf(state.behavior) < 0) { state.behavior = "manual"; }
    }
    /* 当前所选单位是否「与数字之间带空格」——注册表用 space:true 声明 */
    function unitSpaceDefault() {
        try {
            var t = getType(state.typeId) || {};
            var us = isArray(t.units) ? t.units : [];
            for (var i = 0; i < us.length; i++) {
                if (us[i].id === state.unitId || us[i].label === state.unitId) { return us[i].space ? 1 : 0; }
            }
            if (us.length) { return us[0].space ? 1 : 0; }
        } catch (eUS) { }
        return 0;
    }

    /* ================= 下拉渲染 ================= */
    function fillTypeSelect() {
        var sel = $("typeSelect");
        if (!sel) { return; }
        sel.innerHTML = "";
        var ts = typeList();
        for (var i = 0; i < ts.length; i++) {
            var o = document.createElement("option");
            o.value = ts[i].id;
            o.textContent = ts[i].label;
            sel.appendChild(o);
        }
        // 当前类型不在可用范围（例如未激活却停在付费类型上）时，回落到通用数字
        var found = false;
        for (var j = 0; j < ts.length; j++) { if (ts[j].id === state.typeId) { found = true; break; } }
        // 批量混合类型时 typeId 是 "__mixed__"，它不是注册表里的类型，不能当成非法值回落
        if (!found && state.batch && state.typeId === "__mixed__") {
            var om = document.createElement("option");
            om.value = "__mixed__"; om.textContent = "— 多值";
            sel.insertBefore(om, sel.firstChild);
            found = true;
        }
        if (!found) {
            var fallback = "generic";
            var hasGeneric = false;
            for (var k = 0; k < ts.length; k++) { if (ts[k].id === fallback) { hasGeneric = true; break; } }
            if (!hasGeneric && ts.length) { fallback = ts[0].id; }
            state.typeId = fallback;
        }
        sel.value = state.typeId;
    }

    /* 授权状态是异步解析的：状态确定后刷新类型下拉 */
    function refreshTypeSelectByLicense() {
        fillTypeSelect();
        fillUnitSelect();
        syncControls();
        updateConditionalBlocks();
        updatePreview();
    }
    function watchLicenseForTypeList() {
        try {
            if (window.FuiLicense && window.FuiLicense.onChange) {
                window.FuiLicense.onChange(function () {
                    licenseSettled = true;
                    loadDatatypeSpec();
                    // 数量变了由 loadDatatypeSpec 自己记日志；没变（试用到期仍是 4 类）才补一条
                    if (specLogPending) {
                        logSpecCount(typeList().length);
                    }
                    specLogPending = false;
                    refreshTypeSelectByLicense();
                });
            }
        } catch (eWatch) { }
        // 兜底：授权状态推送与 AE 侧校验是异步的，稍后再对齐；这里要重载注册表，
        // 否则面板会一直停在免费 4 类（「已授权」但下拉只有 4 项正是这个原因）。
        function settleReload() {
            if (licenseSettled) { return; }   // onChange 已经处理过，不再重复拉取规格
            licenseSettled = true;
            loadDatatypeSpec();
            if (specLogPending) {
                logSpecCount(typeList().length);
            }
            specLogPending = false;
            refreshTypeSelectByLicense();
        }
        setTimeout(settleReload, 600);
        setTimeout(settleReload, 1800);
    }

    function fillUnitSelect() {
        var sel = $("unitSelect");
        if (!sel) { return; }
        sel.innerHTML = "";
        var t = getType(effTypeId()) || {};
        var units = isArray(t.units) ? t.units : [];
        if (!units.length) {
            var o0 = document.createElement("option");
            o0.value = "";
            o0.textContent = "无";
            sel.appendChild(o0);
            sel.disabled = true;
            state.unitId = "";
            sel.value = "";
            return;
        }
        sel.disabled = false;
        var matched = false;
        for (var i = 0; i < units.length; i++) {
            var o = document.createElement("option");
            o.value = units[i].id;
            o.textContent = (units[i].selectLabel && units[i].selectLabel !== "") ? units[i].selectLabel : ((units[i].label && units[i].label !== "") ? units[i].label : (units[i].id === "none" ? "无" : units[i].id));
            if (units[i].id === state.unitId) { matched = true; }
            sel.appendChild(o);
        }
        if (!matched) { state.unitId = units[0].id; }
        sel.value = state.unitId;
    }

    /* ================= 控件同步 ================= */
    function syncControls() {
        $("decimals").value = state.decimals;
        var padEl = $("padding"); if (padEl) { padEl.value = (state.padding === null || state.padding === undefined) ? 0 : state.padding; }
        var trEl = $("tracking"); if (trEl) { trEl.value = (state.tracking === null || state.tracking === undefined) ? "" : state.tracking; }
        var dcEl = $("decimalChar"); if (dcEl) { dcEl.value = state.decimalChar || "."; }
        var alEl = $("align"); if (alEl) { alEl.value = state.align || ""; }
        var afsEl = $("affixFontSize"); if (afsEl) { afsEl.value = (state.affixFontSize === null || state.affixFontSize === undefined) ? "" : state.affixFontSize; }
        var afFontEl = $("affixFont"); if (afFontEl) { afFontEl.value = state.affixFont || ""; }
        var nc0 = $("numColor"); if (nc0) { nc0.value = state.numColor || "#ffffff"; }
        renderAnchor();
        $("thousands").checked = !!state.thousands;
        var smEl = $("signMode"); if (smEl) { smEl.value = state.forceSign ? "plusminus" : "minus"; }
        var heEl = $("hemisphere"); if (heEl) { heEl.value = state.hemisphere || "lat"; }
        var tmEl2 = $("timerMs"); if (tmEl2) { tmEl2.checked = !!state.timerMs; }
        var tiEl = $("timerInput");
        if (tiEl) {
            if (state.typeId === "timer" && state.__liveValue !== undefined && state.__liveValue !== null && !isNaN(Number(state.__liveValue))) {
                tiEl.value = formatTimeInput(state.__liveValue);
            } else { tiEl.value = ""; }
        }
        var anEl = $("allowNegative"); if (anEl) { anEl.checked = state.allowNegative !== false; }
        var rm0 = $("rangeMin"); if (rm0) { rm0.value = (state.rangeMin === null || state.rangeMin === undefined) ? "" : state.rangeMin; }
        var rx0 = $("rangeMax"); if (rx0) { rx0.value = (state.rangeMax === null || state.rangeMax === undefined) ? "" : state.rangeMax; }
        var cl0 = $("clamp"); if (cl0) { cl0.checked = !!state.clamp; }
        $("prefix").value = state.prefix || "";
        $("suffix").value = state.suffix || "";
        $("prefixSpace").value = (state.prefixSpace === null || state.prefixSpace === undefined) ? "" : state.prefixSpace;
        $("unitSpace").value = (state.unitSpace === null || state.unitSpace === undefined) ? "" : state.unitSpace;
        $("suffixSpace").value = (state.suffixSpace === null || state.suffixSpace === undefined) ? "" : state.suffixSpace;
        $("behavior").value = state.behavior || "smooth";
        $("rate").value = state.rate;
        $("rmbUppercase").checked = !!state.rmbUppercase;

        updatePreview();
    }

    /* 纯文本 + 没选锚点 = 点【应用】什么都不会发生（只读类型）。
     * 与其让用户点了没反应，不如直接禁用并说明原因。 */
    function updateApplyAvailability() {
        var btn = $("btnApply"); if (!btn) { return; }
        var dead = (state.typeId === "plainText" && !state.anchor && !state.batch);
        btn.disabled = !!dead;
        btn.title = dead ? "纯文本类型只读，不修改图层；想要调整位置请先选锚点" : "把当前参数应用到所选图层";
    }

    function updateAffixAvailability() {
        var pre = (state.prefix || "").replace(/^\s+|\s+$/g, "");
        var suf = (state.suffix || "").replace(/^\s+|\s+$/g, "");
        var hasAffix = !!(pre || suf);
        var ps = $("prefixSpace"); if (ps) { ps.disabled = !pre; }
        var ss = $("suffixSpace"); if (ss) { ss.disabled = !suf; }
        var af = $("affixFontSize"); if (af) { af.disabled = !hasAffix; }
        var affF = $("affixFont"); if (affF) { affF.disabled = !hasAffix; }
        setHidden($("affixFontRow"), !hasAffix);
        setHidden($("affixFontSizeRow"), !hasAffix);
    }

    /* 批量里类型不一致时 state.typeId 是 "__mixed__"；条件块仍按第一层的类型渲染，
     * 否则单位行、间距行会被全部误隐藏。 */
    function effTypeId() {
        if (state.typeId === "__mixed__") { return state.__batchFallbackType || "generic"; }
        return state.typeId || "generic";
    }

    function updateConditionalBlocks() {
        var cs = $("configSection"); if (cs) { if (state.typeId === "plainText") { cs.classList.add("plain-mode"); } else { cs.classList.remove("plain-mode"); } }
        var hrEl = $("hemisphereRow"); if (hrEl) { setHidden(hrEl, effTypeId() !== "coordinate"); }
        var t = getType(effTypeId()) || {};
        var isCurrency = (effTypeId() === "currency");
        var isTimer = (effTypeId() === "timer") || (t.format === "timecode");
        setHidden($("currencyBlock"), !isCurrency);
        setHidden($("timerBlock"), !isTimer);
        // 单位间距仅对“有可拆单位文本”的类型生效，避免设了无反应
        var tu = getType(effTypeId()) || {};
        var unitsArr = tu.units || [];
        var hasUnitLabel = false;
        for (var ui0 = 0; ui0 < unitsArr.length; ui0++) { if (unitsArr[ui0] && unitsArr[ui0].label) { hasUnitLabel = true; break; } }
        var canUnitSpace = hasUnitLabel && tu.format !== "dms" && tu.format !== "timecode" && !(effTypeId() === "currency" && state.rmbUppercase);
        setHidden($("unitSpaceRow"), !canUnitSpace);
        setHidden($("unitRow"), !hasUnitLabel);
        var usEl = $("unitSelect"); if (usEl) { usEl.disabled = false; }
        var dcSel = $("decimalChar"); if (dcSel) { dcSel.disabled = (Number(state.decimals) === 0); }
        // 范围/限制只对「有数值」的类型有意义：纯文本、时间码不显示
        var showRange = (effTypeId() !== "plainText" && tu.format !== "timecode");
        setHidden($("rangeRow"), !showRange);
        setHidden($("limitRow"), !showRange);
        updateAffixAvailability();
        updateApplyAvailability();
        applyBatchMarks();
    }

    /* ================= 检测结果 ================= */
    /* 检测结果直接变成一行日志：面板不再单开「检测」区，选中图层就自动回填参数。
     * 想核对识别过程时看日志这一行即可。 */
    function renderDetection(r) {
        var st = r.suggestedType ? getType(r.suggestedType) : null;
        var sug = st ? (st.label || r.suggestedType) : (r.suggestedType || "—");
        var parts = [];
        parts.push(r.layerName || "图层");
        if (!r.isText) { parts.push("非文字层"); }
        else if (r.isNumeric) {
            parts.push("值 " + String(r.parsedValue));
            if (r.parsedUnit) { parts.push("单位 " + r.parsedUnit); }
            parts.push("→ " + sug);
        } else {
            parts.push("未识别到数字");
        }
        if (r.prefix) { parts.push("前缀「" + r.prefix + "」"); }
        if (r.suffix) { parts.push("后缀「" + r.suffix + "」"); }
        log("识别：" + parts.join(" · "), r.isNumeric ? "ok" : "info");
    }
    function clearDetection() { }

    /* ================= 图层 / 批量 ================= */
    function fillLayerSelect() {
        var sel = $("layerSelect");
        if (!sel) { return; }
        sel.innerHTML = "";
        var o0 = document.createElement("option");
        o0.value = "";
        o0.textContent = "（跟随 AE 当前选中）";
        sel.appendChild(o0);
        var found = false;
        for (var i = 0; i < layerList.length; i++) {
            var o = document.createElement("option");
            o.value = layerList[i];
            o.textContent = layerList[i];
            if (layerList[i] === state.selectedLayer) { found = true; }
            sel.appendChild(o);
        }
        if (state.selectedLayer && !found) {
            var o2 = document.createElement("option");
            o2.value = state.selectedLayer;
            o2.textContent = state.selectedLayer + "（不在当前合成）";
            sel.appendChild(o2);
        }
        sel.value = state.selectedLayer || "";
    }

    /* 多选即批量：已经不需要清单与开关，只留一行说明。
     * 这一行同时承担「告诉用户这次会写到哪些层」的职责。 */
    function syncBatchUI() {
        var hint = $("batchHint");
        if (!hint) { return; }
        var show = !!(state.batch && state.batchLayers && state.batchLayers.length > 1);
        if (show) {
            hint.classList.remove("hidden");
            var expired = licenseSettled && !isLicensedActive();
            var note = state.__batchNote || "";
            if (expired) { hint.textContent = "批量 · " + state.batchLayers.length + " 层：试用已结束，批量应用需要激活"; }
            else { hint.textContent = "批量 · " + state.batchLayers.length + " 层" + (note ? "：" + note : ""); }
        } else {
            hint.classList.add("hidden");
            hint.textContent = "";
        }
    }

    function updateStatusLine() {
        var msg;
        if (state.batch && state.batchLayers && state.batchLayers.length) { msg = state.batchLayers.length + " 个图层"; }
        else if (state.selectedLayer) { msg = state.selectedLayer; }
        else { msg = "未选择图层"; }
        setText("statusLine", msg);
    }

    /* ================= evalScript 桥 ================= */
    function evalScript(script, cb) {
        if (!csInterface) {
            log("非 CEP 环境，无法执行 evalScript", "warn");
            if (cb) { cb(""); }
            return;
        }
        // 统一包一层 try/catch：宿主里任何异常都带 file/line 返回，而不是弹 AE 模态框。
        // ExtendScript 的 e.fileName/e.line 指向真正出错的源文件（比如 fui_panel_host.jsx 第 84 行）。
        var guarded = "(function(){try{return (" + script + ");}catch(e){" +
            "return JSON.stringify({__err:true,msg:String(e&&e.message?e.message:e)," +
            "line:(e&&e.line)?e.line:0,file:(e&&e.fileName)?String(e.fileName):''});}})()";
        csInterface.evalScript(guarded, function (res) {
            var errInfo = null;
            try {
                var o = JSON.parse(res);
                if (o && o.__err) { errInfo = o; }
            } catch (eParse) { }
            if (errInfo) {
                log("宿主脚本错误：" + (errInfo.file || "?") + " 第 " + errInfo.line + " 行：" + errInfo.msg, "err");
            }
            if (cb) { cb(res); }
        });
    }

    function refreshLayers(verbose) {
        evalScript("fuiGetActiveCompName()", function (name) {
            compName = name ? String(name).replace(/^"|"$/g, "") : "";
            evalScript("fuiGetLayerListJSON(\"\")", function (res) {
                var arr = [];
                try { arr = JSON.parse(res || "[]"); } catch (e) { arr = []; }
                layerList = isArray(arr) ? arr : [];
                fillLayerSelect();
                updateStatusLine();
                if (verbose) { log("图层已刷新，共 " + layerList.length + " 个图层", "ok"); }
            });
        });
    }

    var specLoadToken = 0;
    var lastSpecTypeCount = -1;
    var licenseSettled = false;   // 授权状态是异步的：确认前不写「载入注册表」日志，避免先报 4 类再报 34 类
    var specLogPending = false;
    var lastLoggedSpecCount = -1;
    function logSpecCount(n) {
        if (n === lastLoggedSpecCount) { return; }
        lastLoggedSpecCount = n;
        log("已从 datatype_spec.json 载入量纲注册表（" + n + " 类）", "ok");
    }
    function loadDatatypeSpec() {
        var myToken = ++specLoadToken;
        evalScript("fuiGetDatatypeSpecJSON()", function (res) {
            if (!res) { return; }
            // 授权后会有第二次加载（全量 34 类）。先发出、后返回的旧请求必须丢弃，
            // 否则免费 4 类的响应可能最后落地，把面板打回 4 类。
            if (myToken !== specLoadToken) { return; }
            var spec = null;
            try { spec = JSON.parse(res); } catch (e) { spec = null; }
            // datatype_spec.json 结构为 { schemaVersion, note, types:{...} }
            if (spec && spec.types && typeof spec.types === "object") { spec = spec.types; }
            if (spec && typeof spec === "object" && !isArray(spec)) {
                registry = spec;
                // 授权后 spec 是全量、引擎是免费档：以多的一方为准注入，避免把开发环境缩水
                try {
                    if (window.FUIFormatCore && window.FUIFormatCore.setRegistry) {
                        var _nSpec = 0, _nEng = 0, _k1, _k2;
                        for (_k1 in spec) { if (spec.hasOwnProperty(_k1)) { _nSpec++; } }
                        for (_k2 in window.FUIFormatCore.REGISTRY) {
                            if (window.FUIFormatCore.REGISTRY.hasOwnProperty(_k2)) { _nEng++; }
                        }
                        if (_nSpec > _nEng) { window.FUIFormatCore.setRegistry(spec); }
                    }
                } catch (eSetReg) { }
                // datatype_spec.json 可能落后于 format_core 新增类型：合并缺失的类型
                try {
                    if (window.FUIFormatCore && window.FUIFormatCore.REGISTRY) {
                        for (var _rk in window.FUIFormatCore.REGISTRY) {
                            if (registry[_rk] === undefined) { registry[_rk] = window.FUIFormatCore.REGISTRY[_rk]; }
                            else {
                                try {
                                    if (window.FUIFormatCore.REGISTRY[_rk].units) { registry[_rk].units = window.FUIFormatCore.REGISTRY[_rk].units; }
                                    if (window.FUIFormatCore.REGISTRY[_rk].label) { registry[_rk].label = window.FUIFormatCore.REGISTRY[_rk].label; }
                                } catch (eOvT) { }
                            }
                        }
                    }
                } catch (eMergeTypes) { }
                var wasBatch = !!(state.batch && state.batchLayers && state.batchLayers.length);
                fillTypeSelect();
                if (!wasBatch) { applyTypeDefaults(state.typeId); }
                fillUnitSelect();
                syncControls();
                updateConditionalBlocks();
                var countNow = typeList().length;
                // 授权前后可能并发请求注册表：按回调那一刻的真实数量比较，避免同一数量记两次
                if (countNow !== lastSpecTypeCount) {
                    lastSpecTypeCount = countNow;
                    if (licenseSettled) { logSpecCount(countNow); }
                    else { specLogPending = true; }
                    if (wasBatch) { setTimeout(function () { try { detectBatch(state.batchLayers.slice(0)); } catch (eBD) { } }, 0); }
                    else if (state.selectedLayer) { setTimeout(function () { try { detectSpecific(state.selectedLayer); } catch (eSD) { } }, 0); }
                }
            }
        });
    }

    /* ================= 自动检测所选图层 ================= */
    function applyDetection(r) {
        clearMixedIndicators();
        renderDetection(r);
        state.__isText = r.isText; state.__isNumeric = r.isNumeric;
        // 换图层时必须清掉上一个图层的参数 K 帧状态，否则「颜色」等按钮会显示成红色（当前在关键帧上）
        if (r.layerName && r.layerName !== state.__paramStatesLayer) {
            state.__paramStatesLayer = r.layerName;
            state.__paramStates = {};
            state.__liveValue = null;
            state.__valueKeyed = false;
            state.__atKeyframe = false;
        }
        if (r.parsedValue !== null && r.parsedValue !== undefined && !isNaN(Number(r.parsedValue))) {
            state.__sampleValue = Number(r.parsedValue);
        }
        if (r.text !== undefined) { state.__layerText = String(r.text || ""); }
        if (r.layerName) {
            state.selectedLayer = r.layerName;
            try { $("layerSelect").value = r.layerName; } catch (e) { }
            updateStatusLine();
        }
        var btn = $("btnApply"); if (btn) { btn.disabled = false; }
        if (r.valueCurrent !== undefined) { state.__liveValue = r.valueCurrent; state.__valueKeyed = !!r.valueKeyed; state.__atKeyframe = !!r.valueAtKeyframe; }
        if (r.hasValueControl !== undefined) { state.__hasValueControl = !!r.hasValueControl; }
        if (r.suggestedType && getRegistry()[r.suggestedType]) {
            // plainText 是「没识别到 FUI 标记」时的安全默认值，不能拿它覆盖用户当前选的类型，
            // 否则选中任何未应用过的图层都会把面板切成只读、并清空前缀/后缀等设置。
            if (r.suggestedType === "plainText") {
                if (state.typeId === "plainText") { /* 已是纯文本，保持不变 */ }
                else { log("未识别到本工具的类型标记：请手动选择数据类型；纯文本类型只读，不修改图层", "info"); }
            } else if (r.suggestedType !== state.typeId) {
                // 仅当数据类型真的变化时才套用类型默认值；避免同一图层因文本/名称变化而被重置（如清空前缀）
                applyTypeDefaults(r.suggestedType);
                fillTypeSelect(); fillUnitSelect(); syncControls(); updateConditionalBlocks();
            }
        }
        // 切换图层时先清掉上一层的格式态，避免「串味」：上一层的 T=、加减号、锚点、计时开关等
        // 粘到新图层上，并在点应用时被写进目标层。
        var isNewLayer = !!(r.layerName && r.layerName !== state.__detectedLayer);
        if (isNewLayer) {
            var td0 = typeDefaults(state.typeId);
            state.prefix = ""; state.suffix = "";
            state.prefixSpace = 0; state.suffixSpace = 0;
            state.__unitSpaceTouched = false;
            state.unitSpace = unitSpaceDefault();   // 跟随该单位的 space 声明，别在这里写死 0
            state.forceSign = !!td0.forceSign;
            state.anchor = "";
            state.tracking = "";
            state.affixFont = ""; state.affixFontSize = "";
            state.timerMs = false;
            state.__layerText = "";
            state.__liveValue = undefined;
            state.__hasValueControl = false;
            state.__paramStates = {};
            state.__detectedLayer = r.layerName;
            renderAnchor();
            syncControls();
        }
        // 若图层已带 FUI_* 控件，回读其参数覆盖面板（识别相关参数）
        if (r.controls) {
            var cc = r.controls;            if (cc.decimals !== undefined) { state.decimals = cc.decimals; }
            if (cc.padding !== undefined) { state.padding = cc.padding; }
            if (cc.prefixSpace !== undefined) { state.prefixSpace = cc.prefixSpace; }
            if (cc.unitSpace !== undefined) { state.unitSpace = cc.unitSpace; }
            if (cc.suffixSpace !== undefined) { state.suffixSpace = cc.suffixSpace; }
            if (cc.thousands !== undefined) { state.thousands = !!cc.thousands; }
            syncControls();
        }
        if (r.timerMode !== undefined) { state.timerMode = r.timerMode; }
        if (r.timerMs !== undefined) { state.timerMs = !!r.timerMs; }
        if (r.timerMode !== undefined || r.timerMs !== undefined) { syncControls(); }
        // 回读单位（按文本中识别到的单位）
        if (r.parsedUnit) {
            var tt = getType(state.typeId) || {};
            var uns = isArray(tt.units) ? tt.units : [];
            var fid = "";
            for (var ui2 = 0; ui2 < uns.length; ui2++) {
                if (uns[ui2].id === r.parsedUnit || uns[ui2].label === r.parsedUnit) { fid = uns[ui2].id; break; }
            }
            if (fid && fid !== state.unitId) {
                state.unitId = fid; fillUnitSelect();
                // 单位定了之后才能算出「单位空格」默认值（°C、m 这类默认带 1 个空格）。
                // 但如果图层上已有「单位空格」控件，就以图层实际值为准，别用默认值覆盖它。
                var layerHasUnitSpace = !!(r.controls && r.controls.unitSpace !== undefined);
                if (!state.__unitSpaceTouched && !layerHasUnitSpace) { state.unitSpace = unitSpaceDefault(); syncControls(); }
            }
        }
        // 回读前后缀（独立子层）
        if (r.prefix !== undefined || r.suffix !== undefined) {
            state.prefix = r.prefix || "";
            state.suffix = r.suffix || "";
            syncControls();
        }
        // 回读单位（来自 FUI单位 子层）
        if (r.unitLabel) {
            var tt2 = getType(state.typeId) || {};
            var uns2 = isArray(tt2.units) ? tt2.units : [];
            for (var ui3 = 0; ui3 < uns2.length; ui3++) {
                if (uns2[ui3].label === r.unitLabel || uns2[ui3].id === r.unitLabel) { state.unitId = uns2[ui3].id; fillUnitSelect(); break; }
            }
        }
        // 回显当前字体/字号（仅占位提示，不改变面板选择）
        if (r.forceSign) { state.forceSign = true; var smEl0 = $("signMode"); if (smEl0) { smEl0.value = "plusminus"; } }
        if (r.timerMode !== undefined) { state.timerMode = r.timerMode; }
        if (r.timerMs !== undefined) { state.timerMs = !!r.timerMs; }
        if (r.timerMode !== undefined || r.timerMs !== undefined) { syncControls(); }
        if (r.tracking !== undefined && r.tracking !== null) { var trEl = $("tracking"); if (trEl) { trEl.placeholder = "当前：" + Math.round(r.tracking); } }
        if (r.fillColor && r.fillColor.length >= 3) {
            var hx = "#";
            for (var ci = 0; ci < 3; ci++) { var cv = Math.max(0, Math.min(255, Math.round(Number(r.fillColor[ci]) * 255))).toString(16); if (cv.length < 2) { cv = "0" + cv; } hx += cv; }
            state.numColor = hx; state.useColor = true; var ncEl0 = $("numColor"); if (ncEl0) { ncEl0.value = hx; }
        }
        updatePreview();
        pollValueState();
            syncBatchUI();
    }
    function numOrNull(v) { if (v === "" || v === null || v === undefined || isNaN(Number(v))) { return null; } return Number(v); }
    /* 计时：接受 HH:MM:SS 或 HH:MM:SS.mmm（也兼容 MM:SS / 纯秒数），返回总秒数。
     * 严格校验：分/秒必须 < 60；小时 <= 999；毫秒最多 3 位。非法返回 null。 */
    function parseTimeInput(txt) {
        var s = String(txt === null || txt === undefined ? "" : txt).replace(/^\s+|\s+$/g, "");
        if (!s) { return null; }
        var m = s.match(/^(-?)(\d{1,3}):(\d{1,2})(?::(\d{1,2}))?(?:\.(\d{1,3}))?$/);
        if (m) {
            var sign = m[1] === "-" ? -1 : 1;
            var h = 0, mi = 0, se = 0, frac = 0;
            if (m[4] !== undefined) { h = Number(m[2]); mi = Number(m[3]); se = Number(m[4]); }
            else { mi = Number(m[2]); se = Number(m[3]); }
            if (mi >= 60 || se >= 60) { return null; }
            if (m[5] !== undefined) { frac = Number(("0." + m[5])); }
            return sign * (h * 3600 + mi * 60 + se + frac);
        }
        m = s.match(/^[-+]?\d+(?:\.\d+)?$/);
        return m ? Number(s) : null;
    }
    /* 秒数 → HH:MM:SS[.mmm]：用整数毫秒分解，避免 59.9996 被格式化成非法的 00:00:60 */
    function formatTimeInput(sec) {
        var v = Number(sec); if (!isFinite(v)) { return ""; }
        var neg = v < 0;
        var totalMs = Math.round(Math.abs(v) * 1000);
        var ms = totalMs % 1000;
        var totalSec = (totalMs - ms) / 1000;
        var se = totalSec % 60;
        var totalMin = (totalSec - se) / 60;
        var mi = totalMin % 60;
        var h = (totalMin - mi) / 60;
        function p2(n) { return (n < 10 ? "0" : "") + n; }
        function p3(n) { return (n < 10 ? "00" : (n < 100 ? "0" : "")) + n; }
        return (neg ? "-" : "") + p2(h) + ":" + p2(mi) + ":" + p2(se) + (ms ? "." + p3(ms) : "");
    }
    /* 分组折叠（AE 属性组）：点分组标题展开/收起 */
    function bindGroups() {
        var titles = document.querySelectorAll("#configSection .group > .group-title");
        for (var i = 0; i < titles.length; i++) {
            (function (t) {
                t.addEventListener("click", function () {
                    var g = t.parentNode;
                    if (g && g.classList) { g.classList.toggle("collapsed"); }
                });
            })(titles[i]);
        }
    }

    /* 全局悬浮说明气泡：挂在 body 上（fixed），不被滚动容器裁切，自动上下翻转/贴边内收 */
    function bindTooltips() {
        var tip = document.getElementById("fuiTip");
        if (!tip) {
            tip = document.createElement("div");
            tip.id = "fuiTip";
            tip.className = "fui-tip";
            document.body.appendChild(tip);
        }
        function show(el) {
            var txt = el.getAttribute("data-tip");
            if (!txt) { return; }
            tip.textContent = txt;
            tip.style.display = "block";
            var r = el.getBoundingClientRect();
            var tw = tip.offsetWidth, th = tip.offsetHeight;
            var vw = window.innerWidth, vh = window.innerHeight;
            var left = r.left + r.width / 2 - tw / 2;
            if (left < 8) { left = 8; }
            if (left + tw > vw - 8) { left = vw - 8 - tw; }
            var top = r.bottom + 6;
            if (top + th > vh - 8) { top = r.top - 6 - th; }
            if (top < 8) { top = 8; }
            tip.style.left = Math.round(left) + "px";
            tip.style.top = Math.round(top) + "px";
        }
        function hide() { tip.style.display = "none"; }
        var els = document.querySelectorAll(".hint-q");
        for (var i = 0; i < els.length; i++) {
            (function (el) {
                if (el.__tipBound) { return; }
                el.__tipBound = true;
                el.addEventListener("mouseenter", function () { show(el); });
                el.addEventListener("mouseleave", hide);
                el.addEventListener("focus", function () { show(el); });
                el.addEventListener("blur", hide);
            })(els[i]);
        }
    }

    /* 让所有数字输入变成 AE 风格「可拖拽刷值(scrub)」：左右拖动改值，单击/不拖动则键入 */
    function bindScrubbers() {
        var ns = document.querySelectorAll('input[type=number]');
        for (var i = 0; i < ns.length; i++) {
            (function (el) {
                if (el.__scrubBound) { return; }
                el.__scrubBound = true;
                el.classList.add('scrub');
                if (!el.title) { el.title = "拖拽可调，单击可输入"; }
                var dragging = false, moved = false, startX = 0, startVal = 0;
                function stepOf() { var s = parseFloat(el.step); return (isNaN(s) || s <= 0) ? 1 : s; }
                function minOf() { var m = parseFloat(el.min); return isNaN(m) ? -Infinity : m; }
                function maxOf() { var m = parseFloat(el.max); return isNaN(m) ? Infinity : m; }
                el.addEventListener('pointerdown', function (e) {
                    if (e.button !== undefined && e.button !== 0) { return; }
                    dragging = true; moved = false; startX = e.clientX; startVal = parseFloat(el.value); if (isNaN(startVal)) { startVal = 0; }
                    try { el.setPointerCapture(e.pointerId); } catch (e1) { }
                });
                el.addEventListener('pointermove', function (e) {
                    if (!dragging) { return; }
                    var dx = e.clientX - startX;
                    if (!moved && Math.abs(dx) < 2) { return; }
                    moved = true;
                    var st = stepOf();
                    var nv = startVal + dx * st;
                    nv = Math.max(minOf(), Math.min(maxOf(), nv));
                    nv = (st < 1) ? (Math.round(nv / st) * st) : Math.round(nv);
                    nv = Math.round(nv * 1e6) / 1e6;
                    el.value = nv;
                    el.dispatchEvent(new Event('input', { bubbles: true }));
                    try { e.preventDefault(); } catch (e2) { }
                });
                function endDrag() { if (!dragging) { return; } dragging = false; if (moved) { try { el.blur(); } catch (e3) { } } }
                el.addEventListener('pointerup', endDrag);
                el.addEventListener('pointercancel', endDrag);
            })(ns[i]);
        }
    }
    function setLogHidden(hidden) {
        setHidden($("logSection"), !!hidden);
        var b = $("btnToggleLog"); if (b) { b.textContent = "日志"; b.title = hidden ? "显示日志" : "隐藏日志"; }
        try { localStorage.setItem("fui_log_hidden", hidden ? "1" : "0"); } catch (e) { }
    }
    var ANCHOR_NAMES = { tl: "左上", tc: "上中", tr: "右上", ml: "左中", mc: "居中", mr: "右中", bl: "左下", bc: "下中", br: "右下" };
    function renderAnchor() {
        var now = $("anchorNow");
        if (now) { now.textContent = state.anchor ? (ANCHOR_NAMES[state.anchor] || state.anchor) : "不改"; }
        var cells = document.querySelectorAll('.anchor-cell');
        for (var i = 0; i < cells.length; i++) {
            var k = cells[i].getAttribute('data-anchor');
            var on = (k === state.anchor);
            if (on) { cells[i].classList.add('active'); } else { cells[i].classList.remove('active'); }
            // 可访问性：九宫格是按钮语义，能 Tab 到、能回车/空格触发
            cells[i].setAttribute('role', 'button');
            cells[i].setAttribute('tabindex', '0');
            cells[i].setAttribute('aria-pressed', on ? 'true' : 'false');
            cells[i].setAttribute('aria-label', '锚点移到' + (ANCHOR_NAMES[k] || k));
            if (!cells[i].getAttribute('data-kb')) {
                cells[i].setAttribute('data-kb', '1');
                cells[i].addEventListener('keydown', function (ev) {
                    if (ev.key === 'Enter' || ev.key === ' ') { ev.preventDefault(); this.click(); }
                });
            }
        }
    }
    function updatePreviewKeyState() {
        var key = $("previewKey"); if (!key) { return; }
        if (state.batch || !state.selectedLayer || !state.__hasValueControl) { key.style.display = "none"; return; }
        key.style.display = "";
        key.className = "preview-key";
        if (state.__valueKeyed) {
            key.classList.add(state.__atKeyframe ? "at-key" : "has-keys");
            key.title = state.__atKeyframe ? "当前在关键帧上" : "已有关键帧（动画中）";
        } else { key.title = "未K帧，点击添加关键帧"; }
    }
    function updatePreview() {
        var el = $("previewLine"); if (!el) { return; }
        var pe = $("previewEdit");
        function setPreviewText(s) { if (pe) { pe.textContent = s; } else { el.textContent = s; } }
        var noSel = !state.selectedLayer && !(state.batch && state.batchLayers && state.batchLayers.length);
        if (noSel) {
            el.className = "preview is-empty";
            setPreviewText("在 AE 中选中文字图层后在此预览");
            el.style.color = ""; el.style.letterSpacing = "";
            var k0 = $("previewKey"); if (k0) { k0.style.display = "none"; }
            return;
        }
        el.className = "preview";
        // 批量：各层数值由各自「数值」控件决定，预览不能拿单一样例冒充
        if (state.batch) {
            setPreviewText("已选 " + (state.batchLayers ? state.batchLayers.length : 0) + " 层：各层保留原有数值，只统一写入当前参数");
            if (pe) { pe.contentEditable = "false"; }
            var kb = $("previewKey"); if (kb) { kb.style.display = "none"; }
            el.style.color = "var(--text-weak)";
            return;
        }
        // 非文字图层：预览必须说清，不能继续显示上一个图层的读数
        if (state.__isText === false) {
            setPreviewText("所选图层不是文字图层，无法挂数据（请在 AE 里选文字图层）");
            if (pe) { pe.contentEditable = "false"; }
            var kn2 = $("previewKey"); if (kn2) { kn2.style.display = "none"; }
            el.style.color = "#e0a04a";
            return;
        }
        try {
        if (state.typeId === "plainText") {
            setPreviewText("纯文本：不改动图层，请直接在 AE 图层中编辑文字");
            if (pe) { pe.contentEditable = "false"; }
            var kp = $("previewKey"); if (kp) { kp.style.display = "none"; }
            el.style.color = "var(--text-weak)"; el.style.letterSpacing = ""; el.style.textAlign = "";
            return;
        }
        if (pe) { pe.contentEditable = "true"; }
            if (!window.FUIFormatCore || !window.FUIFormatCore.formatValue) { setPreviewText("预览：—"); return; }
            var base = getType(state.typeId) || {};
            var spec = clone(base);
            spec.unit = state.unitId;
            spec.decimals = Number(state.decimals);
            spec.padding = numOrNull(state.padding) || 0;
            spec.decimalChar = state.decimalChar || ".";
            spec.__fontSize = 14;
            spec.thousands = !!state.thousands;
            spec.forceSign = !!state.forceSign;
            spec.allowNegative = (state.allowNegative !== false);
            spec.prefix = state.prefix || ""; spec.suffix = state.suffix || "";
            spec.hemisphere = state.hemisphere || "lat";
            spec.prefixSpace = numOrNull(state.prefixSpace); spec.unitSpace = numOrNull(state.unitSpace); spec.suffixSpace = numOrNull(state.suffixSpace);
            spec.range = { min: numOrNull(state.rangeMin), max: numOrNull(state.rangeMax), clamp: !!state.clamp };
            if (state.typeId === "currency" && state.rmbUppercase) { spec.format = "rmbUppercase"; }
            // 预览必须反映「应用后」的结果：
            //  · 已应用过的图层：Value 以显示单位存放，需中性化换算（baseUnit=所选单位、rate=1）
            //  · 还没应用过：示例值来自文字，是基准单位，必须走真实换算（1 m 选 cm → 100 cm）
            var liveApplied = (state.__hasValueControl === true);
            if (state.unitId) {
                spec.unit = state.unitId;
                if (liveApplied) {
                    spec.baseUnit = state.unitId; spec.rate = 1;
                    if (spec.units) { for (var ui = 0; ui < spec.units.length; ui++) { if (spec.units[ui].id === state.unitId) { spec.units[ui].factor = 1; spec.units[ui].offset = 0; } } }
                } else {
                    spec.baseUnit = base.baseUnit || state.unitId;
                    spec.rate = numOrNull(state.rate);
                    if (spec.rate === null) { spec.rate = (base.rate === undefined ? null : base.rate); }
                }
            } else { spec.baseUnit = base.baseUnit || ""; spec.rate = numOrNull(state.rate); }
            var sample = 42;
            if (!state.batch && state.__liveValue !== undefined && state.__liveValue !== null && !isNaN(Number(state.__liveValue))) {
                sample = Number(state.__liveValue);
            } else {
                if (state.__sampleValue !== undefined && state.__sampleValue !== null && !isNaN(Number(state.__sampleValue))) {
                    sample = Number(state.__sampleValue);
                }
            }
            spec.__fontSize = Number(state.__layerFontSize) || Number(state.fontSize) || 14;
            var s = window.FUIFormatCore.formatValue(sample, spec);
            if (!previewEditing) { setPreviewText(s); }
            updatePreviewKeyState();
            el.style.color = state.numColor || "";
            el.style.fontFamily = "";
            el.style.textAlign = state.align === "right" ? "right" : (state.align === "center" ? "center" : "left");
            var tr = Number(state.tracking); el.style.letterSpacing = (isNaN(tr) || tr === 0) ? "" : (tr / 1000 * 13) + "px";
        } catch (e) { setPreviewText("—"); }
    }
    function commitPreviewValue(txt) {
        if (!panelActiveFlag || !panelInteractionRecent()) { updatePreview(); return; }
        if (state.batch || !state.selectedLayer) { updatePreview(); return; }
        if (state.typeId === "plainText") { updatePreview(); return; }
        // 度分秒/半球这类格式不是「一个数字」，直接编辑会把值截断，禁用预览写回
        var tNow = getType(state.typeId) || {};
        if (tNow.format === "dms") { setStatus("坐标类数值请在 AE 的「数值」控件里改（预览不支持直接编辑）", "err"); updatePreview(); return; }
        if (state.typeId === "timer") {
            var sec = parseTimeInput(txt);
            if (sec === null || !isFinite(sec)) { updatePreview(); return; }
            evalScript("fuiSetValueDirect(" + JSON.stringify(state.selectedLayer) + "," + sec + ")", function () {
                state.__liveValue = sec; pollValueState(); updatePreview();
            });
            return;
        }
        var m = String(txt || "").replace(/,/g, "").match(/[-+]?\d+(?:\.\d+)?/);
        if (!m) { updatePreview(); return; }
        var v = Number(m[0]);
        evalScript("fuiSetValueDirect(" + JSON.stringify(state.selectedLayer) + "," + v + ")", function () {
            state.__liveValue = v; pollValueState(); updatePreview();
        });
    }
    function commitTimerInput() {
        var el = $("timerInput"); if (!el) { return; }
        if (state.batch) { setStatus("✗ 批量模式下不能单独改时间，请取消多选", "err"); return; }
        if (!state.selectedLayer) { setStatus("✗ 请先在 AE 里选中计时的文字图层", "err"); return; }
        var sec = parseTimeInput(el.value);
        if (sec === null || !isFinite(sec)) {
            setStatus("✗ 时间格式应为 HH:MM:SS 或 HH:MM:SS.mmm（分、秒小于 60）", "err");
            el.value = formatTimeInput(state.__liveValue);
            return;
        }
        evalScript("fuiSetValueDirect(" + JSON.stringify(state.selectedLayer) + "," + sec + ")", function (res) {
            var r = null; try { r = JSON.parse(res); } catch (e) { r = null; }
            if (r && r.ok) { state.__liveValue = sec; pollValueState(); updatePreview(); }
            else { setStatus("✗ 计时时间写入失败（请先应用计时类型）", "err"); el.value = formatTimeInput(state.__liveValue); }
        });
    }
    function pollValueState() {
        if (!state.selectedLayer || state.batch || state.__hasValueControl === false) { return; }
        if (!panelInteractionRecent()) { return; }
        evalScript("fuiGetValueState(" + JSON.stringify(state.selectedLayer) + ")", function (res) {
            var s = null; try { s = JSON.parse(res); } catch (e) { return; }
            if (!s || !s.ok) { return; }
            state.__liveValue = s.value; state.__valueKeyed = !!s.keyed; state.__atKeyframe = !!s.atKeyframe;
            if (!previewEditing) { updatePreview(); } else { updatePreviewKeyState(); }
        });
        evalScript("fuiGetParamStates(" + JSON.stringify(state.selectedLayer) + ")", function (res) {
            var s = null; try { s = JSON.parse(res); } catch (e) { return; }
            if (s && s.ok) { state.__paramStates = s.params || {}; updateParamKeyStates(); }
        });
    }
    var __livePollTimer = null;
    function liveValuePoll() {
        try {
            if (!state || state.batch) { return; }
            if (!state.selectedLayer) { return; }
            if (previewEditing) { return; }
            if (typeof document !== "undefined" && document.hidden) { return; }
            var layer = state.selectedLayer;
            evalScript("fuiGetValueState(" + JSON.stringify(layer) + ")", function (res) {
                var s = null; try { s = JSON.parse(res); } catch (e) { return; }
                if (!s || !s.ok) { return; }
                state.__hasValueControl = true;
                var changed = (state.__liveValue !== s.value);
                state.__liveValue = s.value;
                state.__valueKeyed = !!s.keyed;
                state.__atKeyframe = !!s.atKeyframe;
                if (changed) { if (!previewEditing) { updatePreview(); } else { updatePreviewKeyState(); } }
            });
        } catch (e) { }
    }
    function startLiveValuePoll() {
        if (__livePollTimer) { return; }
        __livePollTimer = setInterval(liveValuePoll, 400);
    }
    function setupKfIcons() {
        for (var key in KF_CONTROL_MAP) {
            if (!KF_CONTROL_MAP.hasOwnProperty(key)) { continue; }
            var input = $(key); if (!input) { continue; }
            var ctl = input.parentNode; if (!ctl || ctl.querySelector(".kf-key")) { continue; }
            var btn = document.createElement("button");
            btn.type = "button"; btn.className = "preview-key kf-key"; btn.title = "未K帧，点击添加关键帧";
            btn.setAttribute("data-kf", key);
            btn.addEventListener("click", function () { onKfClick(this.getAttribute("data-kf")); });
            ctl.insertBefore(btn, input);
        }
    }
    function updateParamKeyStates() {
        var ps = state.__paramStates || {};
        for (var key in KF_CONTROL_MAP) {
            if (!KF_CONTROL_MAP.hasOwnProperty(key)) { continue; }
            var btn = document.querySelector('.kf-key[data-kf="' + key + '"]'); if (!btn) { continue; }
            btn.style.display = state.batch ? "none" : "";
            btn.className = "preview-key kf-key";
            var p = ps[key];
            if (state.batch) { continue; }
            if (!p) { btn.classList.add("disabled"); btn.title = "请先应用生成该参数控件"; }
            else if (p.keyed) { btn.classList.add(p.atKeyframe ? "at-key" : "has-keys"); btn.title = p.atKeyframe ? "当前在关键帧上" : "已有关键帧（动画中）"; }
            else { btn.title = "未K帧，点击添加关键帧"; }
        }
    }
    function onKfClick(key) {
        if (state.batch || !state.selectedLayer) { return; }
        var p = (state.__paramStates || {})[key];
        if (!p) { setStatus("✗ 请先应用一次，生成该参数控件", "err"); return; }
        if (p.keyed) {
            // 已有关键帧时按钮不是「禁用」，而是不需要再打点：
            // 改数值/参数会自动在当前时间更新该帧，这里明确告诉用户，避免以为没反应。
            setStatus(p.atKeyframe ? "当前时间已在关键帧上：改数值会更新这一帧" : "该参数已有关键帧：改数值会在当前时间新增/更新关键帧", "ok");
            return;
        }
        evalScript("fuiKeyframeParam(" + JSON.stringify(state.selectedLayer) + "," + JSON.stringify(key) + ")", function () {
            pollValueState();
        });
    }
    function syncParamDirect(ev) {
        if (!state.batch && !state.selectedLayer) { return; }
        var id = ev && ev.target && ev.target.id; if (!id || !KF_CONTROL_MAP[id]) { return; }
        if (state.batch || !state.selectedLayer) { return; }
        var el = ev.target, val;
        if (el.type === "checkbox") { val = el.checked ? 1 : 0; }

        else if (id === "numColor") { val = el.value; }
        else { val = Number(el.value); if (el.value === "" || isNaN(val)) { return; } }
        evalScript("fuiSetParamDirect(" + JSON.stringify(state.selectedLayer) + "," + JSON.stringify(id) + "," + JSON.stringify(val) + ")", function () { pollValueState(); });
    }

    var lastSelKey = "";
    function notePanelInteraction() {
        panelActiveFlag = true;
        lastPanelInteraction = (new Date()).getTime();
        // 用户主动点/键进面板，说明他已经离开 AE 的文字编辑状态：
        // 解除焦点冲突的 5 分钟退避，让下一次检测重新尝试深读。
        if (typeof deepDetectBlockedUntil === "number" &&
            deepDetectBlockedUntil > (new Date()).getTime()) {
            deepDetectBlockedUntil = 0;   // 解除退避；下次检测再失败会重新计时
        }
    }
    function panelInteractionRecent() {
        return panelActiveFlag && ((new Date()).getTime() - lastPanelInteraction < 400);
    }
    function pollSelection() {
        if (typeof document !== "undefined" && document.hidden) { return; }
        // 只有面板最近真实交互过才允许 evalScript；AE 文本编辑期间绝不抢焦点
        if (!panelInteractionRecent()) { return; }
        evalScript("fuiGetSelection()", function (res) {
            var arr = null;
            try { arr = JSON.parse(res); } catch (e) { return; }
            if (!arr || !arr.length) {
                if (state.selectedLayer || (state.batchLayers && state.batchLayers.length)) {
                    state.selectedLayer = ""; state.batch = false; state.batchLayers = []; lastSelKey = "__none__";
                    batchDetections = []; batchMixed = {}; clearMixedIndicators();
                    var btn0 = $("btnApply"); if (btn0) { btn0.disabled = false; }
                    updateStatusLine(); clearDetection(); updatePreview();
                }
                return;
            }
            // 兼容 [{i,n}] 或 ["name"]；过滤掉前后缀辅助子层，避免其被当作目标
            var names = [], ids = [];
            for (var q = 0; q < arr.length; q++) {
                var o = arr[q];
                var nm = (o && typeof o === "object") ? (o.n || "") : String(o);
                if (/^FUI前缀|^FUI后缀|^FUI单位|^FUI宽度/.test(nm)) { continue; }
                names.push(nm); ids.push((o && typeof o === "object") ? (o.i !== undefined ? o.i : nm) : nm);
            }
            if (!names.length) {
                // 仅选中了前后缀辅助层：保持当前目标不变
                if (state.selectedLayer) { return; }
                return;
            }
            var key = names.join("|");
            if (key === lastSelKey) { return; }
            lastSelKey = key;
            if (names.length > 1) { state.batch = true; state.batchLayers = names.slice(); state.selectedLayer = names[0]; detectBatch(names); }
            else { state.batch = false; state.batchLayers = []; state.selectedLayer = names[0]; detectSpecific(names[0]); }
            syncBatchUI();
            updateStatusLine();
        });
    }
    /* 深检测的安全开关：AE 在编辑文字时读 Source Text 会触发 76=59（抢焦点）。
     * 默认允许深检测（这样选中图层就能准确回填）；一旦真的撞上焦点错误，
     * 自动退避 5 分钟、退回「只读标记」的安全模式，并在日志里说明原因。 */
    var deepDetectBlockedUntil = 0;
    function deepDetectAllowed() {
        return ((new Date()).getTime() >= deepDetectBlockedUntil);
    }
    function isFocusError(msg) {
        var s = String(msg || "");
        return /focus on ourselves|76\s*=\s*59|76=59/i.test(s);
    }
    /* 选区监视：只读「选了哪些图层」（不碰 Source Text，安全），
     * 一旦选区变化再做一次深检测回填参数。这样在 AE 里换图层后，
     * 面板不需要点任何按钮就会跟上；打字不会改变选区，因此不会在编辑文字时反复读文本。 */
    var selWatchTimer = null, selWatchKey = "";
    function startSelectionWatch() {
        if (selWatchTimer) { return; }
        selWatchTimer = setInterval(function () {
            try {
                if (document.hidden) { return; }
                if (panelInteractionRecent()) { return; }   // 刚才有面板交互，走即时路径即可
                evalScript("fuiGetSelection()", function (res) {
                    var arr = null;
                    try { arr = JSON.parse(res); } catch (e) { return; }
                    if (!arr || !arr.length) { return; }
                    var names = [];
                    for (var i = 0; i < arr.length; i++) {
                        var o = arr[i];
                        var nm = (o && typeof o === "object") ? String(o.n || "") : String(o);
                        if (!nm) { continue; }
                        if (/^FUI前缀|^FUI后缀|^FUI单位|^FUI宽度/.test(nm)) { continue; }
                        names.push(nm);
                    }
                    if (!names.length) { return; }
                    var key = names.join("|");
                    if (key === selWatchKey) { return; }
                    selWatchKey = key;
                    if (names.length > 1) {
                        state.batch = true; state.batchLayers = names.slice(); state.selectedLayer = names[0];
                        detectBatch(names);
                    } else {
                        state.batch = false; state.batchLayers = []; state.selectedLayer = names[0];
                        detectSpecific(names[0]);
                    }
                    syncBatchUI();
                    updateStatusLine();
                });
            } catch (eWatch) { }
        }, 450);
    }

    function detectSpecific(name) {
        if (!name) { return; }
        batchDetections = []; batchMixed = {}; clearMixedIndicators();
        var deep = deepDetectAllowed();
        evalScript("JSON.stringify(fuiDetectLayer(" + JSON.stringify(name) + ", " + (deep ? "true" : "false") + "))", function (res) {
            var r = null;
            try { r = JSON.parse(res); } catch (e) { r = null; }
            if (!r) { log("检测返回异常：" + short(res), "err"); return; }
            if (deep && isFocusError((r.errors || []).join("；"))) {
                deepDetectBlockedUntil = (new Date()).getTime() + 5 * 60 * 1000;
                log("检测遇到 AE 文字编辑焦点冲突，已退回只读模式（5 分钟内不再读文字）；结束后点一下面板即可恢复", "warn");
                detectSpecific(name);
                return;
            }
            if (r.ok) { applyDetection(r); }
        });
    }

    /* ---------- 多选批量：逐层检测 + 混合值 ---------- */
    var BATCH_FIELD_IDS = {
        typeId: "typeSelect", unitId: "unitSelect", decimals: "decimals", padding: "padding",
        prefixSpace: "prefixSpace", unitSpace: "unitSpace", suffixSpace: "suffixSpace",
        thousands: "thousands", prefix: "prefix", suffix: "suffix", align: "align",
        tracking: "tracking", numColor: "numColor", forceSign: "signMode",
        rangeMin: "rangeMin", rangeMax: "rangeMax", allowNegative: "allowNegative", clamp: "clamp",
        decimalChar: "decimalChar", timerMs: "timerMs", timerMode: "timerMode",
        rate: "rate", rmbUppercase: "rmbUppercase", hemisphere: "hemisphere", anchor: "anchorGrid",
        affixFont: "affixFont", affixFontSize: "affixFontSize"
    };
    function batchRgbToHex(rgb) {
        if (!rgb || rgb.length < 3) { return "#ffffff"; }
        var hx = "#";
        for (var i = 0; i < 3; i++) { var v = Math.max(0, Math.min(255, Math.round(Number(rgb[i]) * 255))).toString(16); if (v.length < 2) { v = "0" + v; } hx += v; }
        return hx;
    }
    function deriveLayerState(r) {
        // plainText 只代表「没读到本工具的类型标记」，不能用来覆盖用户当前选择的类型
        var sug = (r && r.suggestedType) ? String(r.suggestedType) : "";
        if (sug === "plainText") { sug = ""; }
        // 批量里 state.typeId 可能是 "__mixed__"，不能拿它当回退值，否则单位/专属参数判定全部失效
        var fallbackId = (state.typeId && state.typeId !== "__mixed__" && getRegistry()[state.typeId]) ? state.typeId : "generic";
        var tId = (sug && getRegistry()[sug]) ? sug : fallbackId;
        var t = getType(tId) || {};
        var units = isArray(t.units) ? t.units : [];
        var pu = r ? (r.parsedUnit || r.unitLabel || "") : "";
        var uid = "";
        for (var i = 0; i < units.length; i++) { if (units[i].id === pu || units[i].label === pu) { uid = units[i].id; break; } }
        if (!uid) { uid = t.baseUnit || (units[0] ? units[0].id : ""); }
        var cc = (r && r.controls) ? r.controls : {};
        function cv(k, d) { return cc[k] !== undefined ? cc[k] : d; }
        return {
            typeId: tId, unitId: uid,
            decimals: cv("decimals", (t.decimals !== undefined ? t.decimals : 2)),
            padding: cv("padding", 0), prefixSpace: cv("prefixSpace", 0), unitSpace: cv("unitSpace", 0), suffixSpace: cv("suffixSpace", 0),
            thousands: cv("thousands", !!t.thousands),
            prefix: (r && r.prefix !== undefined) ? r.prefix : (t.prefix || ""),
            suffix: (r && r.suffix !== undefined) ? r.suffix : (t.suffix || ""),
            align: (r && r.align) ? r.align : "",
            tracking: (r && r.tracking !== undefined) ? r.tracking : "",
            numColor: (r && r.fillColor) ? batchRgbToHex(r.fillColor) : "#ffffff",
            forceSign: !!(r && r.forceSign)
        };
    }
    function detectBatch(names) {
        var token = ++batchDetectToken;
        // 一次 evalScript 批量检测所有层，减少多次宿主往返
        var deepB = deepDetectAllowed();
        evalScript("fuiDetectLayers(" + JSON.stringify(JSON.stringify(names)) + ", " + (deepB ? "true" : "false") + ")", function (res) {
            var s = null; try { s = JSON.parse(res); } catch (e) { s = null; }
            if (!s || !s.items || token !== batchDetectToken) { return; }
            var errText = "";
            for (var bi = 0; bi < s.items.length; bi++) { errText += ((s.items[bi] && s.items[bi].errors) || []).join("；"); }
            if (deepB && isFocusError(errText)) {
                deepDetectBlockedUntil = (new Date()).getTime() + 5 * 60 * 1000;
                log("批量检测遇到 AE 文字编辑焦点冲突，已退回只读模式（5 分钟）", "warn");
                detectBatch(names);
                return;
            }
            applyBatchDetection(names, s.items);
        });
    }
    function applyBatchDetection(names, dets) {
        // 非文字图层直接剔除：批量只写文字层
        var valid = [], validNames = [], skipped = 0;
        for (var i = 0; i < dets.length; i++) {
            if (dets[i] && dets[i].ok !== false && dets[i].isText !== false) { valid.push(dets[i]); validNames.push(names[i]); }
            else if (dets[i]) { skipped++; }
        }
        if (skipped) { log("批量：已忽略 " + skipped + " 个非文字图层", "warn"); }
        if (!valid.length) {
            // 全选中的都不是文字图层：明确告诉用户，别留上一批的旧读数
            state.batch = false; state.batchLayers = []; state.__isText = false;
            batchDetections = [];
            log("批量：所选 " + dets.length + " 层都不是文字图层，无法挂数据", "err");
            updatePreview(); syncBatchUI(); updateStatusLine();
            return;
        }
        if (valid.length === 1) {
            // 多选里只剩一个文字层 → 退回单层模式
            state.batch = false; state.batchLayers = [];
            applyDetection(valid[0]);
            return;
        }
        batchDetections = valid; state.batch = true; state.batchLayers = validNames; state.selectedLayer = validNames[0];
        state.__batchDirty = {};
        var dsList = [];
        for (var j = 0; j < valid.length; j++) { dsList.push(deriveLayerState(valid[j])); }
        var layersForPlan = [];
        for (var li = 0; li < dsList.length; li++) {
            layersForPlan.push({ typeId: dsList[li].typeId, unitId: dsList[li].unitId, params: dsList[li] });
        }
        var plan = null;
        try { plan = FUI_BATCH.plan(layersForPlan, getRegistry()); } catch (ePlan) { plan = null; log("批量判定失败：" + ePlan, "err"); }
        state.__batchPlan = plan;
        state.__batchNote = plan ? plan.note : "";
        state.__batchFallbackType = dsList[0].typeId;
        clearMixedIndicators();
        batchMixed = {};
        // 界面值：一致就显示那个值，不一致就显示「多值」
        var allKeys = FUI_BATCH.KEYS;
        for (var k = 0; k < allKeys.length; k++) {
            var key = allKeys[k], ent = plan ? plan.keys[key] : null;
            if (!ent || ent.status !== "all") { continue; }
            if (ent.mixed) { batchMixed[key] = true; }
            else if (ent.value !== undefined) { state[key] = ent.value; }
        }
        if (plan && plan.sameType) { state.typeId = plan.typeId; }
        else { state.typeId = "__mixed__"; batchMixed.typeId = true; batchMixed.unitId = true; }
        if (plan && plan.sameUnit && plan.unitId) { state.unitId = plan.unitId; }
        state.__isText = true; state.__isNumeric = true;
        fillTypeSelect(); fillUnitSelect(); syncControls(); updateConditionalBlocks(); updatePreview(); syncBatchUI();
        applyBatchMarks();
        updateStatusLine();
    }
    /* 批量标记（多值 / 被锁）会被后续的 syncControls / updateConditionalBlocks 重置，
     * 所以统一成一个幂等函数，每次条件块刷新后重新盖上去。 */
    function applyBatchMarks() {
        if (!state.batch || !state.__batchPlan) { return; }
        var plan = state.__batchPlan;
        for (var key in batchMixed) {
            if (batchMixed.hasOwnProperty(key) && BATCH_FIELD_IDS[key]) { markMixed(key, BATCH_FIELD_IDS[key]); }
        }
        if (plan.blockedKeys) {
            for (var i = 0; i < plan.blockedKeys.length; i++) {
                var bk = plan.blockedKeys[i];
                if (BATCH_FIELD_IDS[bk]) { markBlocked(bk, BATCH_FIELD_IDS[bk], plan.keys[bk] && plan.keys[bk].blockedReason); }
            }
        }
    }
    function clearMixedIndicators() {
        for (var key in BATCH_FIELD_IDS) {
            if (!BATCH_FIELD_IDS.hasOwnProperty(key)) { continue; }
            var el = $(BATCH_FIELD_IDS[key]); if (!el) { continue; }
            el.classList.remove("mixed");
            if (el.classList.contains("blocked")) {
                el.classList.remove("blocked");
                el.title = "";
                if (el.tagName === "SELECT" || el.tagName === "INPUT" || el.tagName === "BUTTON") { el.disabled = false; }
                if (el.classList.contains("anchor-grid")) {
                    var cells = el.querySelectorAll(".anchor-cell");
                    for (var ci = 0; ci < cells.length; ci++) { cells[ci].disabled = false; }
                }
            }
            if (el.tagName === "SELECT") {
                var op = el.querySelector('option[value="__mixed__"]'); if (op && op.parentNode) { op.parentNode.removeChild(op); }
                el.disabled = false;
            } else if (el.type === "checkbox") { el.indeterminate = false; }
            else if (el.type === "color") { el.title = ""; }
            else { if (el.getAttribute("data-orig-ph") !== null) { el.placeholder = el.getAttribute("data-orig-ph"); } else if (el.placeholder === "— 多值") { el.placeholder = ""; } }
        }
    }
    /* 类型不同导致某参数无法统一：置灰禁用，并给出原因。
     * 注意锚点九宫格是容器，要禁用的是里面的按钮。 */
    function markBlocked(key, id, reason) {
        var el = $(id); if (!el) { return; }
        el.classList.add("blocked");
        el.title = reason || "该参数在当前所选类型下不可统一";
        if (el.classList && el.classList.contains("anchor-grid")) {
            var cells = el.querySelectorAll(".anchor-cell");
            for (var i = 0; i < cells.length; i++) { cells[i].disabled = true; }
        } else if (el.tagName === "SELECT" || el.tagName === "INPUT" || el.tagName === "BUTTON") {
            el.disabled = true;
        }
    }
    function markMixed(key, id) {
        var el = $(id); if (!el) { return; }
        el.classList.add("mixed");
        if (el.tagName === "SELECT") {
            var op = el.querySelector('option[value="__mixed__"]');
            if (!op) { op = document.createElement("option"); op.value = "__mixed__"; op.textContent = "— 多值"; el.insertBefore(op, el.firstChild); }
            el.value = "__mixed__";
        } else if (el.type === "checkbox") { el.indeterminate = true; }
        else if (el.type === "color") { el.title = "— 多值"; }
        else { if (!el.getAttribute("data-orig-ph")) { el.setAttribute("data-orig-ph", el.placeholder || ""); } el.value = ""; el.placeholder = "— 多值"; }
    }
    function markBatchDirty(ev) {
        if (!state.batch || !batchDetections.length) { return; }
        var id = ev && ev.target && ev.target.id; if (!id) { return; }
        for (var key in BATCH_FIELD_IDS) {
            if (!BATCH_FIELD_IDS.hasOwnProperty(key) || BATCH_FIELD_IDS[key] !== id) { continue; }
            state.__batchDirty = state.__batchDirty || {};
            state.__batchDirty[key] = true;
            // 用户改过的参数不再是「多值」，把标记摘掉，否则下一次刷新又会被清空
            if (batchMixed[key]) { delete batchMixed[key]; }
            var el = $(id);
            if (el) {
                el.classList.remove("mixed");
                if (el.getAttribute && el.getAttribute("data-orig-ph") !== null) { el.placeholder = el.getAttribute("data-orig-ph"); }
                else if (el.placeholder === "— 多值") { el.placeholder = ""; }
            }
            // 改类型 = 整批统一成该类型：单位、被锁参数全部重新判定，先解除旧标记
            if (key === "typeId") {
                var kk;
                for (kk in batchMixed) { if (batchMixed.hasOwnProperty(kk)) { delete batchMixed[kk]; } }
                if (state.__batchPlan) { state.__batchPlan.blockedKeys = []; }
                clearMixedIndicators();
            }
            break;
        }
    }

    /* ================= 应用 ================= */
    var statusTimer = null;
    function setStatus(msg, kind) {
        var el = $("applyStatus");
        if (!el) { return; }
        var txt = $("applyStatusText");
        if (txt) { txt.textContent = msg || ""; } else { el.textContent = msg || ""; }
        el.className = "apply-status " + (kind || "");
        el.style.display = msg ? "block" : "none";
        if (statusTimer) { clearTimeout(statusTimer); }
        if (msg) { statusTimer = setTimeout(function () { el.style.display = "none"; }, 6000); }
    }
    /* 恢复当前数据类型的默认值（间距一律 0） */
    function resetToDefaults() {
        var t = state.typeId || "generic";
        var keepSel = state.selectedLayer, keepBatch = state.batch, keepLayers = (state.batchLayers || []).slice();
        // 运行态（图层是否已应用、当前值、K 帧状态）不是「参数」，重置时必须保留，
        // 否则重置一次就把预览值、计时输入和 K 帧圆点全清掉，看起来像图层被改回去了。
        var keepRuntime = {
            __liveValue: state.__liveValue,
            __hasValueControl: state.__hasValueControl,
            __valueKeyed: state.__valueKeyed,
            __atKeyframe: state.__atKeyframe,
            __paramStates: state.__paramStates,
            __detectedLayer: state.__detectedLayer,
            __layerText: state.__layerText,
            __layerFontSize: state.__layerFontSize,
            __layerFontName: state.__layerFontName,
            __isText: state.__isText
        };
        state = FUI.defaultDataState();
        for (var rk in keepRuntime) { if (keepRuntime.hasOwnProperty(rk)) { state[rk] = keepRuntime[rk]; } }
        applyTypeDefaults(t);
        state.__unitSpaceTouched = false;
        state.unitSpace = unitSpaceDefault();
        state.prefixSpace = 0; state.suffixSpace = 0;
        state.selectedLayer = keepSel; state.batch = keepBatch; state.batchLayers = keepLayers;
        fillTypeSelect(); fillUnitSelect(); syncControls(); updateConditionalBlocks();
        updateStatusLine(); updatePreview();
        var lbl = (getType(t) || {}).label || t;
        setStatus("已恢复默认值：" + lbl, "ok");
        log("已恢复默认值：" + lbl, "ok");
        scheduleLive();
    }

    function doApply(silent) {
        // 纯文本只读：没有锚点时不写图层；有锚点时仅允许设置锚点/位置
        if (state.typeId === "plainText" && !state.anchor) {
            if (!silent) { setStatus("纯文本：只读，不修改图层", "ok"); }
            return;
        }
        // 双击/延时应用绝不跨到 AE 文本编辑：执行前再确认面板仍在前台
        try { if (!panelActiveFlag) { log("应用被跳过：面板不在前台（先把 AE 焦点切回面板）", "warn"); return; } } catch (eApplyFocus) { return; }
        if (!panelInteractionRecent()) { log("应用被跳过：距上次面板操作超过 0.4 秒，请再点一次【应用】", "warn"); return; }
        if ((!state.batch && !state.selectedLayer) || (state.batch && (!state.batchLayers || !state.batchLayers.length))) {
            if (!silent) { setStatus("✗ 请先在 AE 里选中一个图层（可多选批量）", "err"); }
            log("未选中图层：请先在 AE 中选中文字图层", "err");
            return;
        }
        if (state.__isText === false) {
            if (!silent) { setStatus("✗ 当前图层不是文字图层，请选择文字图层", "err"); }
            log("当前图层不是文字图层", "err");
            return;
        }
        var v = FUI.validateDataState(state);
        if (!v.ok) { if (!silent) { setStatus("✗ " + v.errors.join("；"), "err"); } log("校验失败：" + v.errors.join("；"), "err"); return; }
        if (state.batch) {
            if (batchDetections.length === state.batchLayers.length && batchDetections.length > 0) { doBatchApply(silent); }
            else { setStatus("✗ 批量检测尚未完成，请稍后再点应用", "err"); }
            return;
        }
        var options = FUI.buildApplyOptions(state, getType(state.typeId));
        var layerArg;
        if (state.batch) { layerArg = JSON.stringify(state.batchLayers); }
        else { layerArg = JSON.stringify(state.selectedLayer || ""); }
        var cmd = "JSON.stringify(fuiApplyData(" + layerArg + ", " + JSON.stringify(state.typeId) + ", " + JSON.stringify(options) + "))";
        var t = getType(state.typeId);
        log("应用数据（" + (state.batch ? state.batchLayers.length + " 层批量" : (state.selectedLayer || "当前选中")) +
            " · " + ((t && t.label) ? t.label : state.typeId) + "）");
        evalScript(cmd, function (res) {
            var r = parseHostResult(res);
            if (!r) { setStatus("✗ 应用返回异常", "err"); log("应用返回异常: " + short(res), "err"); return; }
            var er = r.errors || [];
            if (r.ok) { if (!silent) { setStatus("✓ 应用成功，共 " + ((r.applied ? r.applied.length : 0)) + " 项", "ok"); } log("应用完成：applied " + (r.applied ? r.applied.length : 0) + " 项", "ok"); }
            else { setStatus("✗ 应用失败：" + humanizeLicenseError(er[0] || "见日志"), "err"); log("应用未完成", "err"); }
            var ap = r.applied || [];
            for (var i = 0; i < ap.length; i++) { log("  ✓ " + ap[i], "ok"); }
            for (var j = 0; j < er.length; j++) { log("  ✗ " + er[j], "err"); }
        });
    }

    function onApply() {
        // 用户点了按钮就算一次交互：否则「按住按钮 >0.4 秒再松开」会被 doApply 的前台守卫挡掉、毫无反馈
        if (typeof notePanelInteraction === "function") { notePanelInteraction(); }
        doApply(false);
    }

    /* 多选批量：每层独立 options；未改动且混合的参数保留该层原值 */
    function doBatchApply(silent) {
        // 逐层合并：用户改过的参数（dirty）统一写入；没改的按该层自己的检测值保留。
        // 具体规则在 batch_plan.js 的 merge() 里，可被 Node 测试覆盖。
        var items = [];
        var dirty = state.__batchDirty || {};
        var plan = state.__batchPlan || null;
        for (var i = 0; i < state.batchLayers.length; i++) {
            var r = batchDetections[i]; if (!r || r.ok === false) { continue; }
            var ds = deriveLayerState(r);
            var layerState = { typeId: ds.typeId, unitId: ds.unitId, params: ds };
            var merged = FUI_BATCH.merge(layerState, state, dirty, plan, getRegistry());
            var opt = FUI.buildApplyOptions(merged, getType(merged.typeId));
            items.push({ name: state.batchLayers[i], type: merged.typeId, options: opt });
        }
        if (!items.length) { setStatus("✗ 批量应用没有有效图层", "err"); return; }
        var itemsJson = JSON.stringify(items);
        var cmd = "JSON.stringify(fuiApplyBatch(" + JSON.stringify(itemsJson) + "))";
        log("批量应用（按层保留未修改的参数，共 " + items.length + " 层）");
        evalScript(cmd, function (res) {
            var r = parseHostResult(res);
            if (!r) { setStatus("✗ 批量应用返回异常", "err"); log("批量应用返回异常: " + short(res), "err"); return; }
            var er = r.errors || [];
            if (r.ok) { if (!silent) { setStatus("✓ 批量应用成功，共 " + (r.applied ? r.applied.length : 0) + " 项", "ok"); } log("批量应用完成", "ok"); }
            else {
                var first = humanizeLicenseError(er[0] || "见日志");
                setStatus("✗ 批量应用失败：" + first, "err");
                log("批量应用未完成", "err");
            }
            for (var j = 0; j < (r.applied || []).length; j++) { log("  ✓ " + r.applied[j], "ok"); }
            for (var k = 0; k < er.length; k++) { log("  ✗ " + humanizeLicenseError(er[k]), "err"); }
            // 应用后重新检测一遍：面板显示的各层参数要与图层真实状态一致（刚统一的值不该还标「多值」）
            if (r.ok) { state.__batchDirty = {}; if (state.batch && state.batchLayers.length) { detectBatch(state.batchLayers.slice(0)); } }
        });
    }

    var liveMode = true;  // 实时写入常开：选中图层后改参数即自动应用（不再提供开关）
    var liveTimer = null;
    function scheduleLive() {
        if (!panelInteractionRecent()) { return; }
        if (!state.selectedLayer && !(state.batch && state.batchLayers && state.batchLayers.length)) { return; }
        if (state.__isText === false) { return; }
        if (liveTimer) { clearTimeout(liveTimer); }
        liveTimer = setTimeout(function () { liveTimer = null; doApply(true); }, 260);
    }

    /* ================= 事件绑定 ================= */
    function bindEvents() {
        $("btnRefreshLayers").addEventListener("click", function () { refreshLayers(true); });
        $("btnApply").addEventListener("click", onApply);
        $("btnClearLog").addEventListener("click", function () { $("log").innerHTML = ""; });
        var btnResetEl = $("btnReset");
        if (btnResetEl) { btnResetEl.addEventListener("click", resetToDefaults); }
        // 版权链接：用系统浏览器打开 cgartlab.com
        var extLinks = document.querySelectorAll('a[data-ext-url]');
        for (var li = 0; li < extLinks.length; li++) {
            extLinks[li].addEventListener("click", function (ev) {
                ev.preventDefault();
                var url = this.getAttribute("data-ext-url");
                try { if (csInterface && csInterface.openURLInDefaultBrowser) { csInterface.openURLInDefaultBrowser(url); return; } } catch (eUrl) { }
                try { window.open(url, "_blank"); } catch (eUrl2) { }
            });
        }
        // 预览数值直接编辑 + 秒表 K 帧
        var pe = $("previewEdit");
        if (pe) {
            pe.addEventListener("focus", function () { previewEditing = true; });
            pe.addEventListener("input", function () {
                if (state.typeId !== "plainText" || !state.selectedLayer || state.batch) { return; }
                var self = this;
                if (previewInputTimer) { clearTimeout(previewInputTimer); }
                previewInputTimer = setTimeout(function () { commitPreviewValue(self.innerText || self.textContent); }, 220);
            });
            pe.addEventListener("blur", function () {
                if (previewInputTimer) { clearTimeout(previewInputTimer); previewInputTimer = null; }
                previewEditing = false;
                commitPreviewValue(this.innerText || this.textContent);
            });
            pe.addEventListener("keydown", function (e) { if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); this.blur(); } });
        }
        var pk = $("previewKey");
        if (pk) {
            pk.addEventListener("click", function () {
                if (state.batch || !state.selectedLayer) { return; }
                evalScript("JSON.stringify(fuiKeyframeValue(" + JSON.stringify(state.selectedLayer) + "))", function (res) {
                    var r = parseHostResult(res);
                    if (r && r.ok) { setStatus(r.atKeyframe ? "✓ 已在当前时间打点（该帧已存在，已更新）" : "✓ 已在当前时间打点", "ok"); }
                    else if (r && r.errors && r.errors.length) { setStatus("✗ 打点失败：" + humanizeLicenseError(r.errors[0]), "err"); }
                    pollValueState(); updatePreview();
                });
            });
        }

        $("layerSelect").addEventListener("change", function () {
            state.selectedLayer = this.value;
            updateStatusLine();
            detectSpecific(this.value);
        });

        $("typeSelect").addEventListener("change", function () {
            applyTypeDefaults(this.value);
            fillUnitSelect();
            syncControls();

            updateConditionalBlocks();
            if (this.value === "plainText" && state.selectedLayer && !state.batch) {
                // 纯文本只读：不做任何写回
                setStatus("纯文本：只读，不修改图层", "ok");
            }
        });
        $("unitSelect").addEventListener("change", function () {
            state.unitId = this.value;
            if (!state.__unitSpaceTouched) { state.unitSpace = unitSpaceDefault(); syncControls(); }
        });

        $("decimals").addEventListener("input", function () { var n = Number(this.value); if (isNaN(n)) { n = 0; } n = Math.max(0, Math.min(10, Math.round(n))); this.value = n; state.decimals = n; updateConditionalBlocks(); });
        var padB = $("padding"); if (padB) { padB.addEventListener("input", function () { var n = Number(this.value); if (isNaN(n)) { n = 0; } n = Math.max(0, Math.min(12, Math.round(n))); this.value = n; state.padding = n; }); }
        var trB = $("tracking"); if (trB) { trB.addEventListener("input", function () { var n = Number(this.value); state.tracking = (this.value === "" || isNaN(n)) ? "" : Math.max(-1000, Math.min(1000, Math.round(n))); updatePreview(); }); }
        var dcB = $("decimalChar"); if (dcB) { dcB.addEventListener("change", function () { state.decimalChar = this.value; updatePreview(); }); }
        var alB = $("align"); if (alB) { alB.addEventListener("change", function () { state.align = this.value; updatePreview(); }); }
        var afsB = $("affixFontSize"); if (afsB) { afsB.addEventListener("input", function () { var n = Number(this.value); state.affixFontSize = (this.value === "" || isNaN(n)) ? "" : n; }); }
        var afFontB = $("affixFont"); if (afFontB) { afFontB.addEventListener("input", function () { state.affixFont = this.value; }); }
        var ncEl = $("numColor"); if (ncEl) { ncEl.addEventListener("input", function () { state.numColor = this.value; state.useColor = true; updatePreview(); }); }
        var cells = document.querySelectorAll('.anchor-cell');
        for (var ai = 0; ai < cells.length; ai++) {
            (function (c) {
                c.addEventListener("click", function () { var k = c.getAttribute("data-anchor"); state.anchor = (state.anchor === k) ? "" : k; if (state.batch) { state.__batchDirty = state.__batchDirty || {}; state.__batchDirty.anchor = true; } renderAnchor(); if (state.typeId === "plainText" && state.selectedLayer) { setTimeout(function () { doApply(true); }, 0); } });
            })(cells[ai]);
        }
        $("thousands").addEventListener("change", function () { state.thousands = this.checked; });
        var smB = $("signMode"); if (smB) { smB.addEventListener("change", function () { state.forceSign = (this.value === "plusminus"); }); }
        var heB = $("hemisphere"); if (heB) { heB.addEventListener("change", function () { state.hemisphere = this.value; }); }
        var tmB2 = $("timerMs"); if (tmB2) { tmB2.addEventListener("change", function () { state.timerMs = this.checked; }); }
        var tiB = $("timerInput");
        if (tiB) {
            tiB.addEventListener("change", commitTimerInput);
            tiB.addEventListener("keydown", function (e) { if (e.key === "Enter") { e.preventDefault(); this.blur(); } });
        }
        var anB = $("allowNegative"); if (anB) { anB.addEventListener("change", function () { state.allowNegative = this.checked; }); }
        var rmB = $("rangeMin"); if (rmB) { rmB.addEventListener("input", function () { state.rangeMin = this.value; }); }
        var rxB = $("rangeMax"); if (rxB) { rxB.addEventListener("input", function () { state.rangeMax = this.value; }); }
        var clB = $("clamp"); if (clB) { clB.addEventListener("change", function () { state.clamp = this.checked; }); }
        $("prefix").addEventListener("input", function () { state.prefix = this.value; updateAffixAvailability(); });
        $("suffix").addEventListener("input", function () { state.suffix = this.value; updateAffixAvailability(); });
        $("prefixSpace").addEventListener("input", function () {
            var n = Number(this.value); if (isNaN(n)) { n = 0; } n = Math.max(0, Math.min(20, Math.round(n)));
            this.value = n; state.prefixSpace = n; state.__unitSpaceTouched = state.__unitSpaceTouched; updatePreview();
        });
        $("unitSpace").addEventListener("input", function () {
            var n = Number(this.value); if (isNaN(n)) { n = 0; } n = Math.max(0, Math.min(20, Math.round(n)));
            this.value = n; state.unitSpace = n; state.__unitSpaceTouched = true; updatePreview();
        });
        $("suffixSpace").addEventListener("input", function () {
            var n = Number(this.value); if (isNaN(n)) { n = 0; } n = Math.max(0, Math.min(20, Math.round(n)));
            this.value = n; state.suffixSpace = n; updatePreview();
        });
        $("behavior").addEventListener("change", function () { state.behavior = this.value; updateConditionalBlocks(); });
        $("rate").addEventListener("input", function () { var n = Number(this.value); state.rate = isNaN(n) ? 1 : n; });
        $("rmbUppercase").addEventListener("change", function () { state.rmbUppercase = this.checked; updateConditionalBlocks(); });
        // 实时：控件改动/点选即防抖自动应用到图层（无需点“应用”）
        var cfgEl = $("configSection");
        if (cfgEl) {
            cfgEl.addEventListener("input", scheduleLive);
            cfgEl.addEventListener("change", scheduleLive);
            cfgEl.addEventListener("input", markBatchDirty);
            cfgEl.addEventListener("change", markBatchDirty);
            cfgEl.addEventListener("input", syncParamDirect);
            cfgEl.addEventListener("change", syncParamDirect);
            cfgEl.addEventListener("click", function (e) {
                var tg = e.target;
                if (tg && tg.classList && tg.classList.contains("anchor-cell")) { scheduleLive(); }
            });
        }
        // 日志显示/隐藏
        var logBtn = $("btnToggleLog");
        if (logBtn) {
            var lh = false; try { lh = (localStorage.getItem("fui_log_hidden") === "1"); } catch (eL) { lh = false; }
            setLogHidden(lh);
            logBtn.addEventListener("click", function () {
                var cur = false; try { cur = (localStorage.getItem("fui_log_hidden") === "1"); } catch (eL2) { }
                setLogHidden(!cur);
            });
        }
                // 悬浮通知关闭
        var asc = $("applyStatusClose"); if (asc) { asc.addEventListener("click", function () { setStatus("", ""); }); }
        var cfgSec = $("configSection");
        if (cfgSec) { cfgSec.addEventListener("input", updatePreview); cfgSec.addEventListener("change", updatePreview); }
    }

    /* 板块折叠：点标题展开/收起（键盘可操作 + aria + localStorage 记忆） */
    function bindAccordion() {
        var saved = {};
        try { saved = JSON.parse(localStorage.getItem("fui_collapsed") || "{}") || {}; } catch (e) { saved = {}; }
        function toggle(h) {
            var s = h.parentNode; if (!s || !s.classList) { return; }
            if (s.classList.contains('collapsed')) { s.classList.remove('collapsed'); } else { s.classList.add('collapsed'); }
            h.setAttribute('aria-expanded', s.classList.contains('collapsed') ? 'false' : 'true');
            saveCollapsedState();
        }
        var heads = document.querySelectorAll('.section > .section-head');
        for (var i = 0; i < heads.length; i++) {
            (function (h) {
                h.setAttribute('role', 'button'); h.setAttribute('tabindex', '0');
                h.addEventListener('click', function (e) {
                    if (e.target && e.target.closest && e.target.closest('button')) { return; }
                    toggle(h);
                });
                h.addEventListener('keydown', function (e) {
                    if (e.key === 'Enter' || e.key === ' ' || e.key === 'Spacebar') { e.preventDefault(); toggle(h); }
                });
            })(heads[i]);
        }
        var secs = document.querySelectorAll('.section');
        for (var s2 = 0; s2 < secs.length; s2++) {
            if (secs[s2].id && saved[secs[s2].id]) { secs[s2].classList.add('collapsed'); }
            var hh = secs[s2].querySelector('.section-head');
            if (hh) { hh.setAttribute('aria-expanded', secs[s2].classList.contains('collapsed') ? 'false' : 'true'); }
        }
    }
    function saveCollapsedState() {
        try {
            var o = {};
            var secs = document.querySelectorAll('.section');
            for (var i = 0; i < secs.length; i++) { if (secs[i].id && secs[i].classList.contains('collapsed')) { o[secs[i].id] = 1; } }
            localStorage.setItem("fui_collapsed", JSON.stringify(o));
        } catch (e) { }
    }

    /* ================= 启动 ================= */
    function init() {
        // 注册表真源：优先 format_core.js（浏览器内加载的 FUIFormatCore），否则用 config_builder 内置兜底
        if (window.FUIFormatCore && window.FUIFormatCore.REGISTRY) {
            registry = window.FUIFormatCore.REGISTRY;
        }
        state = FUI.defaultDataState();
        var btnA0 = $("btnApply"); if (btnA0) { btnA0.disabled = false; }
        applyTypeDefaults(state.typeId);
        fillTypeSelect();
        fillUnitSelect();
        syncControls();

        updateConditionalBlocks();
        clearDetection();
        setupKfIcons();
        // 回到面板时恢复轮询/检测（AE 文本编辑期间焦点在 AE，不执行脚本）
        window.addEventListener("blur", function () { panelActiveFlag = false; lastPanelInteraction = 0; });
        window.addEventListener("focus", function () { notePanelInteraction(); lastSelKey = ""; pollSelection(); pollValueState(); });
        // 点击/按键落在面板上时明确恢复前台标志（兼容部分 CEP 焦点事件不完整的环境）
        document.addEventListener("mousedown", function () {
            notePanelInteraction();
            setTimeout(function () { pollSelection(); pollValueState(); }, 0);
        }, true);
        var lastKeyPoll = 0;
        document.addEventListener("keydown", function () {
            notePanelInteraction();
            var now = (new Date()).getTime();
            if (now - lastKeyPoll < 150) { return; }   // 连续输入时不要每键都打宿主脚本
            lastKeyPoll = now;
            setTimeout(function () { pollSelection(); pollValueState(); }, 0);
        }, true);
        document.addEventListener("input", function () { notePanelInteraction(); }, true);
        // 预览数值/关键帧状态只在面板交互时刷新，不做后台定时轮询（避免 AE 文本编辑期 evalScript 抢焦点）
        bindEvents();
        startSelectionWatch();
        startLiveValuePoll();
        bindAccordion();
        bindScrubbers();
        bindGroups();
        bindTooltips();
        if (csInterface) { pollSelection(); }
        updateStatusLine();
        log("FUI 数据图层控制器就绪");
        if (csInterface) { bootHostThenStart(); }
        // 兜底：即使 boot 的 evalScript 回调没回来，也在 1.5s 后确保 startData 执行（引擎加载由 boot 的 evalScript 在 AE 侧完成）
        if (csInterface) { setTimeout(function () { try { startData(); } catch (eFb) { } }, 1500); }
    }

    /* 面板每次加载都用扩展自身路径重新求值宿主 JSX：刷新引擎、清除可能的失败缓存、避免陈旧 JSX */
    function _fuiExtDir() {
        var ext = "";
        try { if (csInterface && csInterface.getSystemPath && typeof SystemPath !== "undefined") { ext = String(csInterface.getSystemPath(SystemPath.EXTENSION) || ""); } } catch (e) { ext = ""; }
        if (!ext) {
            try { ext = decodeURI(String(window.location.href)).replace(/^file:\/\/\//, "").replace(/\/index\.html.*$/, ""); } catch (e2) { ext = ""; }
        }
        return String(ext).replace(/\\/g, "/");
    }
    function bootHostThenStart() {
        // 用绝对路径 evalFile 宿主 + 显式设置 jsx 目录 + 加载引擎，规避 CEP 自动加载时 $.fileName 不可靠的问题
        var extF = _fuiExtDir();
        if (!extF) { startData(); return; }
        var hostFile = extF + "/jsx/fui_panel_host.jsx";
        var jsxDir = extF + "/jsx";
        var sc = "(function(){try{$.evalFile(new File(\"" + hostFile + "\"));}catch(eL){} try{if(typeof fuiPanelSetHostDir===\"function\"){fuiPanelSetHostDir(\"" + jsxDir + "\");}}catch(eD){} try{if(typeof fuiPanelLoadDataEngine===\"function\"){fuiPanelLoadDataEngine();}}catch(eE){} return \"booted\";})()";
        try {
            csInterface.evalScript(sc, function () { startData(); });
            return;
        } catch (e0) { }
        startData();
    }
    var __fuiDataStarted = false;
    function startData() {
        if (__fuiDataStarted) { return; }
        __fuiDataStarted = true;
        // 云端优先：激活/取规格/注入宿主。成功则面板拿到全量并刷新；失败回落本地免费档。
        if (window.FuiCloud && window.FuiCloud.bootstrap) {
            window.FuiCloud.bootstrap(function (r) {
                if (r && r.ok) {
                    window.FUI_CLOUD = { licensed: true, plan: r.plan || "trial" };
                    loadDatatypeSpec();
                    refreshTypeSelectByLicense();
                } else {
                    loadDatatypeSpec();
                }
                refreshLayers(false);
                watchLicenseForTypeList();
            });
            return;
        }
        loadDatatypeSpec();
        refreshLayers(false);
        watchLicenseForTypeList();
    }

    if (document.readyState === "loading") {
        document.addEventListener("DOMContentLoaded", init);
    } else {
        init();
    }
})();
























