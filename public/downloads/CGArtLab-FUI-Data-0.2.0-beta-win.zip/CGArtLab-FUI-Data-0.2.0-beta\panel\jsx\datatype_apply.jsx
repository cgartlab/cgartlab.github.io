/**
 * datatype_apply.jsx —— 数据+单位 AE glue（ES3，只在 AE 内执行）
 * © 2026 CGArtLab · https://cgartlab.com · CGArtLab FUI Data
 * ------------------------------------------------------------------
 * 依赖同目录 format_core.js（纯逻辑）：若未加载会自动 $.evalFile。
 *
 * 对外：
 *   fuiDetectLayer(layer) -> { isText, isNumeric, text, parsedValue, parsedUnit, suggestedType, formatHint?, hemisphere? }
 *   fuiApplyData(target, typeId, options) -> { ok, layer, errors, applied }
 *     - 在目标文本层加/复用 Slider "Value"（初值=检测值或 options.value 或 0）
 *     - behavior：smooth=BEZIER / linear=LINEAR / step=HOLD 关键帧插值；
 *                 wave=给 Value 加 value+wiggle(amp,freq)
 *     - Source Text 表达式：读 Value -> 内联 format_core 的 formatValue -> 返回字符串
 *     - target 可传单层 Layer，或 Layer 数组（批量）
 *   options 可覆盖 spec 字段：unit/rate/prefix/suffix/decimals/thousands/allowNegative/
 *     forceSign/format/behavior/timerMode/timerMs/hemisphere/min/max/clamp，
 *     以及 value/keyframes[{time,value}]/waveAmp/waveFreq
 * 只改目标层，不保存工程。
 */
(function () {
    try {
        if (typeof FUIFormatCore === "undefined") {
            var f = new File($.fileName);
            if (f && f.parent) {
                var core = new File(f.parent.fsName + "/format_core.js");
                if (core.exists) { $.evalFile(core); }
            }
        }
    } catch (eLoad) {}
})();

/* ---------------- 检测 ---------------- */
function fuiDetectLayer(layer) {
    var out = {
        isText: false, isNumeric: false, text: "",
        parsedValue: null, parsedUnit: "", suggestedType: "generic"
    };
    if (!layer) { return out; }
    try { out.isText = (layer instanceof TextLayer); } catch (eIs) { out.isText = false; }
    if (!out.isText) { return out; }

    var txt = "";
    try {
        var td = layer.property("Source Text").value;
        txt = td ? td.text : "";
    } catch (eTxt) { txt = ""; }
    out.text = txt;

    if (typeof FUIFormatCore !== "undefined" && FUIFormatCore) {
        var d = FUIFormatCore.detectParse(txt);
        out.isNumeric = !!d.isNumeric;
        out.parsedValue = d.value;
        out.parsedUnit = d.unit;
        out.suggestedType = d.suggestedType;
        if (d.prefix !== undefined) { out.prefix = d.prefix; }
        if (d.suffix !== undefined) { out.suffix = d.suffix; }
        if (d.forceSign !== undefined) { out.forceSign = !!d.forceSign; }
        if (d.formatHint !== undefined) { out.formatHint = d.formatHint; }
        if (d.hemisphere !== undefined) { out.hemisphere = d.hemisphere; }
    }
    return out;
}

/* ---------------- 深拷贝 ---------------- */
function fuiClone(o) {
    if (o === null || typeof o !== "object") { return o; }
    if (o instanceof Array) {
        var a = [];
        for (var i = 0; i < o.length; i++) { a.push(fuiClone(o[i])); }
        return a;
    }
    var r = {};
    for (var k in o) {
        if (o.hasOwnProperty(k)) { r[k] = fuiClone(o[k]); }
    }
    return r;
}

/* ---------------- 合并 spec ---------------- */
function fuiMergeSpec(typeId, options, errors) {
    var base = null;
    if (typeof FUIFormatCore !== "undefined" && FUIFormatCore) {
        base = FUIFormatCore.getType(typeId);
    }
    if (!base) {
        errors.push("未知 typeId: " + typeId + "（回退 generic）");
        base = (typeof FUIFormatCore !== "undefined" && FUIFormatCore)
            ? FUIFormatCore.getType("generic") : null;
    }
    if (!base) {
        errors.push("format_core 不可用，无法取得量纲");
        return null;
    }
    var spec = fuiClone(base);
    var keys = ["unit", "rate", "prefix", "suffix", "decimals", "thousands",
        "allowNegative", "forceSign", "format", "behavior", "timerMode", "timerMs", "hemisphere",
        "prefixSpace", "unitSpace", "suffixSpace", "affixFont", "affixFontSize", "padding", "color", "anchor", "font", "fontSize", "tracking", "decimalChar", "align", "rmbUppercase"];
    for (var i = 0; i < keys.length; i++) {
        var k = keys[i];
        if (options[k] !== undefined) { spec[k] = options[k]; }
    }
    if (options.min !== undefined || options.max !== undefined || options.clamp !== undefined) {
        if (!spec.range) { spec.range = {}; }
        // 面板里填的范围是「基准单位」的数值（与类型默认上限同源），
        // 但应用到图层后滑块按显示单位计数（如 % → ‰、m → cm）。
        // 不换算的话，切到 ‰ 时上限 100 会把 150‰ 夹成 100‰（旧版本已知缺陷）。
        var fromU = base.baseUnit || "";
        var toU = spec.unit || fromU;
        function toDisplay(v) {
            if (v === null || v === undefined || v === "") { return v; }
            var n = Number(v);
            if (isNaN(n)) { return v; }
            if (!fromU || !toU || fromU === toU) { return n; }
            try {
                if (typeof FUIFormatCore !== "undefined" && FUIFormatCore && FUIFormatCore.convert) {
                    var cv = FUIFormatCore.convert(n, fromU, toU);
                    if (cv !== null && cv !== undefined && !isNaN(Number(cv))) { return Number(cv); }
                }
            } catch (eCv) { }
            return n;
        }
        if (options.min !== undefined) { spec.range.min = toDisplay(options.min); }
        if (options.max !== undefined) { spec.range.max = toDisplay(options.max); }
        if (options.clamp !== undefined) { spec.range.clamp = options.clamp; }
    }
    // 类型自带的默认范围同样是「基准单位」的数值（如百分比 0–100%），
    // 换到 ‰ 后必须一起换算，否则滑块按 ‰ 计数却仍被 100 夹住。
    try {
        if (spec.range) {
            var bU = base.baseUnit || "";
            var tU = spec.unit || bU;
            if (bU && tU && bU !== tU && FUIFormatCore && FUIFormatCore.convert) {
                if (spec.range.min !== null && spec.range.min !== undefined && spec.range.min !== "") {
                    var cmin = FUIFormatCore.convert(Number(spec.range.min), bU, tU);
                    if (!isNaN(Number(cmin))) { spec.range.min = Number(cmin); }
                }
                if (spec.range.max !== null && spec.range.max !== undefined && spec.range.max !== "") {
                    var cmax = FUIFormatCore.convert(Number(spec.range.max), bU, tU);
                    if (!isNaN(Number(cmax))) { spec.range.max = Number(cmax); }
                }
            }
        }
    } catch (eRangeCv) { }
    if (options.thresholds !== undefined) { spec.thresholds = fuiClone(options.thresholds); }
    return spec;
}

/* ---------------- 单位描述查找 ---------------- */
function fuiUnitDesc(spec, idOrLabel) {
    var us = (spec && spec.units) ? spec.units : [];
    if (!us.length) { return null; }
    if (idOrLabel !== undefined && idOrLabel !== null && idOrLabel !== "") {
        for (var i = 0; i < us.length; i++) {
            if (us[i].id === idOrLabel || us[i].label === idOrLabel) { return us[i]; }
        }
    }
    return us[0];
}

/* ---------------- 简易 JSON 序列化（ES3） ---------------- */
function fuiJsonQuote(s) {
    s = String(s);
    var out = "\"";
    for (var i = 0; i < s.length; i++) {
        var c = s.charAt(i);
        if (c === "\\") { out += "\\\\"; }
        else if (c === "\"") { out += "\\\""; }
        else if (c === "\n") { out += "\\n"; }
        else if (c === "\r") { out += "\\r"; }
        else if (c === "\t") { out += "\\t"; }
        else { out += c; }
    }
    return out + "\"";
}

function fuiJson(o) {
    if (o === null || o === undefined) { return "null"; }
    var t = typeof o;
    if (t === "number") { return isFinite(o) ? String(o) : "0"; }
    if (t === "boolean") { return o ? "true" : "false"; }
    if (t === "string") { return fuiJsonQuote(o); }
    if (t === "function") { return "null"; }
    if (o instanceof Array) {
        var s = "[";
        for (var i = 0; i < o.length; i++) {
            if (i > 0) { s += ","; }
            s += fuiJson(o[i]);
        }
        return s + "]";
    }
    var parts = [];
    for (var k in o) {
        if (o.hasOwnProperty(k)) {
            var val = o[k];
            if (typeof val === "function") { continue; }
            parts.push(fuiJsonQuote(k) + ":" + fuiJson(val));
        }
    }
    return "{" + parts.join(",") + "}";
}

/* 生成 Source Text 表达式：优先读取图层上的 FUI_* 效果控件（可在 Effect Controls 调/打关键帧），缺失则用内联 spec */
function fuiBuildSourceExpr(spec) {
    var bundle = FUIFormatCore.expressionBundle();
    var specJson = fuiJson(spec);
    return "var FUI_FMT = " + bundle + ";\n" +
        "var spec = " + specJson + ";\n" +
        "try{ spec.decimals = Math.max(0, Math.min(10, Math.round(effect(\"小数位\")(\"Slider\").value))); }catch(_e0){ try{ spec.decimals = Math.max(0, Math.min(10, Math.round(effect(\"FUI_Decimals\")(\"Slider\").value))); }catch(_e0b){ try{ spec.decimals = Math.max(0, Math.min(10, Math.round(effect(\"fui_decimals\")(\"Slider\").value))); }catch(_e0c){} } }\n" +
        "try{ spec.padding = Math.max(0, Math.min(12, Math.round(effect(\"前导零\")(\"Slider\").value))); }catch(_e1){ try{ spec.padding = Math.max(0, Math.min(12, Math.round(effect(\"FUI_Padding\")(\"Slider\").value))); }catch(_e1b){} }\n" +
        "try{ spec.prefixSpace = Math.max(0, Math.min(20, Math.round(effect(\"前缀空格\")(\"Slider\").value))); }catch(_e2){}\n" +
        "try{ spec.unitSpace = Math.max(0, Math.min(20, Math.round(effect(\"单位空格\")(\"Slider\").value))); }catch(_e3){}\n" +
        "try{ spec.suffixSpace = Math.max(0, Math.min(20, Math.round(effect(\"后缀空格\")(\"Slider\").value))); }catch(_e4){}\n" +
        "try{ spec.thousands = (effect(\"千分位\")(\"Checkbox\").value > 0); }catch(_e5){ try{ spec.thousands = (effect(\"FUI_Thousands\")(\"Checkbox\").value > 0); }catch(_e5b){} }\n" +
        "try{ spec.timerMs = (effect(\"毫秒\")(\"Checkbox\").value > 0); }catch(_e6){}\n" +
        "var v = 0;\n" +
        "if (spec.behavior === \"hold\") {\n" +
        "  var vp = null; var vpPoint = false; try{ vp = thisLayer.effect(\"数值\")(\"Slider\"); }catch(_h0){ try{ vp = thisLayer.effect(\"Value\")(\"Slider\"); }catch(_h1){ try{ vp = thisLayer.effect(\"数值\")(\"Point\"); vpPoint = true; }catch(_h2){} } }\n" +
        "  if (vp) { var tv = time; var ki = 0; for (var ii = 1; ii <= vp.numKeys; ii++) { if (vp.key(ii).time <= tv + 0.0001) { ki = ii; } } if (ki > 0) { v = vpPoint ? vp.key(ki).value[0] : vp.key(ki).value; } else if (vp.numKeys > 0) { v = vpPoint ? vp.key(1).value[0] : vp.key(1).value; } else { v = vpPoint ? vp.value[0] : vp.value; } }\n" +
        "} else {\n" +
        "  try { v = thisLayer.effect(\"数值\")(\"Slider\").value; }catch(_ev1){ try { v = thisLayer.effect(\"Value\")(\"Slider\").value; }catch(_ev2){ try { v = thisLayer.effect(\"数值\")(\"Point\").value[0]; }catch(_ev3){ try { v = thisLayer.effect(\"Value\")(\"Point\").value[0]; }catch(_ev4){} } } }\n" +
        "}\n" +
        "String(FUI_FMT.formatValue(v, spec));";
}

function fuiEnsureControls(layer, spec, result) {
    var parade = layer.property("ADBE Effect Parade");
    /* legacy 可以是字符串或数组：兼容历史版本的 FUI_Decimals 与 fui_decimals 两套命名，
     * 找到就改名复用，避免同一参数在图层上出现两个控件、表达式读错来源。 */
    function findLegacyEffect(names) {
        if (!names) { return null; }
        var list = (names instanceof Array) ? names : [names];
        for (var i = 0; i < list.length; i++) {
            var e = null;
            try { e = layer.effect(list[i]); } catch (eL) { e = null; }
            if (e) { return e; }
        }
        return null;
    }
    function addSlider(name, legacy, val) {
        var ex = null; try { ex = layer.effect(name); } catch (e) { ex = null; }
        if (!ex) { ex = findLegacyEffect(legacy); if (ex) { try { ex.name = name; } catch (eR) { } } }
        if (ex) {
            try { var pr = ex.property("ADBE Slider Control-0001"); if (pr.numKeys === 0) { pr.setValue(Number(val)); } } catch (eS) { }
            return;
        }
        var f = parade.addProperty("ADBE Slider Control"); f.name = name;
        f.property("ADBE Slider Control-0001").setValue(Number(val));
        result.applied.push("控件 " + name + "=" + val);
    }
    function addCheck(name, legacy, on) {
        var ex = null; try { ex = layer.effect(name); } catch (e) { ex = null; }
        if (!ex) { ex = findLegacyEffect(legacy); if (ex) { try { ex.name = name; } catch (eR) { } } }
        if (ex) {
            try { var pr = ex.property("ADBE Checkbox Control-0001"); if (pr.numKeys === 0) { pr.setValue(on ? 1 : 0); } } catch (eC) { }
            return;
        }
        var f = parade.addProperty("ADBE Checkbox Control"); f.name = name;
        f.property("ADBE Checkbox Control-0001").setValue(on ? 1 : 0);
        result.applied.push("控件 " + name + "=" + (on ? 1 : 0));
    }
    var us = spec.units || [], ud = null;
    for (var i = 0; i < us.length; i++) { if (us[i].id === spec.unit || us[i].label === spec.unit) { ud = us[i]; break; } }
    if (!ud && us.length) { ud = us[0]; }
    var unitSeed;
    if (spec.unitSpace !== undefined && spec.unitSpace !== null) { unitSeed = spec.unitSpace; }
    else { unitSeed = (ud && ud.space) ? 1 : 0; }  // 该单位若声明「与数字间有空格」，默认给 1 个
    // 清理旧版“间距(px)”控件，避免与新的“空格”控件并存造成误解
    var legacySpacing = ["前缀间距", "单位间距", "后缀间距", "FUI_PrefixSpace", "FUI_UnitSpace", "FUI_SuffixSpace"];
    for (var lsi = 0; lsi < legacySpacing.length; lsi++) {
        try { var lfx = layer.effect(legacySpacing[lsi]); if (lfx) { lfx.remove(); } } catch (eLs) { }
    }
    addSlider("小数位", ["FUI_Decimals", "fui_decimals"], spec.decimals === undefined ? 0 : spec.decimals);
    addSlider("前导零", ["FUI_Padding", "fui_padding"], spec.padding || 0);
    addSlider("前缀空格", null, spec.prefixSpace || 0);
    addSlider("单位空格", null, unitSeed);
    addSlider("后缀空格", null, spec.suffixSpace || 0);
    addCheck("千分位", ["FUI_Thousands", "fui_thousands"], !!spec.thousands);
    try {
        if (spec.id === "timer" || spec.format === "timecode") {
            try { var oldAuto = layer.effect("自动计时"); if (oldAuto) { oldAuto.remove(); } } catch (eOldAuto2) { }
            addCheck("毫秒", null, !!spec.timerMs);
        }
    } catch (eTimerC) { }
}

/* ---------------- 获取/新增数值控件 ---------------- */

function fuiIsPointFx(fx) {
    try { return !!fx.property("ADBE Point Control-0001"); } catch (e) { return false; }
}

/* 获取/创建数值控件：常规用 Slider；数值超过 ±1,000,000 时自动改用 Point（x 存数值，可K帧、无此上限） */
function fuiGetValueControl(layer, initVal, result, oldUnitDesc, newUnitDesc) {
    // 清理上次迁移可能残留的旧控件
    try { var stale1 = layer.effect("数值_旧"); if (stale1) { stale1.remove(); } } catch (eS1) { }
    try { var stale2 = layer.effect("Value_旧"); if (stale2) { stale2.remove(); } } catch (eS2) { }
    var fx = null, found = null, names = ["数值", "Value"];
    for (var i = 0; i < names.length; i++) {
        try { fx = layer.effect(names[i]); } catch (eFind) { fx = null; }
        if (fx) { found = names[i]; break; }
    }
    function convKey(v) {
        try {
            if (oldUnitDesc && newUnitDesc && oldUnitDesc.id !== newUnitDesc.id) {
                return FUIFormatCore.convert(Number(v), oldUnitDesc, newUnitDesc);
            }
        } catch (eCk) { }
        return Number(v);
    }
    var needPoint = Math.abs(Number(initVal)) > 1000000;
    if (fx) {
        var isP = fuiIsPointFx(fx);
        if (found !== "数值") { try { fx.name = "数值"; } catch (eR) { } }
        var prop0 = fx.property(isP ? "ADBE Point Control-0001" : "ADBE Slider Control-0001");
        // 检查关键帧换算后的最大值，决定是否需要 Point
        var keyVals = [], keyTimes = [];
        var keyInterp = [], keyEaseIn = [], keyEaseOut = [];
        if (prop0.numKeys > 0) {
            for (var k0 = 1; k0 <= prop0.numKeys; k0++) {
                keyTimes.push(prop0.keyTime(k0));
                var kv0 = prop0.keyValue(k0); if (isP) { kv0 = kv0[0]; }
                var cv0 = convKey(kv0); keyVals.push(cv0);
                if (Math.abs(cv0) > 1000000) { needPoint = true; }
                // 迁移到 Point 时 setValuesAtTimes 会把插值/缓动重置，先记下来
                try {
                    keyInterp.push([prop0.keyInInterpolationType(k0), prop0.keyOutInterpolationType(k0)]);
                    keyEaseIn.push(prop0.keyInTemporalEaseAtKey(k0));
                    keyEaseOut.push(prop0.keyOutTemporalEaseAtKey(k0));
                } catch (eEase) {
                    keyInterp.push(null); keyEaseIn.push(null); keyEaseOut.push(null);
                }
            }
        }
        if (needPoint && !isP) {
            // 迁移必须可回滚：旧 Slider 上有用户的关键帧，删掉就不可恢复。
            // 顺序：先建 Point 并写值成功 → 再移除旧 Slider；任何一步失败都保留/重建旧控件。
            var parade = null;
            var nf = null, np = null, migrated = false;
            try {
                parade = layer.property("ADBE Effect Parade");
                nf = parade.addProperty("ADBE Point Control");
                nf.name = "数值";
                np = nf.property("ADBE Point Control-0001");
                if (keyTimes.length > 0) {
                    var vsP = [];
                    for (var km = 0; km < keyTimes.length; km++) { vsP.push([keyVals[km], 0]); }
                    np.setValuesAtTimes(keyTimes, vsP);
                    // 还原插值与缓动：迁移不该改变动画手感
                    for (var kr = 1; kr <= np.numKeys; kr++) {
                        var idx = kr - 1;
                        try {
                            if (keyInterp[idx]) {
                                np.setInterpolationTypeAtKey(kr, keyInterp[idx][0], keyInterp[idx][1]);
                            }
                            if (keyEaseIn[idx] && keyEaseOut[idx]) {
                                np.setTemporalEaseAtKey(kr, keyEaseIn[idx], keyEaseOut[idx]);
                            }
                        } catch (eRestore) {
                            if (result) { result.errors.push("迁移后有 " + (keyTimes.length) + " 帧缓动未完全还原: " + String(eRestore)); }
                            break;
                        }
                    }
                } else { np.setValue([Number(initVal), 0]); }
                migrated = true;
            } catch (eMig) {
                // 失败：撤掉半成品 Point，保留原 Slider（下面的 return 会让表达式继续读旧控件）
                try { if (nf) { nf.remove(); } } catch (eRollback) { }
                try { fx.name = "数值"; fx.enabled = true; } catch (eBack) { }
                result.errors.push("大数值迁移失败（已保留原滑块，关键帧未丢）: " + String(eMig));
                result.ok = false;
                var p0b = fx.property("ADBE Slider Control-0001");
                return { fx: fx, prop: p0b, isPoint: false };
            }
            if (migrated) {
                // 确认新控件可读，再删旧控件，避免中间态把表达式指向不存在的效果
                try { var probe = np.value; if (probe === undefined || probe === null) { throw new Error("Point 控件写入后读不到值"); } } catch (eProbe) {
                    try { nf.remove(); } catch (eR2) { }
                    try { fx.name = "数值"; fx.enabled = true; } catch (eB2) { }
                    result.errors.push("大数值迁移校验失败（已回滚，保留原滑块）: " + String(eProbe));
                    result.ok = false;
                    return { fx: fx, prop: fx.property("ADBE Slider Control-0001"), isPoint: false };
                }
                // 注意：addProperty 之后，之前拿到的 Effect 引用在 AE 里可能已经失效
                // （表现为改名/删除静默不生效，最后留下两个「数值」控件）。
                // 所以这里重新按名字找旧滑块，再删。
                var oldFx = null;
                try {
                    var pd = layer.property("ADBE Effect Parade");
                    for (var qi = pd.numProperties; qi >= 1; qi--) {
                        var ec = pd.property(qi);
                        var ecName = "";
                        try { ecName = String(ec.name); } catch (eN) { ecName = ""; }
                        if (ecName !== "数值" && ecName !== "Value") { continue; }
                        var isSliderEc = false;
                        try { isSliderEc = !!ec.property("ADBE Slider Control-0001"); } catch (eK) { isSliderEc = false; }
                        if (isSliderEc) { oldFx = ec; break; }
                    }
                } catch (eFindOld) { oldFx = null; }
                if (oldFx) {
                    try { oldFx.name = "数值_旧"; oldFx.enabled = false; } catch (eOld) { }
                    try { oldFx.remove(); } catch (eRem0) {
                        if (result) { result.errors.push("旧滑块删除失败（已改名 数值_旧，请手动删除或再应用一次）: " + String(eRem0)); }
                    }
                } else {
                    try { fx.name = "数值_旧"; fx.enabled = false; fx.remove(); } catch (eRem1) { }
                }
                if (result) { result.applied.push("数值超出滑块上限，已改用 Point 控件（可K帧，关键帧已迁移）"); }
                // 删旧控件后重新取一次新控件：AE 里相邻操作可能让先前拿到的引用失效
                var nf2 = null, np2 = null;
                try { nf2 = layer.effect("数值"); } catch (eNf2) { nf2 = null; }
                if (nf2) { try { np2 = nf2.property("ADBE Point Control-0001"); } catch (eNp2) { np2 = null; } }
                return { fx: (nf2 || nf), prop: (np2 || np), isPoint: true };
            }
        }
        // 已有 K 帧且切换了单位：换算关键帧数值（保留时间/缓动）
        if (prop0.numKeys > 0 && oldUnitDesc && newUnitDesc && oldUnitDesc.id !== newUnitDesc.id) {
            var kcFail = 0;
            for (var k1 = 1; k1 <= prop0.numKeys; k1++) {
                try { prop0.setValueAtKey(k1, isP ? [keyVals[k1 - 1], 0] : keyVals[k1 - 1]); } catch (eKc2) { kcFail++; }
            }
            if (kcFail > 0) {
                result.errors.push("关键帧换算有 " + kcFail + " 帧写入失败，请检查该图层的「数值」关键帧");
                result.ok = false;
            } else if (result) {
                result.applied.push("关键帧数值已按单位换算: " + oldUnitDesc.id + " → " + newUnitDesc.id);
            }
        }
        if (result) { result.applied.push("复用控件 '数值'"); }
        return { fx: fx, prop: prop0, isPoint: isP };
    }
    var parade2 = layer.property("ADBE Effect Parade");
    var f2 = parade2.addProperty(needPoint ? "ADBE Point Control" : "ADBE Slider Control");
    f2.name = "数值";
    if (result) { result.applied.push((needPoint ? "新增 Point 控件 '数值'（大数值，可K帧）" : "新增控件 '数值'")); }
    return { fx: f2, prop: f2.property(needPoint ? "ADBE Point Control-0001" : "ADBE Slider Control-0001"), isPoint: needPoint };
}

/* ---------------- 前后缀独立层（思源黑体，数字层保持原字体） ---------------- */
/* 读取某数字层的“单位”子层文本（用于单位拆层后的检测/换算） */
function fuiFindUnitChildText(layer) {
    try {
        var comp = layer.containingComp;
        for (var i = 1; i <= comp.numLayers; i++) {
            var L = comp.layer(i);
            if (L && L.parent === layer && /^FUI单位/.test(L.name)) {
                var ut = String(L.property("Source Text").value.text);
                return ut.replace(/^[+\-]/, ""); // 去掉动态符号，仅返回单位符号
            }
        }
    } catch (e) { }
    return "";
}
/* 判断 L 是否在 root 的祖先链下（支持挂在“单位层”下的前缀层等间接子层） */
function fuiIsUnder(L, root) {
    var p = L, d = 0;
    while (p && d < 10) {
        var par = null; try { par = p.parent; } catch (e) { par = null; }
        if (par === root) { return true; }
        p = par; d++;
    }
    return false;
}

/* 清理孤儿前后缀/单位子层（父链顶端仍是 FUI 辅助层且无父 → 视为孤儿） */
function fuiCleanupOrphanAffix(comp) {
    try {
        for (var i = comp.numLayers; i >= 1; i--) {
            var L = comp.layer(i);
            if (!/^FUI前缀|^FUI单位|^FUI后缀|^FUI宽度/.test(L.name)) { continue; }
            var p = L, top = L, d = 0;
            while (p && d < 10) {
                var par = null; try { par = p.parent; } catch (eP) { par = null; }
                if (!par) { top = p; break; }
                p = par; d++;
            }
            // 顶端若仍是 FUI 辅助层 → 父数字层已被删除，清理
            if (top && /^FUI前缀|^FUI单位|^FUI后缀|^FUI宽度/.test(top.name)) { try { L.remove(); } catch (eR) { } }
        }
    } catch (e) { }
}

function fuiFindAffixChildren(layer) {
    var out = { prefix: null, suffix: null, unit: null };
    var comp = null; try { comp = layer.containingComp; } catch (e) { comp = null; }
    if (!comp) { return out; }
    for (var i = 1; i <= comp.numLayers; i++) {
        var L = null; try { L = comp.layer(i); } catch (eL) { L = null; }
        if (!L) { continue; }
        try {
            if (fuiIsUnder(L, layer)) {
                if (/^FUI前缀/.test(L.name)) { out.prefix = L; }
                else if (/^FUI后缀/.test(L.name)) { out.suffix = L; }
                else if (/^FUI单位/.test(L.name)) { out.unit = L; }
            }
        } catch (eP) { }
    }
    return out;
}

/* 复制父文本的字符样式到子层（不含字体/字号/字距/填充色，这几项已单独处理） */
function fuiCopyCharStyle(baseTd, td) {
    if (!baseTd || !td) { return; }
    var bools = ["fauxBold", "fauxItalic", "underline", "strikethrough", "allCaps", "subscript", "superscript"];
    for (var i = 0; i < bools.length; i++) { try { td[bools[i]] = baseTd[bools[i]]; } catch (e1) { } }
    var nums = ["horizontalScale", "verticalScale", "baselineShift", "leading"];
    for (var j = 0; j < nums.length; j++) { try { td[nums[j]] = baseTd[nums[j]]; } catch (e2) { } }
    try { td.applyFill = baseTd.applyFill; } catch (e3) { }
    try {
        if (baseTd.applyStroke) {
            td.applyStroke = true;
            try { td.strokeColor = baseTd.strokeColor; } catch (e4) { }
            try { td.strokeWidth = baseTd.strokeWidth; } catch (e5) { }
            try { td.strokeOverFill = baseTd.strokeOverFill; } catch (e6) { }
        } else { td.applyStroke = false; }
    } catch (e7) { }
}

function fuiStyleAffix(L, text, isLeft, gapPx, scaleDiv, fontName, fontSize, tracking, fillColor, result, opacityExpr, blendMode, baseTd) {
    try {
        var src = L.property("Source Text");
        // 先清除可能残留的表达式（例如从“单位在前(货币)”切到“单位在后(温度)”）
        try { src.expression = ""; } catch (eEx) { }
        var td = src.value;
        td.text = text;
        if (fontName) { try { td.font = fontName; } catch (eF) { } }
        try { td.fontSize = fontSize; } catch (eS) { }
        try { td.tracking = tracking || 0; } catch (eT) { }
        try { td.fillColor = fillColor; } catch (eC) { }
        try { td.justification = ParagraphJustification.LEFT_JUSTIFY; } catch (eJ) { }
        fuiCopyCharStyle(baseTd, td);
        src.setValue(td);
        var sd = Number(scaleDiv); if (!(sd > 0) || !isFinite(sd)) { sd = 1; }
        var g = (Number(gapPx) || 0) / sd;
        // 用隐藏测量层 FUI宽度（同长度占位数字，宽度稳定）来定位，避免数字动画时单位左右抖动
        var MEAS = "var ml=0,mw=0; try{ var rt=p; try{ if(p.parent) rt=p.parent; }catch(er0){} for(var mi=1;mi<=thisComp.numLayers;mi++){ var M=thisComp.layer(mi); try{ if(M.parent===rt && /^FUI宽度/.test(M.name)){ var mr=M.sourceRectAtTime(); ml=mr.left; mw=mr.width; break; } }catch(er1){} } }catch(er2){} if(!(mw>0)){ ml=r.left; mw=r.width; }";
        var expr = isLeft
            ? ("var p=thisLayer.parent; var r=p.sourceRectAtTime(); var c=thisLayer.sourceRectAtTime(); " + MEAS + " [ml - " + g + " - (c.left + c.width), 0];")
            : ("var p=thisLayer.parent; var r=p.sourceRectAtTime(); var c=thisLayer.sourceRectAtTime(); " + MEAS + " [ml + mw + " + g + " - c.left, 0];");
        L.property("Position").expression = expr;
        // 不透明度跟随数字层（AE 父子不继承不透明度）
        if (opacityExpr) { try { L.property("Opacity").expression = opacityExpr; } catch (eOp) { } }
        // 混合模式复制（父子同样不继承混合模式）
        if (blendMode !== undefined && blendMode !== null) { try { L.blendMode = blendMode; } catch (eBm) { } }
    } catch (e) { result.errors.push("设置前后缀层失败: " + String(e)); }
}

/* 返回 true 表示使用独立层承载 前缀/单位/后缀（数字层文本需去掉这些） */
/* 生成“符号+标签”的动态文本表达式（按显示小数位四舍五入判断正负） */
function fuiSignLabelExpr(P, label, forceSign) {
    var fsp = forceSign ? "true" : "false";
    return "var v=0; try{ v=" + P + ".effect(\"数值\")(\"Slider\").value; }catch(e1){ try{ v=" + P + ".effect(\"Value\")(\"Slider\").value; }catch(e2){} } " +
        "var d=2; try{ d=Math.round(" + P + ".effect(\"小数位\")(\"Slider\").value); }catch(e3){} if(!(d>=0&&d<=10))d=2; " +
        "var pp=Math.pow(10,d); var rv=Math.round(Math.abs(v)*pp)/pp; var s=\"\"; " +
        "if(v<0 && rv!==0){s=\"-\";} else if(" + fsp + " && v>0 && rv!==0){s=\"+\";} s+" + fuiJsonQuote(label) + ";";
}

function fuiApplyAffix(layer, spec, result) {
    var pre = spec.prefix || "";
    var suf = spec.suffix || "";
    var comp = null; try { comp = layer.containingComp; } catch (e) { comp = null; }
    if (!comp) { return false; }
    var selNames = [];
    try { var sl = comp.selectedLayers; for (var si = 0; si < sl.length; si++) { selNames.push(sl[si].name); } } catch (eSel) { }
    function hasName(nm) { for (var q = 0; q < selNames.length; q++) { if (selNames[q] === nm) { return true; } } return false; }
    function restoreSel() { try { for (var ri = 1; ri <= comp.numLayers; ri++) { var LL = comp.layer(ri); LL.selected = hasName(LL.name); } } catch (eR) { } }

    var unit = null; try { unit = fuiUnitDesc(spec, spec.unit); } catch (eU) { unit = null; }
    var unitLabel = unit ? (unit.label || "") : "";
    var unitPlace = (unit && unit.place) ? unit.place : "suffix";
    var usePrefix = !!pre, useSuffix = !!suf;
    // 单位拆层仅对“有实际显示单位文本”的类型生效；DMS(经纬度)、人民币大写、计时等不应拆单位层
    var unitDisplayable = !!unitLabel && (spec.format !== "dms") && (spec.format !== "rmbUppercase") && (spec.format !== "timecode");
    var useUnit = unitDisplayable && (Number(spec.unitSpace) > 0);
    // 只有用户明确设置前后缀字体/字号时，才使用独立前后缀层（统一字体）
    var customAffix = (spec.affixFont !== undefined && spec.affixFont !== null && String(spec.affixFont) !== "") ||
        (spec.affixFontSize !== undefined && spec.affixFontSize !== null && String(spec.affixFontSize) !== "");
    if (!customAffix || !(usePrefix || useSuffix)) {
        // 单层模式：清理历史辅助层
        var kids0 = fuiFindAffixChildren(layer);
        if (kids0.prefix) { try { kids0.prefix.remove(); } catch (e1) { } }
        if (kids0.suffix) { try { kids0.suffix.remove(); } catch (e2) { } }
        if (kids0.unit) { try { kids0.unit.remove(); } catch (e3) { } }
        var oldM0 = null;
        try { for (var mi0 = 1; mi0 <= comp.numLayers; mi0++) { var M0 = comp.layer(mi0); if (M0 && M0.parent === layer && /^FUI宽度/.test(M0.name)) { oldM0 = M0; break; } } } catch (eM0) { }
        if (oldM0) { try { oldM0.remove(); } catch (e4) { } }
        restoreSel();
        return { any: false, unit: false };
    }
    useUnit = false; // 单位仍留在主层文本；只拆分前后缀
    var kids = fuiFindAffixChildren(layer);
    function findMeasure() {
        try {
            for (var mi = 1; mi <= comp.numLayers; mi++) {
                var M = comp.layer(mi);
                if (M && M.parent === layer && /^FUI宽度/.test(M.name)) { return M; }
            }
        } catch (eM) { }
        return null;
    }
    var base = null; try { base = layer.property("Source Text").value; } catch (eB) { base = null; }
    var baseFont = base ? String(base.font) : "";
    var affFont = (spec.affixFont !== undefined && spec.affixFont !== null && String(spec.affixFont) !== "") ? String(spec.affixFont) : baseFont;
    var baseSize = base ? base.fontSize : 30;
    var baseTrack = 0; try { baseTrack = base ? Number(base.tracking) || 0 : 0; } catch (eTr) { baseTrack = 0; }
    var baseFill = base ? base.fillColor : [1, 1, 1];
    var affSize = (spec.affixFontSize !== undefined && spec.affixFontSize !== null && spec.affixFontSize !== "") ? Number(spec.affixFontSize) : baseSize;

    // 隐藏测量层：文本用同长度的占位数字（数字→0、符号/小数点保留），宽度在数字位数不变时恒定
    var measureLayer = findMeasure();
    if (!measureLayer) { measureLayer = comp.layers.addText("0"); measureLayer.name = "FUI宽度"; try { measureLayer.parent = layer; } catch (eMP) { } }
    try { measureLayer.guideLayer = true; measureLayer.shy = true; } catch (eMG) { }
    try {
        var msrc = measureLayer.property("Source Text");
        var mtd = msrc.value;
        mtd.text = "0";
        if (baseFont) { try { mtd.font = baseFont; } catch (eMF) { } }
        try { mtd.fontSize = baseSize; } catch (eMS) { }
        try { mtd.tracking = baseTrack || 0; } catch (eMT) { }
        fuiCopyCharStyle(base, mtd);
        try {
            var baseJust = ParagraphJustification.LEFT_JUSTIFY;
            try { if (base && base.justification !== undefined && base.justification !== null) { baseJust = base.justification; } } catch (eBJ) { }
            mtd.justification = baseJust;
        } catch (eMJ) { }
        msrc.setValue(mtd);
        msrc.expression = "var t=String(thisLayer.parent.text.sourceText); var s=\"\"; for(var mi=0;mi<t.length;mi++){ var ch=t.charAt(mi); s+=(/[0-9]/.test(ch)?\"0\":ch); } s;";
    } catch (eMeas) { }
    if (!(affSize > 0)) { affSize = baseSize; }
    var gPre = (spec.prefixSpace !== undefined && spec.prefixSpace !== null) ? Number(spec.prefixSpace) : 0;
    var gSuf = (spec.suffixSpace !== undefined && spec.suffixSpace !== null) ? Number(spec.suffixSpace) : 0;
    var gUnit = (spec.unitSpace !== undefined && spec.unitSpace !== null) ? Number(spec.unitSpace) : 0;

    // 应用时烘焙父层缩放，用于把像素间距换算到父坐标系
    var scaleVal = 100;
    try { scaleVal = Number(layer.transform.scale.value[0]); } catch (eS1) { try { scaleVal = Number(layer.transform.scale[0]); } catch (eS2) { scaleVal = 100; } }
    var rootScale = Math.abs(scaleVal) / 100; if (!(rootScale > 0) || !isFinite(rootScale)) { rootScale = 1; }

    // 单位层
    var unitLayer = null;
    var parentBlend = null; try { parentBlend = layer.blendMode; } catch (eB0) { parentBlend = null; }
    if (parentBlend === undefined || parentBlend === null) { try { parentBlend = BlendingMode.NORMAL; } catch (eB1) { } }
    var signInPrefix = (useUnit && unitPlace === "prefix" && usePrefix);
    if (useUnit) {
        unitLayer = kids.unit || comp.layers.addText(unitLabel);
        unitLayer.name = "FUI单位"; try { unitLayer.parent = layer; } catch (eUP) { }
        fuiStyleAffix(unitLayer, unitLabel, (unitPlace === "prefix"), gUnit, rootScale, baseFont, baseSize, baseTrack, baseFill, result, "thisLayer.parent.opacity;", parentBlend, base);
        if (unitPlace === "prefix" && !signInPrefix) {
            try { unitLayer.property("Source Text").expression = fuiSignLabelExpr("thisLayer.parent", unitLabel, spec.forceSign); } catch (eUE) { }
        }
    } else if (kids.unit) { try { kids.unit.remove(); } catch (eUR) { } }

    // 前缀层（若单位在前，则挂在单位层左侧）
    if (usePrefix) {
        var parentP = (useUnit && unitPlace === "prefix") ? unitLayer : layer;
        var PL = kids.prefix || comp.layers.addText(pre);
        PL.name = "FUI前缀"; try { PL.parent = parentP; } catch (ePP) { }
        fuiStyleAffix(PL, pre, true, gPre, rootScale, affFont, affSize, baseTrack, baseFill, result, (parentP === unitLayer ? "thisLayer.parent.parent.opacity;" : "thisLayer.parent.opacity;"), parentBlend, base);
        if (signInPrefix && PL.parent === unitLayer) {
            try { PL.property("Source Text").expression = fuiSignLabelExpr("thisLayer.parent.parent", pre, spec.forceSign); } catch (ePE) { }
        } else if (signInPrefix) {
            // 单位不再拆层（useUnit=false）时，前缀直接挂在数字层下，不能再取 parent.parent
            try { PL.property("Source Text").expression = fuiSignLabelExpr("thisLayer.parent", pre, spec.forceSign); } catch (ePE2) { }
        }
    } else if (kids.prefix) { try { kids.prefix.remove(); } catch (ePR) { } }

    // 后缀层（若单位在后，则挂在单位层右侧）
    if (useSuffix) {
        var parentS = (useUnit && unitPlace !== "prefix") ? unitLayer : layer;
        var SL = kids.suffix || comp.layers.addText(suf);
        SL.name = "FUI后缀"; try { SL.parent = parentS; } catch (eSP) { }
        fuiStyleAffix(SL, suf, false, gSuf, rootScale, affFont, affSize, baseTrack, baseFill, result, (parentS === unitLayer ? "thisLayer.parent.parent.opacity;" : "thisLayer.parent.opacity;"), parentBlend, base);
    } else if (kids.suffix) { try { kids.suffix.remove(); } catch (eSR) { } }

    restoreSel();
    try { layer.selected = true; } catch (eLT) { }
    return { any: true, unit: useUnit, unitPrefix: (useUnit && unitPlace === "prefix") };
}

/* ---------------- 对齐（左/中/右，针对该数字文字层段落对齐） ---------------- */
function fuiApplyAlign(layer, srcText, align, result) {
    try {
        var td = srcText.value;
        var j = ParagraphJustification.LEFT_JUSTIFY;
        if (align === "right") { j = ParagraphJustification.RIGHT_JUSTIFY; }
        else if (align === "center") { j = ParagraphJustification.CENTER_JUSTIFY; }
        td.justification = j;
        srcText.setValue(td);
        result.applied.push("对齐 = " + align);
    } catch (e) { result.errors.push("设置对齐失败: " + String(e)); }
}

/* ---------------- 字距统一（可调 tracking，全字符视觉间距一致） ---------------- */
function fuiApplyTypography(layer, srcText, opts, result) {
    try {
        // 未主动设置字距（留空）时不改动图层，保留用户手动设置的字距/字体等样式
        if (!opts || opts.tracking === undefined || opts.tracking === null || opts.tracking === "") { return; }
        var td = srcText.value;
        if (!td) { return; }
        var tv = Number(opts.tracking);
        if (isNaN(tv)) { return; }
        var curT = 0, curK = 0;
        try { curT = Number(td.tracking) || 0; } catch (eT0) { curT = 0; }
        try { curK = Number(td.kerning) || 0; } catch (eK0) { curK = 0; }
        // 字距已一致就不写回 TextDocument，避免把字体等样式写回造成字体变化
        if (tv === curT && curK === 0) { return; }
        try { td.tracking = tv; } catch (eT) { }
        try { td.kerning = 0; } catch (eK) { }
        srcText.setValue(td);
        result.applied.push("字距 tracking=" + tv + "（kerning=0）");
    } catch (e) { /* 字体无此属性时忽略 */ }
}

/* ---------------- 文字字号 ---------------- */
function fuiApplyFontSize(layer, srcText, size, result) {
    try {
        var n = Number(size);
        if (!(n > 0)) { return; }
        var td = srcText.value;
        td.fontSize = n;
        srcText.setValue(td);
        result.applied.push("字号 = " + n);
    } catch (e) { result.errors.push("设置字号失败: " + String(e)); }
}

/* ---------------- 文字字体 ---------------- */
function fuiApplyFont(layer, srcText, font, result) {
    try {
        if (!font) { return; }
        var name = (font === "思源黑体" || font === "__siyuan__") ? "SourceHanSansSC-Regular" : String(font);
        var td = srcText.value;
        var prev = td.font;
        td.font = name;
        srcText.setValue(td);
        var got = srcText.value.font;
        if (got && String(got).toLowerCase().indexOf(String(name).toLowerCase()) >= 0) {
            result.applied.push("字体 = " + got);
        } else {
            // 字体名可能无效，恢复原字体并提示
            try { var td2 = srcText.value; td2.font = prev; srcText.setValue(td2); } catch (eR) { }
            result.errors.push("字体名可能无效（已保留原字体）: " + name);
        }
    } catch (e) { result.errors.push("设置字体失败: " + String(e)); }
}

/* ---------------- 文字颜色（Effect Controls 可调、可K帧） ---------------- */
function fuiEnsureColorFx(layer, rgb, setColor, result, ensureIfMissing) {
    try {
        var fx = null;
        try { fx = layer.effect("颜色"); } catch (e0) { fx = null; }
        if (!fx) {
            try {
                var parade = layer.property("ADBE Effect Parade");
                for (var i = 1; i <= parade.numProperties; i++) {
                    var p = parade.property(i);
                    try { if (p.matchName === "ADBE Fill") { fx = p; break; } } catch (eM) { }
                }
            } catch (eP) { }
        }
        if (!fx) {
            if (!ensureIfMissing) { return null; }
            var parade2 = layer.property("ADBE Effect Parade");
            fx = parade2.addProperty("ADBE Fill");
            fx.name = "颜色";
            if (result) { result.applied.push("新增颜色效果（Fill，可K帧）"); }
        }
        if (setColor && rgb && rgb.length >= 3) {
            var cp = fx.property("ADBE Fill-0002");
            if (cp.numKeys === 0) {
                cp.setValue([Number(rgb[0]), Number(rgb[1]), Number(rgb[2])]);
                if (result) { result.applied.push("颜色效果 = [" + rgb.join(",") + "]"); }
            } else if (result) {
                result.applied.push("颜色效果已有关键帧，保留你的颜色动画");
            }
        }
        return fx;
    } catch (e) { if (result) { result.errors.push("设置颜色效果失败: " + String(e)); } return null; }
}

function fuiApplyTextColor(layer, srcText, rgb, result) {
    try {
        var td = srcText.value;
        if (td) {
            td.fillColor = [Number(rgb[0]), Number(rgb[1]), Number(rgb[2])];
            try { td.applyFill = true; } catch (eF) {}
            srcText.setValue(td);
            result.applied.push("文字颜色 = [" + rgb.join(",") + "]");
        }
    } catch (e) { result.errors.push("设置颜色失败: " + String(e)); }
}

/* ---------------- 锚点九宫格（设到对应边/角，并补偿位置保持视觉不跳） ---------------- */
function fuiApplyAnchor(layer, key, result) {
    try {
        var comp = null; try { comp = layer.containingComp; } catch (eC) { comp = null; }
        var when = comp ? comp.time : 0;
        var rect = null;
        try { rect = layer.sourceRectAtTime(when, false); } catch (eR) { rect = null; }
        if (!rect) { result.errors.push("锚点: 无法取图层边界"); return; }
        var xs = { l: rect.left, c: rect.left + rect.width / 2, r: rect.left + rect.width };
        var ys = { t: rect.top, c: rect.top + rect.height / 2, b: rect.top + rect.height };
        var map = { tl: ["l", "t"], tc: ["c", "t"], tr: ["r", "t"], ml: ["l", "c"], mc: ["c", "c"], mr: ["r", "c"], bl: ["l", "b"], bc: ["c", "b"], br: ["r", "b"] };
        if (!map[key]) { result.errors.push("锚点: 未识别的位置 " + String(key)); return; }
        var ax = xs[map[key][0]], ay = ys[map[key][1]];
        var xf = layer.property("ADBE Transform Group");
        var ap = xf.property("ADBE Anchor Point");
        var pos = xf.property("ADBE Position");
        var oldA = ap.value, oldP = pos.value;
        // 缩放不为 100 时，锚点位移要在图层坐标系里换算，否则每次套锚点都会产生视觉位移
        var sx = 100, sy = 100;
        try {
            var sc = xf.property("ADBE Scale").value;
            sx = Number(sc[0]); sy = Number(sc[1]);
            if (!isFinite(sx) || sx === 0) { sx = 100; }
            if (!isFinite(sy) || sy === 0) { sy = 100; }
        } catch (eS) { }
        var dX = (ax - oldA[0]) * sx / 100;
        var dY = (ay - oldA[1]) * sy / 100;
        var hadKeys = false;
        try { hadKeys = (pos.numKeys > 0); } catch (eK) { }
        // 先写位置再改锚点：位置写失败时锚点还保持原状，不会留下「跳了一半」的状态
        if (hadKeys) {
            try { pos.setValueAtTime(when, [oldP[0] + dX, oldP[1] + dY]); }
            catch (ePk) { result.errors.push("锚点: 位置已有关键帧，写入失败（" + String(ePk) + "）"); return; }
        } else {
            pos.setValue([oldP[0] + dX, oldP[1] + dY]);
        }
        ap.setValue([ax, ay]);
        result.applied.push("锚点 -> " + key + (hadKeys ? "（位置写入当前时间关键帧）" : ""));
    } catch (e) { result.errors.push("锚点设置失败: " + String(e)); }
}

/* ---------------- 应用 ---------------- */
/* 撤销组 + 错误弹窗抑制：把一次「应用」变成 AE 里可整体 Ctrl+Z 的一步，
 * 并且在批处理/大数值迁移等场景不打断用户（AE 脚本规范要求）。 */
var FUI_UNDO_DEPTH = 0;
function fuiUndoBegin(name) {
    try {
        if (FUI_UNDO_DEPTH === 0) {
            try { app.beginUndoGroup(name || "CGArtLab FUI Data"); } catch (eU0) { }
            try { app.beginSuppressDialogs(); } catch (eS0) { }
        }
        FUI_UNDO_DEPTH++;
    } catch (eU) { }
}
function fuiUndoEnd() {
    try {
        if (FUI_UNDO_DEPTH > 0) { FUI_UNDO_DEPTH--; }
        if (FUI_UNDO_DEPTH === 0) {
            try { app.endSuppressDialogs(true); } catch (eS1) { }
            try { app.endUndoGroup(); } catch (eU1) { }
        }
    } catch (e) { }
}

function fuiApplyData(target, typeId, options) {
    fuiUndoBegin(typeId === "plainText" ? "FUI Data: 纯文本（只读）" : "FUI Data: " + String(typeId || ""));
    try {
        return fuiApplyDataCore(target, typeId, options);
    } finally {
        fuiUndoEnd();
    }
}

function fuiApplyDataCore(target, typeId, options) {
    options = options || {};
    var result = { ok: false, layer: target, errors: [], applied: [] };

    // 批量：Layer 数组
    if (target instanceof Array) {
        var okAll = true;
        var layers = [];
        var errAll = [];
        for (var i = 0; i < target.length; i++) {
            var r = fuiApplyData(target[i], typeId, options);
            layers.push(r.layer);
            if (!r.ok) { okAll = false; }
            for (var e = 0; e < r.errors.length; e++) { errAll.push(r.errors[e]); }
        }
        result.ok = okAll;
        result.layers = layers;
        result.errors = errAll;
        return result;
    }

    var layer = target;
    if (!layer) { result.errors.push("target 为空"); return result; }
    try { if (/^FUI前缀|^FUI后缀|^FUI单位|^FUI宽度/.test(layer.name)) { result.errors.push("跳过 FUI 辅助层"); return result; } } catch (eAff) { }

    var isText = false;
    try { isText = (layer instanceof TextLayer); } catch (eIs) { isText = false; }
    if (!isText) { result.errors.push("目标不是文本层（TextLayer）"); return result; }
    if (typeId === "plainText") {
        // 纯文本：格式/文字只读；仅允许用户显式设置锚点（Transform 属性，不碰 Source Text）。
        // 注意：这一段必须在任何「清理旧子层」之前返回，否则「只读」也会改动用户合成。
        if (options.anchor) { fuiApplyAnchor(layer, options.anchor, result); }
        result.ok = (result.errors.length === 0);
        result.applied.push(options.anchor ? (result.ok ? "纯文本：仅设置锚点" : "纯文本：锚点未识别") : "纯文本：只读，不修改图层");
        return result;
    }

    if (typeof FUIFormatCore === "undefined" || !FUIFormatCore) {
        result.errors.push("format_core 未加载");
        return result;
    }

    var spec = fuiMergeSpec(typeId, options, result.errors);
    if (!spec) { return result; }
    // 校验通过、且确定要写入后才清理历史辅助层；失败路径不再有机会删用户的层
    try { if (layer.containingComp) { fuiCleanupOrphanAffix(layer.containingComp); } } catch (eCO) { }
    // 人民币大写：即便只传标记也映射到 format
    if (spec.rmbUppercase) { spec.format = "rmbUppercase"; }

    // ★ 让 Value 滑块与"显示数值"完全一致：滑块以「选定显示单位」计；
    //   单位换算只在应用时对初值做一次；表达式只格式化、不再换算。
    var chosen = fuiUnitDesc(spec, (spec.unit !== undefined ? spec.unit : null));
    var chosenId = chosen ? chosen.id : (spec.unit || "");
    if (chosenId) { spec.unit = chosenId; }
    var isCurrency = (spec.format === "rmbUppercase") || (chosen && chosen.place === "prefix");

    var initVal;
    var detectedUnitDesc = null;
    if (options.value !== undefined && options.value !== null) {
        initVal = Number(options.value); // 视为已是显示单位
    } else {
        var txt0 = "";
        try { txt0 = layer.property("Source Text").value.text; } catch (eTxt0) { txt0 = ""; }
        var d0 = null;
        try { d0 = FUIFormatCore.detectParse(txt0); } catch (eD0) { d0 = null; }
        if (d0 && d0.isNumeric && d0.value !== null && d0.value !== undefined) {
            var dv = Number(d0.value);
            var du = fuiUnitDesc(spec, d0.unit);
            // 单位被拆成子层时，数字层文本不含单位，从 FUI单位 子层补读原单位，保证切换单位能正确换算
            if ((!d0.unit || d0.unit === "") && (!du)) {
                var ut = fuiFindUnitChildText(layer);
                if (ut) { du = fuiUnitDesc(spec, ut); }
            }
            // 货币：纯数字默认按基准货币（人民币）理解，以便正确换算到目标币种
            if (isCurrency && !du && chosen && chosen.id !== spec.baseUnit) { du = fuiUnitDesc(spec, spec.baseUnit); }
            if (du && chosen && du.id !== chosen.id) {
                try {
                    var rate = (spec.rate !== undefined && spec.rate !== null && spec.rate !== "") ? Number(spec.rate) : 0;
                    if (isCurrency && rate) {
                        // rate = 1 目标货币 折合多少基准货币（如 USD→CNY≈7.2）
                        if (chosen.id === spec.baseUnit) {
                            if (du && du.id !== spec.baseUnit) { dv = dv * rate; }   // 非基准 -> 基准：×rate
                        } else {
                            if (!du || du.id === spec.baseUnit) { dv = dv / rate; }  // 基准 -> 非基准：÷rate
                            // 两个非基准币种之间无多汇率，保持数值不变
                        }
                    } else {
                        dv = FUIFormatCore.convert(dv, du, chosen);
                    }
                } catch (eConv) {}
            }
            detectedUnitDesc = du;
            initVal = dv;
        } else {
            // 无法从文本还原数值（如人民币大写、纯符号等）：若已存在数值滑块则沿用其当前值，避免重置为 0
            var existingV = null;
            try {
                var exFx = null;
                try { exFx = layer.effect("数值"); } catch (eN1) { exFx = null; }
                if (!exFx) { try { exFx = layer.effect("Value"); } catch (eN2) { exFx = null; } }
                if (exFx) {
                    var exP = null, exPt = false;
                    try { var pPt = exFx.property("ADBE Point Control-0001"); if (pPt) { exP = pPt; exPt = true; } } catch (ePt0) { }
                    if (!exP) { try { var pSl = exFx.property("ADBE Slider Control-0001"); if (pSl) { exP = pSl; exPt = false; } } catch (eSl0) { } }
                    if (exP && exP.numKeys === 0) { var evv = exP.value; existingV = exPt ? evv[0] : evv; }
                }
            } catch (eEx) { existingV = null; }
            initVal = (existingV !== null && existingV !== undefined && !isNaN(Number(existingV))) ? Number(existingV) : 0;
        }
    }
    if (isNaN(initVal)) { initVal = 0; }

    try {
        var vc = fuiGetValueControl(layer, initVal, result, detectedUnitDesc, chosen);
        var valueProp = vc.prop;
        var valueIsPoint = vc.isPoint;
        if (valueProp.numKeys === 0) {
            valueProp.setValue(valueIsPoint ? [initVal, 0] : initVal);
            result.applied.push("数值初值 = " + initVal);
        } else {
            result.applied.push("数值已有关键帧，保留你的动画（不改初值）");
        }

        var behavior = (options.behavior !== undefined) ? options.behavior : "manual";
        spec.behavior = behavior;

        // 简化：数值只需可 K 帧；预设只套 AE 原生关键帧插值（Easy Ease/Linear/Hold）。
        // manual = 完全不碰关键帧、不加表达式，动画由用户在 AE 里手动控制。
        if (options.keyframes && options.keyframes.length > 0) {
            var ts = [], vs = [];
            for (var k = 0; k < options.keyframes.length; k++) {
                ts.push(Number(options.keyframes[k].time));
                vs.push(Number(options.keyframes[k].value));
            }
            if (valueIsPoint) {
                var vsP = [];
                for (var kp = 0; kp < vs.length; kp++) { vsP.push([vs[kp], 0]); }
                try { valueProp.setValuesAtTimes(ts, vsP); } catch (eKVP) { }
            } else {
                try { valueProp.setValuesAtTimes(ts, vs); } catch (eKV) { }
            }
        }
        if (behavior === "smooth" || behavior === "linear" || behavior === "hold") {
            var nk = valueProp.numKeys;
            for (var kk = 1; kk <= nk; kk++) {
                try {
                    if (behavior === "smooth") {
                        valueProp.setInterpolationTypeAtKey(kk, KeyframeInterpolationType.BEZIER, KeyframeInterpolationType.BEZIER);
                        try { valueProp.setTemporalEaseAtKey(kk, [new KeyframeEase(0, 33.33)], [new KeyframeEase(0, 33.33)]); } catch (eEase) {}
                    } else if (behavior === "linear") {
                        valueProp.setInterpolationTypeAtKey(kk, KeyframeInterpolationType.LINEAR, KeyframeInterpolationType.LINEAR);
                    } else {
                        valueProp.setInterpolationTypeAtKey(kk, KeyframeInterpolationType.HOLD, KeyframeInterpolationType.HOLD);
                    }
                } catch (eI) {}
            }
            result.applied.push("关键帧插值(AE原生): " + behavior + " · " + nk + " 帧");
        } else {
            result.applied.push("关键帧保持手动（未套预设，可自行在 AE 调缓动）");
        }

        // 在图层上加可 K 帧的 FUI_* 效果控件（Effect Controls 可见）
        fuiEnsureControls(layer, spec, result);

        // Source Text 表达式
        var srcText = layer.property("Source Text");
        if (!srcText) {
            result.errors.push("目标缺少 Source Text 属性");
            return result;
        }
        // 文字颜色（可选，先设样式，表达式返回字符串会沿用）
        if (options.color && options.color.length >= 3) { fuiApplyTextColor(layer, srcText, options.color, result); }
        // 颜色也做成 Effect Controls 的「颜色」Fill 效果：可直接调、可K帧
        var curFill = [1, 1, 1]; try { curFill = srcText.value.fillColor; } catch (eCF) { curFill = [1, 1, 1]; }
        fuiEnsureColorFx(layer, (options.color && options.color.length >= 3) ? options.color : curFill, !!(options.color && options.color.length >= 3), result, !!(options.color && options.color.length >= 3));
        // 字体（可选）
        if (options.font) { fuiApplyFont(layer, srcText, options.font, result); }
        // 字号（可选）
        if (options.fontSize !== undefined && options.fontSize !== null && options.fontSize !== "") { fuiApplyFontSize(layer, srcText, options.fontSize, result); }
        // 数字对齐（左/中/右）
        if (options.align) { fuiApplyAlign(layer, srcText, options.align, result); }
        // 统一字距：让小数点与字符间距和普通字符一致（tracking 可调）
        fuiApplyTypography(layer, srcText, options, result);
        // 前后缀独立层（思源黑体），数字层保持原字体
        var aff = fuiApplyAffix(layer, spec, result);
        var useAffix = !!(aff && aff.any);
        var exprSpec = fuiClone(spec);
        if (useAffix) { exprSpec.prefix = ""; exprSpec.suffix = ""; exprSpec.prefixSpace = 0; exprSpec.suffixSpace = 0; exprSpec.omitUnit = !!aff.unit; exprSpec.noSign = !!aff.unitPrefix; }
        if (chosenId) {
            exprSpec.unit = chosenId;
            exprSpec.baseUnit = chosenId;   // 使 convertDisplay 视为基准单位，不再乘 rate/offset
            exprSpec.rate = 1;
            if (exprSpec.units) {
                for (var ui = 0; ui < exprSpec.units.length; ui++) {
                    if (exprSpec.units[ui].id === chosenId) { exprSpec.units[ui].factor = 1; exprSpec.units[ui].offset = 0; }
                }
            }
        } else { exprSpec.rate = 1; }
        // 将当前字号烘焙进 spec，使「像素间距」按真实字号换算为等值字符间隔
        try { exprSpec.__fontSize = (srcText.value && srcText.value.fontSize) ? srcText.value.fontSize : 14; } catch (eFS) { exprSpec.__fontSize = 14; }
        var expr = fuiBuildSourceExpr(exprSpec);
        srcText.expression = expr;
        try { srcText.expressionEnabled = true; } catch (eEn2) {}
        result.applied.push("Source Text 表达式已设（formatValue）");

        // 锚点预设（可选，放在表达式之后，让边界反映格式化后的文本）
        if (options.anchor) { fuiApplyAnchor(layer, options.anchor, result); }

        // 在 layer.comment 写入类型标记，解决 "%(含氧/百分比)、g(重量/加速度)、g/L(密度/浓度)" 等回读歧义
        try {
            var prevCmt = String(layer.comment || "");
            prevCmt = prevCmt.replace(/FUI_TYPE:[A-Za-z0-9_\-]+/g, "").replace(/FUI_UNIT:[^\s]+/g, "").replace(/\s+/g, " ").replace(/^\s+|\s+$/g, "");
            layer.comment = (prevCmt ? prevCmt + " " : "") + "FUI_TYPE:" + typeId + (chosenId ? " FUI_UNIT:" + chosenId : "");
        } catch (eCmt) { }

        result.ok = true;
    } catch (eApply) {
        result.errors.push("apply 异常: " + String(eApply) +
            " @" + (eApply.line !== undefined ? eApply.line : "?"));
        result.ok = false;
    }
    return result;
}






