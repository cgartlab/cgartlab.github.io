/**
 * license_gate.jsx —— JSX 侧授权闸门（ExtendScript / ES3）
 * © 2026 CGArtLab · https://cgartlab.com · CGArtLab FUI Data
 * ------------------------------------------------------------------
 * 面板用 evalScript 推来一个 HMAC 令牌（fuiLicenseSetToken），这里：
 *   1. 校验令牌（HMAC / 机器指纹 / 到期）
 *   2. 提供 fuiLicenseRequire(权限位)，供各写入入口拦截
 *   3. 提供全量规格解密（datatype_spec.enc）
 *   4. 维护试用起始时间（写进 AE 偏好，清浏览器缓存不会重置）
 *
 * 设计取舍：ExtendScript 没有 BigInt，做不了 RSA 验签，所以签名校验在面板侧；
 * 这里只信任“带正确 HMAC 且与本机指纹一致”的令牌 —— 目标是提高改造成本，
 * 不是密码学边界。
 */
(function () {
    var G = $.global;
    var STATE = {
        token: null,
        licensed: false,
        plan: "none",
        ents: [],
        code: "",
        fp: "",
        specKey: ""
    };
    var TRIAL_PREF = "FUI_TRIAL_START";
    var RAWID_KEY = "cgartlab_fui_raw_machine_id_v1";

    var CORE_MTIME = "";

    function corePath() {
        try {
            var here = File($.fileName).parent;
            var p = File(here.fsName + "/license_core.js");
            if (!p.exists) { p = File(here.fsName + "/../src/license_core.js"); }
            if (!p.exists) { p = null; }
            return p;
        } catch (e) { return null; }
    }

    function core() {
        var p = corePath();
        // 开发/升级场景：license_core.js 被替换后必须重新加载，
        // 否则 AE 会一直用 $.global 里旧版本（改完“没生效”的经典坑）。
        var stamp = "";
        try { if (p) { stamp = String(p.modified.getTime()) + "|" + p.length; } } catch (eS) { stamp = ""; }
        var needLoad = !G.FuiLicenseCore || (stamp !== "" && stamp !== CORE_MTIME);
        if (needLoad) {
            if (!p) { throw new Error("license_core.js 未找到"); }
            $.evalFile(p);
            CORE_MTIME = stamp;
        }
        return G.FuiLicenseCore;
    }

    function nowMs() { return (new Date()).getTime(); }

    function callShell(cmd) {
        try {
            var out = system.callSystem(cmd);
            return out ? String(out) : "";
        } catch (e) {
            return "";
        }
    }

    function prefType() {
        try { return PREF_Type_MACHINE_INDEPENDENT; } catch (e) { return 2; }
    }

    function prefsGet(key) {
        try {
            var v = app.preferences.getPrefAsString("CGArtLab FUI Data", key, prefType());
            return v === undefined || v === null ? "" : String(v);
        } catch (e) {
            return "";
        }
    }

    function prefsSet(key, value) {
        try {
            app.preferences.savePrefAsString("CGArtLab FUI Data", key, String(value), prefType());
            return true;
        } catch (e) {
            return false;
        }
    }

    function readRawMachineId() {
        var cached = prefsGet(RAWID_KEY);
        // 只有「强 ID」才可以直接复用缓存。弱兜底（fallback|主机名|OS）依赖主机名，
        // 而且可能是某次 callSystem 被禁用时算出来的：必须每次重试强 ID，
        // 否则以后即使能读到 BIOS UUID 也会一直用弱值，导致正版用户机器码不匹配。
        var cachedStrong = cached && cached.length > 6 && cached.indexOf("fallback|") !== 0;
        if (cachedStrong) { return cached; }

        var os = "";
        try { os = String($.os).toLowerCase(); } catch (e0) { os = ""; }
        var raw = "";

        if (os.indexOf("windows") >= 0) {
            // Win11 24H2 起默认没有 wmic，先用 PowerShell，再退回 wmic
            var ps = callShell('powershell -NoProfile -ExecutionPolicy Bypass -Command "(Get-CimInstance Win32_ComputerSystemProduct).UUID"');
            var m = ps.match(/[0-9A-Fa-f]{8}-[0-9A-Fa-f]{4}-[0-9A-Fa-f]{4}-[0-9A-Fa-f]{4}-[0-9A-Fa-f]{12}/);
            if (m) { raw = m[0]; }
            if (!raw) {
                var wm = callShell('cmd /c "wmic csproduct get uuid /value"');
                var m2 = wm.match(/[0-9A-Fa-f]{8}-[0-9A-Fa-f]{4}-[0-9A-Fa-f]{4}-[0-9A-Fa-f]{4}-[0-9A-Fa-f]{12}/);
                if (m2) { raw = m2[0]; }
            }
        } else {
            var io = callShell('ioreg -rd1 -c IOPlatformExpertDevice | grep IOPlatformUUID');
            var m3 = io.match(/"IOPlatformUUID"\s*=\s*"([^"]+)"/);
            if (m3) { raw = m3[1]; }
        }

        if (!raw) {
            // 兜底：主机名 + 系统信息（弱，但不至于完全没有机器码）
            var host = "";
            try { host = $.getenv("COMPUTERNAME") || $.getenv("HOSTNAME") || ""; } catch (e1) { host = ""; }
            raw = "fallback|" + host + "|" + os;
        }

        prefsSet(RAWID_KEY, raw);
        return raw;
    }

    /* ---------------- 对外函数 ---------------- */

    function fuiLicenseFingerprint() {
        var c;
        try { c = core(); } catch (e) {
            return JSON.stringify({ ok: false, error: String(e) });
        }
        var raw = readRawMachineId();
        var code = c.machineCode(raw);
        var fp = c.fp16(raw);
        STATE.code = code;
        STATE.fp = fp;
        // weak=true 表示没读到 BIOS UUID，用的是主机名兜底：
        // 机器码可用但不稳（改主机名会变），面板需要提示用户开启
        // 「允许脚本写入文件与访问网络」后重启，才能拿到稳定机器码。
        var weak = String(raw).indexOf("fallback|") === 0;
        return JSON.stringify({ ok: true, code: code, fp: fp, raw: raw, weak: weak });
    }

    function fuiLicenseSetToken(json) {
        var c = core();
        var token = null;
        try { token = JSON.parse(json); } catch (e) { token = null; }

        if (!STATE.fp) { fuiLicenseFingerprint(); }
        var r = c.verifyToken(token, STATE.fp, nowMs());
        if (!r.ok) {
            STATE.token = null;
            STATE.licensed = false;
            STATE.plan = "none";
            STATE.ents = [];
            STATE.specKey = "";
            return JSON.stringify({ ok: false, reason: r.reason });
        }
        STATE.token = token;
        STATE.licensed = true;
        STATE.plan = r.plan;
        STATE.ents = r.ents || [];
        STATE.specKey = r.specKey || "";
        // 全量规格改由云端 /v1/spec 下发并 setRegistry；本机不再内嵌试用解密密钥。
        // 本地令牌只保留 license 里的 sk（若存在），否则保持空。
        return JSON.stringify({ ok: true, plan: STATE.plan, ents: STATE.ents });
    }

    function fuiLicenseState() {
        return JSON.stringify({
            ok: true,
            licensed: STATE.licensed,
            plan: STATE.plan,
            ents: STATE.ents || [],
            code: STATE.code,
            hasSpecKey: !!STATE.specKey
        });
    }

    /** 权限位：licensed 且令牌未过期时放行；试用只放行基础功能（由调用方决定） */
    function fuiLicenseRequire(ent) {
        if (!STATE.licensed) { return false; }
        var c = core();
        return c.hasEnt(STATE.ents, ent) || c.hasEnt(STATE.ents, "all_types");
    }

    /** 试用/免费档能用的类型 id 列表 */
    function fuiLicenseFreeTypes() {
        var c = core();
        return JSON.stringify(c.FREE_TYPE_IDS);
    }

    function fuiLicenseTrialStart() {
        var iso = prefsGet(TRIAL_PREF);
        return JSON.stringify({ ok: true, start: iso || "" });
    }

    function fuiLicenseSetTrialStart(iso) {
        if (!prefsGet(TRIAL_PREF) || prefsGet(TRIAL_PREF) === "") {
            prefsSet(TRIAL_PREF, iso);
            return JSON.stringify({ ok: true, start: iso });
        }
        return JSON.stringify({ ok: true, start: prefsGet(TRIAL_PREF) });
    }

    /**
     * 解密全量规格。没许可证时抛错，调用方退回免费子集。
     * @param {string} encPath datatype_spec.enc 的绝对路径
     */
    var SPEC_CACHE = { key: "", text: "" };
    function fuiLicenseDecryptSpec(encPath) {
        if (!STATE.licensed || !STATE.specKey) { throw new Error("LICENSE_REQUIRED"); }
        var c = core();
        var f = File(encPath);
        if (!f.exists) { throw new Error("SPEC_NOT_FOUND"); }
        // 解密结果按「文件 mtime + 长度 + 许可证密钥」缓存：
        // 面板每次打开都会重载注册表，不缓存的话每次都要重新解密 42 KB。
        var stamp = "";
        try { stamp = String(f.modified.getTime()) + "|" + f.length + "|" + STATE.specKey.substring(0, 8); } catch (eS) { stamp = ""; }
        if (stamp && SPEC_CACHE.key === stamp && SPEC_CACHE.text) { return SPEC_CACHE.text; }
        f.encoding = "UTF-8";
        f.open("r");
        var text = f.read();
        f.close();
        var box = JSON.parse(text);
        var plain = c.decryptPayload(STATE.specKey, box);
        if (stamp) { SPEC_CACHE.key = stamp; SPEC_CACHE.text = plain; }
        return plain;
    }

    /** 「有全量权限」：正式许可证或试用期全功能。批量/规格解密都按这个判定。 */
    function fuiLicenseIsPaid() {
        var c = core();
        return !!(STATE.licensed && c.hasEnt(STATE.ents, "all_types"));
    }

    /** 云端授权：面板从 API 拿到规格并注入后调用，等价「已授权 all_types」 */
    function fuiLicenseSetCloud(json) {
        var info = {};
        try { info = JSON.parse(json) || {}; } catch (eC) { info = {}; }
        STATE.licensed = true;
        STATE.plan = info.plan || "buyout";
        var ents = ["all_types", "batch"];
        if (info.ents && info.ents.length) {
            for (var i = 0; i < info.ents.length; i++) {
                if (ents.indexOf(info.ents[i]) < 0) { ents.push(info.ents[i]); }
            }
        }
        STATE.ents = ents;
        STATE.specKey = "";
        return JSON.stringify({ ok: true, plan: STATE.plan, ents: STATE.ents });
    }

    G.fuiLicenseFingerprint = fuiLicenseFingerprint;
    G.fuiLicenseSetCloud = fuiLicenseSetCloud;
    G.fuiLicenseSetToken = fuiLicenseSetToken;
    G.fuiLicenseState = fuiLicenseState;
    G.fuiLicenseRequire = fuiLicenseRequire;
    G.fuiLicenseFreeTypes = fuiLicenseFreeTypes;
    G.fuiLicenseTrialStart = fuiLicenseTrialStart;
    G.fuiLicenseSetTrialStart = fuiLicenseSetTrialStart;
    G.fuiLicenseDecryptSpec = fuiLicenseDecryptSpec;
    G.fuiLicenseIsPaid = fuiLicenseIsPaid;
})();



