<#
.SYNOPSIS
  CGArtLab FUI Data —— 一键安装脚本（Windows / After Effects 2023+）

.DESCRIPTION
  给第一次安装的人用：不需要懂代码，按提示走完即可。

  它做四件事：
    1. 检查插件文件是否齐全（缺文件会直接告诉你缺哪个）
    2. 把插件复制到 AE 的 CEP 扩展目录
    3. 打开「未签名扩展」的加载开关（PlayerDebugMode）
    4. 自检，并告诉你下一步该做什么

.USAGE
  最简单：在资源管理器里右键 install.ps1 -> 「使用 PowerShell 运行」
  或者双击同目录的 install.cmd

  也可以手动打开 PowerShell 执行：
    pwsh -ExecutionPolicy Bypass -File .\install.ps1
    pwsh -ExecutionPolicy Bypass -File .\install.ps1 -VerifyOnly   # 只检查，不安装
    pwsh -ExecutionPolicy Bypass -File .\install.ps1 -Force        # 跳过确认

.NOTES
  不需要管理员权限：扩展目录在 %APPDATA%，注册表写在 HKCU。
  不会修改任何 After Effects 工程文件。
#>

[CmdletBinding()]
param(
    [switch]$VerifyOnly,
    [switch]$Force
)

$ErrorActionPreference = 'Stop'

$ExtensionId       = 'com.cgartlab.fui.controller'
$DisplayName       = 'CGArtLab FUI Data'
$RequiredFiles     = @(
    'index.html',
    'CSXS\manifest.xml',
    'js\panel.js',
    'js\config_builder.js',
    'js\CSInterface.js',
    'jsx\fui_panel_host.jsx',
    'jsx\format_core.js',
    'jsx\datatype_apply.jsx'
)
# AE 2020~2024 的 CEP 版本号；一次性都写上，避免新手搞错版本
$CsxsVersions      = @('10', '11', '12')

function Write-Title($text) {
    Write-Host ''
    Write-Host ('=' * 62) -ForegroundColor DarkCyan
    Write-Host "  $text" -ForegroundColor Cyan
    Write-Host ('=' * 62) -ForegroundColor DarkCyan
}

function Write-Step($n, $text) {
    Write-Host ''
    Write-Host "[$n] $text" -ForegroundColor Yellow
}

function Write-Ok($text)   { Write-Host "    ✓ $text" -ForegroundColor Green }
function Write-Warn2($text){ Write-Host "    ! $text" -ForegroundColor Yellow }
function Write-Bad($text)  { Write-Host "    ✗ $text" -ForegroundColor Red }
function Write-Info($text) { Write-Host "      $text" -ForegroundColor Gray }

# ----------------------------------------------------------------------------
# 1. 找到插件源目录
# ----------------------------------------------------------------------------
Write-Title "$DisplayName 安装程序"

Write-Step 1 '定位插件文件'

$candidates = @(
    (Join-Path $PSScriptRoot 'tools\ui-behaviour-v1\panel'),
    (Join-Path $PSScriptRoot 'panel'),
    (Join-Path (Split-Path $PSScriptRoot -Parent) 'tools\ui-behaviour-v1\panel')
)

$panelDir = $null
foreach ($c in $candidates) {
    if (Test-Path (Join-Path $c 'CSXS\manifest.xml')) { $panelDir = $c; break }
}

if (-not $panelDir) {
    Write-Bad '没有找到插件文件（panel\CSXS\manifest.xml）'
    Write-Info '请确认 install.ps1 就放在项目根目录（能看到 tools 文件夹的那一层），然后重新运行。'
    Write-Info ('当前脚本位置：' + $PSScriptRoot)
    exit 1
}

Write-Ok "插件目录：$panelDir"

$missing = @()
foreach ($f in $RequiredFiles) {
    if (-not (Test-Path (Join-Path $panelDir $f))) { $missing += $f }
}
if ($missing.Count -gt 0) {
    Write-Bad '插件文件不完整，缺少：'
    foreach ($m in $missing) { Write-Info "  - $m" }
    Write-Info '请重新获取完整的插件目录后再安装。'
    exit 1
}
Write-Ok "关键文件齐全（$($RequiredFiles.Count) 项）"

# 读取版本号
$manifestPath = Join-Path $panelDir 'CSXS\manifest.xml'
$manifestText = Get-Content $manifestPath -Raw -Encoding UTF8
$version = 'unknown'
if ($manifestText -match 'ExtensionBundleVersion="([^"]+)"') { $version = $Matches[1] }
Write-Ok "插件版本：$version"

# 提示授权档位（新手最容易困惑的点）
$encPath  = Join-Path $panelDir 'jsx\datatype_spec.enc'
$freePath = Join-Path $panelDir 'jsx\datatype_spec.free.json'
$plainPath= Join-Path $panelDir 'jsx\datatype_spec.json'
if (Test-Path $encPath) {
    Write-Info '授权说明：安装后有 14 天全功能试用（34 类 / 173 单位，含批量应用）。'
    Write-Info '          试用到期后回落到 4 类免费档；在面板右上角点开状态条，可看到机器码并粘贴许可证。'
}
if (Test-Path $plainPath) {
    Write-Warn2 '检测到明文规格 datatype_spec.json（开发用）。正式分发版本不应包含它。'
}

$dest = Join-Path $env:APPDATA "Adobe\CEP\extensions\$ExtensionId"

# ----------------------------------------------------------------------------
# 2. 只检查模式
# ----------------------------------------------------------------------------
if ($VerifyOnly) {
    Write-Step 'V' '仅检查（不安装）'
    if (-not (Test-Path $dest)) {
        Write-Bad "尚未安装：$dest 不存在"
        exit 1
    }
    $bad = 0
    foreach ($f in $RequiredFiles) {
        if (Test-Path (Join-Path $dest $f)) { Write-Ok $f } else { Write-Bad "缺少 $f"; $bad++ }
    }
    $regOk = $false
    foreach ($v in $CsxsVersions) {
        $key = "HKCU:\Software\Adobe\CSXS.$v"
        if (Test-Path $key) {
            $val = (Get-ItemProperty -Path $key -Name PlayerDebugMode -ErrorAction SilentlyContinue).PlayerDebugMode
            if ($val -eq '1') { $regOk = $true; Write-Ok "PlayerDebugMode 已开启（CSXS.$v）"; break }
        }
    }
    if (-not $regOk) { Write-Warn2 'PlayerDebugMode 未开启，未签名扩展不会被加载' }
    if ($bad -eq 0) { Write-Host ''; Write-Ok '检查通过'; exit 0 } else { exit 1 }
}

# ----------------------------------------------------------------------------
# 3. 确认 AE 是否在运行
# ----------------------------------------------------------------------------
Write-Step 2 '检查 After Effects 是否在运行'

$aeProcs = @(Get-Process -Name 'AfterFX' -ErrorAction SilentlyContinue)
if ($aeProcs.Count -gt 0) {
    Write-Warn2 'After Effects 正在运行。它不会重新扫描扩展目录，安装后必须重启 AE。'
    if (-not $Force) {
        $ans = Read-Host '    继续安装吗？（安装不会动你的工程，只是复制文件） [Y/n]'
        if ($ans -and $ans.Trim() -notmatch '^(y|Y|yes|是|好)') {
            Write-Info '已取消。请先关闭 After Effects 再运行本脚本。'
            exit 0
        }
    }
} else {
    Write-Ok 'After Effects 未运行'
}

# ----------------------------------------------------------------------------
# 4. 复制文件（干净同步：先清掉源目录里已不存在的旧文件）
# ----------------------------------------------------------------------------
Write-Step 3 "复制插件到扩展目录"
Write-Info $dest

New-Item -ItemType Directory -Force -Path $dest | Out-Null

# 计算源目录的相对路径清单
$srcRoot = (Resolve-Path $panelDir).Path
$srcFiles = @{}
Get-ChildItem -LiteralPath $srcRoot -Recurse -File | ForEach-Object {
    $srcFiles[$_.FullName.Substring($srcRoot.Length).TrimStart('\')] = $true
}

# 清掉目标目录里「源目录已经没有」的旧文件
# 这一条很关键：旧版本可能残留 jsx\datatype_spec.json（明文规格），
# 不清掉会让未授权用户绕过授权直接拿到全部类型。
$stale = @()
if (Test-Path $dest) {
    Get-ChildItem -LiteralPath $dest -Recurse -File | ForEach-Object {
        $rel = $_.FullName.Substring((Resolve-Path $dest).Path.Length).TrimStart('\')
        if (-not $srcFiles.ContainsKey($rel)) { $stale += $rel }
    }
}
foreach ($rel in $stale) {
    $p = Join-Path $dest $rel
    try { Remove-Item -LiteralPath $p -Force; Write-Warn2 "已清理旧版本残留：$rel" } catch { Write-Warn2 "无法清理残留：$rel" }
}
# 清理因此变空的目录
if ($stale.Count -gt 0) {
    Get-ChildItem -LiteralPath $dest -Recurse -Directory |
        Sort-Object FullName -Descending |
        Where-Object { -not (Get-ChildItem -LiteralPath $_.FullName -Force) } |
        ForEach-Object { try { Remove-Item -LiteralPath $_.FullName -Force } catch { } }
}

Copy-Item -Path (Join-Path $panelDir '*') -Destination $dest -Recurse -Force
Write-Ok '文件复制完成'
if ($stale.Count -gt 0) {
    Write-Ok "已移除 $($stale.Count) 个旧版本文件（避免旧文件干扰新版行为）"
}

# ----------------------------------------------------------------------------
# 5. 打开未签名扩展加载开关
# ----------------------------------------------------------------------------
Write-Step 4 '打开未签名扩展加载开关（PlayerDebugMode）'

foreach ($v in $CsxsVersions) {
    $key = "HKCU:\Software\Adobe\CSXS.$v"
    New-Item -Path $key -Force | Out-Null
    New-ItemProperty -Path $key -Name PlayerDebugMode -Value '1' -PropertyType String -Force | Out-Null
}
Write-Ok "已设置 CSXS.$($CsxsVersions -join ' / CSXS.') 的 PlayerDebugMode = 1"
Write-Info '注意：类型必须是字符串。写成数字（DWORD）AE 可能读不到。'

# ----------------------------------------------------------------------------
# 6. 自检
# ----------------------------------------------------------------------------
Write-Step 5 '安装自检'

$fail = 0
foreach ($f in $RequiredFiles) {
    if (Test-Path (Join-Path $dest $f)) { Write-Ok $f } else { Write-Bad "缺少 $f"; $fail++ }
}

$installedVersion = 'unknown'
$installedManifest = Join-Path $dest 'CSXS\manifest.xml'
if (Test-Path $installedManifest) {
    $t = Get-Content $installedManifest -Raw -Encoding UTF8
    if ($t -match 'ExtensionBundleVersion="([^"]+)"') { $installedVersion = $Matches[1] }
}
Write-Ok "已安装版本：$installedVersion"

$regFail = 0
foreach ($v in $CsxsVersions) {
    $val = (Get-ItemProperty -Path "HKCU:\Software\Adobe\CSXS.$v" -Name PlayerDebugMode -ErrorAction SilentlyContinue).PlayerDebugMode
    if ($val -ne '1') { $regFail++ }
}
if ($regFail -eq 0) { Write-Ok '注册表开关读取正常' } else { Write-Bad '注册表开关读取失败'; $fail++ }

# ----------------------------------------------------------------------------
# 7. 下一步
# ----------------------------------------------------------------------------
Write-Title '安装完成，下一步'

if ($fail -gt 0) {
    Write-Bad "有 $fail 项自检未通过，请先按上面的 ✗ 处理。"
    exit 1
}

Write-Host @"
  1. 重启 After Effects（如果它本来开着）
  2. 菜单：窗口 > 扩展 > $DisplayName
  3. 面板右上角会显示授权状态：
       · 未激活 → 显示「试用 · 全功能 · 剩 N 天」，14 天内全部功能可用；到期后 4 类
       · 已购买 → 点开状态条，复制机器码，粘贴许可证，点「激活」，解锁 34 类
  4. 验证面板在工作（约 1 分钟）：
       · 新建合成 → 新建文字图层 → 输入 22.0 °C
       · 在 AE 里选中该图层，面板会自动读一次文字并把类型填成「温度」（无需点检测）
       · 点【应用】
       · 图层出现「数值」效果控件，画面显示 22.0 °C → 安装成功

  出问题看：docs\manual\05-故障排查.md
  卸载：删掉 %APPDATA%\Adobe\CEP\extensions\$ExtensionId，或运行 uninstall.cmd（不想确认可加 -Force）
"@ -ForegroundColor Gray

Write-Host ''
if (-not $Force) { Read-Host '按回车键关闭窗口' | Out-Null }
