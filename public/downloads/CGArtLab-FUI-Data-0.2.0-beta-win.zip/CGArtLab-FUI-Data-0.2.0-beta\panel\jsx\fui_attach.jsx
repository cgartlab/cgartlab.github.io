/**
 * fui_attach.jsx —— 挂载器（ES3，脚本侧，只在 AE 内执行）
 * ------------------------------------------------------------------
 * fuiAttach(config, compItem)：
 *   1) 定位合成：优先用 compItem，否则 app.project.activeItem（必须是 CompItem）；
 *   2) 确保 MASTER 层存在：State(默认 0/3/5s = 0/1/2)、Transition(0.8)、Ease(2)；
 *   3) 逐个 elements：按层名取层，按 role 注入/复用 Expression Controls、设表达式、启用表达式；
 *   4) 返回 { ok, applied, errors }；层缺失或单元素失败记入 errors 但不中断。
 * 只改动 MASTER 与 elements 目标层，不碰其它图层；不保存工程；undo/suppressDialogs 包裹。
 * 表达式公式来自 fui_roles.jsx（引用 MASTER 的 State/Transition/Ease）。
 */
function fuiAttach(config, compItem) {
    var result = { ok: false, applied: [], errors: [] };

    var comp = compItem ? compItem : app.project.activeItem;
    if (!comp || !(comp instanceof CompItem)) {
        result.errors.push("未找到有效 CompItem：请显式传入 compItem 或在 AE 中激活一个合成");
        return result;
    }
    if (!config || typeof config !== "object") {
        result.errors.push("config 缺失或不是对象");
        return result;
    }

    try { app.beginSuppressDialogs(0); } catch (eSuppress) {}

    try {
        app.beginUndoGroup("FUI Attach");
        var masterName = config.masterLayerName ? String(config.masterLayerName) : "MASTER";
        var master = fuiEnsureMaster(comp, masterName, config.master, result);

        var elements = config.elements ? config.elements : [];
        for (var i = 0; i < elements.length; i++) {
            fuiApplyElement(comp, master, elements[i], i, result);
        }

        // 单元素错误不阻断，只要没有致命异常即视为执行完成
        result.ok = true;
    } catch (eFatal) {
        result.errors.push("fatal: " + String(eFatal) +
            " @" + (eFatal.line !== undefined ? eFatal.line : "?"));
        result.ok = false;
    } finally {
        try { app.endUndoGroup(); } catch (eUndo) {}
        try { app.endSuppressDialogs(true); } catch (eRestore) {}
    }

    return result;
}

/* ---------- MASTER ---------- */
function fuiEnsureMaster(comp, name, masterCfg, result) {
    var master = fuiFindLayerByName(comp, name);
    if (!master) {
        master = comp.layers.addNull(comp.duration);
        master.name = name;
        try { master.moveToBeginning(); } catch (eMove) {}
        result.applied.push("新建 MASTER 层: " + name);
    } else {
        result.applied.push("复用已有 MASTER 层: " + name);
    }

    var defTransition = (masterCfg && masterCfg.transition !== undefined) ? Number(masterCfg.transition) : 0.8;
    var defEase = (masterCfg && masterCfg.ease !== undefined) ? Number(masterCfg.ease) : 2;

    // State：确保存在；仅当没有关键帧时补默认关键帧（不覆盖用户已有 K 帧）
    var stateFx = fuiGetOrAddSlider(master, "State", 0, result);
    var stateP = stateFx.property("ADBE Slider Control-0001");
    if (stateP.numKeys === 0) {
        var keys = (masterCfg && masterCfg.stateKeys) ? masterCfg.stateKeys : null;
        var tArr = [];
        var vArr = [];
        if (keys && keys.length > 0) {
            for (var k = 0; k < keys.length; k++) {
                tArr.push(Number(keys[k][0]));
                vArr.push(Number(keys[k][1]));
            }
            result.applied.push("State 关键帧: 自定义 " + keys.length + " 帧");
        } else {
            tArr = [0, 3, 5];
            vArr = [0, 1, 2];
            result.applied.push("State 关键帧: 0/3/5s = 0/1/2");
        }
        try { stateP.setValuesAtTimes(tArr, vArr); } catch (eKeys) {
            // 极端情况下回退为逐帧
            for (var kk = 0; kk < tArr.length; kk++) { stateP.setValueAtTime(tArr[kk], vArr[kk]); }
        }
    } else {
        result.applied.push("State 已有 " + stateP.numKeys + " 个关键帧，保留不动");
    }

    fuiGetOrAddSlider(master, "Transition", defTransition, result);
    fuiGetOrAddSlider(master, "Ease", defEase, result);

    return master;
}

/* ---------- 单个元素 ---------- */
function fuiApplyElement(comp, master, el, index, result) {
    if (!el || !el.layer) {
        result.errors.push("elements[" + index + "]: 缺少 layer 字段");
        return;
    }
    var layerName = String(el.layer);
    var role = el.role ? String(el.role) : "";
    var params = el.params ? el.params : {};

    var layer = fuiFindLayerByName(comp, layerName);
    if (!layer) {
        result.errors.push("elements[" + index + "]: 层未找到: " + layerName);
        return;
    }

    var expr;
    try {
        expr = fuiBuildExpr(role, params);
    } catch (eBuild) {
        result.errors.push("elements[" + index + "] (" + layerName + "): 生成表达式失败: " + String(eBuild));
        return;
    }

    try {
        // 先注入/复用元素级 Expression Controls（表达式会读取）
        fuiEnsureElementControls(layer, role, params, result);

        if (role === "dataText" || role === "statusText") {
            var srcText = layer.property("Source Text");
            fuiSetExpression(srcText, expr, layerName + " -> Source Text (" + role + ")", result);
        } else if (role === "progress") {
            var scaleProp = layer.property("ADBE Transform Group").property("ADBE Scale");
            fuiSetExpression(scaleProp, expr, layerName + " -> Scale (" + role + ")", result);
            fuiSetProgressAnchor(layer, (params.axis === "y") ? "y" : "x", result);
        } else if (role === "statusColor") {
            var fillProp = fuiFindFillColorProp(layer);
            if (!fillProp) {
                result.errors.push(layerName + ": 未找到矢量填充色属性 (ADBE Vector Fill Color)");
                return;
            }
            fuiSetExpression(fillProp, expr, layerName + " -> Vector Fill Color (" + role + ")", result);
        } else {
            result.errors.push("elements[" + index + "] (" + layerName + "): 未知 role: " + role);
        }
    } catch (eApply) {
        result.errors.push("elements[" + index + "] (" + layerName + "): 应用失败: " + String(eApply));
    }
}

/* ---------- 元素控件 ---------- */
function fuiEnsureElementControls(layer, role, params, result) {
    if (role === "dataText") {
        fuiGetOrAddSlider(layer, "fui_decimals", fuiDefault(params.decimals, 0), result);
        fuiGetOrAddSlider(layer, "fui_padding", fuiDefault(params.padding, 0), result);
        fuiGetOrAddCheckbox(layer, "fui_thousands", (params.thousands ? 1 : 0), result);
    } else if (role === "progress") {
        fuiGetOrAddSlider(layer, "fui_min", fuiDefault(params.min, 0), result);
        fuiGetOrAddSlider(layer, "fui_max", fuiDefault(params.max, 100), result);
    }
    // statusColor / statusText 无标量参数，直接读 MASTER，无需元素控件
}

function fuiDefault(v, d) {
    return (v === undefined || v === null) ? d : v;
}

function fuiGetOrAddSlider(layer, name, defVal, result) {
    var fx = null;
    try { fx = layer.effect(name); } catch (eFind) { fx = null; }
    if (fx) {
        result.applied.push("复用控件 " + name + " @ " + layer.name);
        return fx;
    }
    var parade = layer.property("ADBE Effect Parade");
    fx = parade.addProperty("ADBE Slider Control");
    fx.name = name;
    fx.property("ADBE Slider Control-0001").setValue(Number(defVal));
    result.applied.push("新增控件 " + name + "=" + defVal + " @ " + layer.name);
    return fx;
}

function fuiGetOrAddCheckbox(layer, name, defVal, result) {
    var fx = null;
    try { fx = layer.effect(name); } catch (eFind) { fx = null; }
    if (fx) {
        result.applied.push("复用控件 " + name + " @ " + layer.name);
        return fx;
    }
    var parade = layer.property("ADBE Effect Parade");
    fx = parade.addProperty("ADBE Checkbox Control");
    fx.name = name;
    fx.property("ADBE Checkbox Control-0001").setValue(defVal ? 1 : 0);
    result.applied.push("新增控件 " + name + "=" + (defVal ? 1 : 0) + " @ " + layer.name);
    return fx;
}

/* ---------- 表达式指派 ---------- */
function fuiSetExpression(prop, expr, label, result) {
    if (!prop) {
        result.errors.push(label + ": 属性为空");
        return;
    }
    try {
        if (prop.canSetExpression === false) {
            result.errors.push(label + ": 该属性不支持表达式");
            return;
        }
    } catch (eCan) {}
    prop.expression = expr;
    try { prop.expressionEnabled = true; } catch (eEn) {}
    result.applied.push("已设表达式 -> " + label);
}

/* ---------- progress 锚点（依 axis 设左端/上端，并补偿位置保持视觉不动） ---------- */
function fuiSetProgressAnchor(layer, axis, result) {
    try {
        var xform = layer.property("ADBE Transform Group");
        var anchorProp = xform.property("ADBE Anchor Point");
        var posProp = xform.property("ADBE Position");
        var oldA = anchorProp.value;
        var rect = null;
        try { rect = layer.sourceRectAtTime(0, false); } catch (eRect) { rect = null; }

        var newA;
        if (rect) {
            if (axis === "y") {
                newA = [rect.left + rect.width / 2, rect.top];
            } else {
                newA = [rect.left, rect.top + rect.height / 2];
            }
        } else {
            newA = (axis === "y") ? [oldA[0], 0] : [0, oldA[1]];
        }
        anchorProp.setValue(newA);

        // 补偿位置：anchor 改变量按 1:1 反向加到 position，保持图层视觉位置
        var oldP = posProp.value;
        posProp.setValue([oldP[0] + (oldA[0] - newA[0]), oldP[1] + (oldA[1] - newA[1])]);
        result.applied.push("锚点 -> " + layer.name + " (" + axis + " 端)");
    } catch (eAnchor) {
        result.errors.push(layer.name + ": 设置锚点失败: " + String(eAnchor));
    }
}

/* ---------- 查找辅助 ---------- */
function fuiFindLayerByName(comp, name) {
    for (var i = 1; i <= comp.numLayers; i++) {
        if (comp.layer(i).name === name) { return comp.layer(i); }
    }
    return null;
}

function fuiFindFillColorProp(layer) {
    var root = null;
    try { root = layer.property("ADBE Root Vectors Group"); } catch (eRoot) { root = null; }
    if (!root) { return null; }
    return fuiFindPropByMatchName(root, "ADBE Vector Fill Color");
}

function fuiFindPropByMatchName(group, matchName) {
    var count = 0;
    try { count = group.numProperties; } catch (eCount) { return null; }
    if (!count) { return null; }
    for (var i = 1; i <= count; i++) {
        var p = null;
        try { p = group.property(i); } catch (eP) { p = null; }
        if (!p) { continue; }
        var mn = "";
        try { mn = p.matchName; } catch (eMn) { mn = ""; }
        if (mn === matchName) { return p; }
        var sub = 0;
        try { sub = p.numProperties; } catch (eSub) { sub = 0; }
        if (sub && sub > 0) {
            var found = fuiFindPropByMatchName(p, matchName);
            if (found) { return found; }
        }
    }
    return null;
}
