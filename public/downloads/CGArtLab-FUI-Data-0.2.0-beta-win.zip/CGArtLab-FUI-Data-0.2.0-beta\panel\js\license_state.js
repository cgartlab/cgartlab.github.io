/**
 * license_state.js —— 授权状态机（CEP 面板侧）
 * © 2026 CGArtLab · https://cgartlab.com · CGArtLab FUI Data
 * ------------------------------------------------------------------
 * 职责：
 *   1. 取机器码（由 JSX 侧读 BIOS UUID 后派生，见 license_gate.jsx）
 *   2. 读许可证 → RSA 验签 → 校验机器 / 到期 / 产品
 *   3. 没有许可证则走试用（起始时间存在 AE 偏好里，清 cookie 不重置）
 *   4. 把带 HMAC 的令牌推给 JSX（JSX 侧据此放行付费功能、解密全量规格）
 *
 * 依赖：license_core.js、license_rsa.js，以及 window.CSInterface（CEP 环境）。
 */
(function (root) {
    var C = root.FuiLicenseCore;
    var RSA = root.FuiLicenseRsa;
    if (!C) { throw new Error("license_core.js 未加载"); }

    var STORE_LICENSE = "cgartlab.fui.license.v1";
    var STORE_CACHE = "cgartlab.fui.license.state.v1";
    var TRIAL_DAYS = 14;
/* 试用期开放全部功能；到期后回落到免费档（4 类、无批量）。 */
var TRIAL_ENTS = ["all_types", "all_units", "batch", "cn_amount"];

    var api = {
        TRIAL_DAYS: TRIAL_DAYS,
        status: "unknown",      // active | trial | trial-expired | free | invalid | mismatch | no-host
        reason: "",
        plan: "none",
        ents: [],
        machineCode: "",
        fp: "",
        expires: null,
        trialDaysLeft: 0,
        specKey: "",
        licenseId: "",
        weakMachine: false     // true = 机器码来自主机名兜底（不稳），面板要提示
    };

    var listeners = [];
    var env = {
        evalScript: null,
        storage: null,
        now: function () { return Date.now(); }
    };

    /* ---------------- 环境桥 ---------------- */

    function evalJsx(code, cb) {
        if (!env.evalScript) { cb(null); return; }
        env.evalScript(code, function (res) {
            cb(res === undefined || res === null ? null : res);
        });
    }

    function storageGet(k) {
        try { return env.storage ? env.storage.getItem(k) : null; } catch (e) { return null; }
    }
    function storageSet(k, v) {
        try { if (env.storage) { env.storage.setItem(k, v); } } catch (e) { /* 忽略配额/隐私模式 */ }
    }
    function storageDel(k) {
        try { if (env.storage) { env.storage.removeItem(k); } } catch (e) { }
    }

    function notify() {
        for (var i = 0; i < listeners.length; i++) {
            try { listeners[i](snapshot()); } catch (e) { /* 单个监听器出错不影响他人 */ }
        }
    }

    function snapshot() {
        return {
            status: api.status, reason: api.reason, plan: api.plan,
            ents: api.ents.slice(0), machineCode: api.machineCode, fp: api.fp,
            weakMachine: !!api.weakMachine,
            expires: api.expires, trialDaysLeft: api.trialDaysLeft, fullTrial: !!api.fullTrial,
            licenseId: api.licenseId, trialDays: TRIAL_DAYS
        };
    }

    /* ---------------- 机器码 ---------------- */

    function fetchMachineCode(cb) {
        evalJsx("fuiLicenseFingerprint()", function (res) {
            var obj = null;
            try { obj = JSON.parse(res); } catch (e) { obj = null; }
            if (!obj || !obj.ok || !obj.code) {
                // 没有宿主（例如在浏览器里预览面板）：退化为占位机器码
                api.machineCode = "NO-HOST-0000-0000";
                api.fp = "NOHOST0000000000";
                cb(false);
                return;
            }
            api.machineCode = obj.code;
            api.fp = obj.fp;
            api.weakMachine = !!obj.weak;   // true = 没读到 BIOS UUID，用的是主机名兜底
            cb(true);
        });
    }

    /* ---------------- 试用 ---------------- */

    function readTrialStart(cb) {
        // 优先 AE 偏好（清浏览器存储无效），退回 localStorage
        evalJsx("fuiLicenseTrialStart()", function (res) {
            var iso = null;
            try { var o = JSON.parse(res); if (o && o.ok && o.start) { iso = o.start; } } catch (e) { }
            if (!iso) { iso = storageGet("cgartlab.fui.trial.start.v1"); }
            cb(iso);
        });
    }

    function writeTrialStart(iso) {
        storageSet("cgartlab.fui.trial.start.v1", iso);
        evalJsx("fuiLicenseSetTrialStart(" + JSON.stringify(iso) + ")", function () { });
    }

    function evaluateTrial(cb) {
        readTrialStart(function (iso) {
            var now = env.now();
            if (!iso) {
                iso = new Date(now).toISOString();
                writeTrialStart(iso);
            }
            var start = C.parseIsoMs(iso);
            if (isNaN(start)) { start = now; }
            // 防系统时钟回拨续期：记录见过的最大时间，用「更大者」当 now
            var seen = storageGet("cgartlab.fui.trial.lastseen.v1");
            var seenMs = C.parseIsoMs(seen);
            if (isNaN(seenMs) || now > seenMs) {
                seenMs = now;
                storageSet("cgartlab.fui.trial.lastseen.v1", new Date(now).toISOString());
            }
            var eff = Math.max(now, seenMs);
            var left = TRIAL_DAYS - Math.floor((eff - start) / 86400000);
            if (left > TRIAL_DAYS) { left = TRIAL_DAYS; }
            api.trialDaysLeft = left > 0 ? left : 0;
            if (left > 0) {
                api.status = "trial";
                api.reason = "";
                api.plan = "trial";
                api.ents = TRIAL_ENTS.slice(0);
                api.fullTrial = true;
            } else {
                api.status = "trial-expired";
                api.reason = "trial-over";
                api.plan = "none";
                api.ents = [];
                api.fullTrial = false;
            }
            cb();
        });
    }

    /* ---------------- 许可证 ---------------- */

    function licensePayloadValid(payload) {
        if (!payload || payload.product !== C.PRODUCT) { return { ok: false, reason: "wrong-product" }; }
        var seats = payload.seats || [];
        var norm = function (s) { return String(s || "").toUpperCase().replace(/[^0-9A-Z]/g, ""); };
        var own = norm(api.machineCode);
        var hit = false;
        for (var i = 0; i < seats.length; i++) {
            if (norm(seats[i]) === own) { hit = true; }
        }
        if (!hit) { return { ok: false, reason: "machine-mismatch" }; }
        if (payload.expires) {
            var exp = C.parseIsoMs(payload.expires);
            if (!isNaN(exp) && env.now() > exp) { return { ok: false, reason: "expired" }; }
        }
        return { ok: true };
    }

    function applyLicenseText(text) {
        var obj;
        try { obj = JSON.parse(text); } catch (e) { return { ok: false, reason: "bad-json" }; }
        var v = RSA ? RSA.verifyLicense(obj) : { ok: false, reason: "no-rsa-module" };
        if (!v.ok) { return v; }
        var p = v.payload;
        var chk = licensePayloadValid(p);
        if (!chk.ok) { return chk; }

        api.status = "active";
        api.reason = "";
        api.plan = p.plan || "personal";
        api.ents = (p.ents || []).slice(0);
        api.expires = p.expires || null;
        api.licenseId = p.license_id || "";
        api.specKey = p.sk ? C.bytesToHex(C.base64ToBytes(p.sk)) : "";
        return { ok: true, payload: p };
    }

    function loadStoredLicense(cb) {
        var text = storageGet(STORE_LICENSE);
        if (!text) { cb(false); return; }
        var r = applyLicenseText(text);
        if (!r.ok) {
            api.status = r.reason === "machine-mismatch" ? "mismatch" : "invalid";
            api.reason = r.reason;
            cb(false);
            return;
        }
        cb(true);
    }

    /* ---------------- 令牌推送 ---------------- */

    function pushTokenToHost() {
        var licensed = api.status === "active";
        // 令牌必须始终带过期时间：试用令牌给「当天结束 + 1 天」，每次打开面板重新签发；
        // 不带 exp 的令牌等于永不过期，是 fail-open。
        var expIso;
        if (licensed) {
            expIso = api.expires || null;
        } else {
            var dayMs = 86400000;
            expIso = new Date(env.now() + dayMs).toISOString();
        }
        var token = C.issueToken({
            plan: api.plan,
            ents: api.ents,
            exp: expIso,
            fp: api.fp,
            specKey: licensed ? api.specKey : "",
            iat: env.now()
        });
        var js = "fuiLicenseSetToken(" + JSON.stringify(JSON.stringify(token)) + ")";
        evalJsx(js, function () { });
        storageSet(STORE_CACHE, JSON.stringify({ at: env.now(), status: api.status, plan: api.plan }));
        return token;
    }

    /* ---------------- 对外 API ---------------- */

    function init(opts) {
        opts = opts || {};
        env.evalScript = opts.evalScript || (root.CSInterface ? new root.CSInterface().evalScript : null);
        env.storage = opts.storage ||
            (function () { try { return root.localStorage; } catch (e) { return null; } })();
        env.now = opts.now || env.now;
        if (opts.onChange) { listeners.push(opts.onChange); }

        var done = function () {
            pushTokenToHost();
            notify();
        };

        if (!env.evalScript) {
            api.status = "no-host";
            api.reason = "no-cep";
            api.machineCode = "NO-HOST-0000-0000";
            api.fp = "NOHOST0000000000";
            evaluateTrial(done);
            return;
        }

        fetchMachineCode(function (hasHost) {
            loadStoredLicense(function (ok) {
                if (ok) { done(); return; }
                evaluateTrial(done);
            });
        });
    }

    function activate(text) {
        if (!text) { return { ok: false, reason: "empty" }; }
        var r = applyLicenseText(text);
        if (!r.ok) { api.status = "invalid"; api.reason = r.reason; notify(); return r; }
        storageSet(STORE_LICENSE, text);
        pushTokenToHost();
        notify();
        return { ok: true, plan: api.plan };
    }

    function deactivate() {
        storageDel(STORE_LICENSE);
        storageDel(STORE_CACHE);
        api.status = "unknown";
        api.plan = "none";
        api.ents = [];
        api.specKey = "";
        api.licenseId = "";
        init({ evalScript: env.evalScript, storage: env.storage, now: env.now });
    }

    function can(ent) {
        // 试用期 ents 就是全量，和正式许可证走同一条判定；到期后 ents 为空 → 全部拒绝
        if (C.hasEnt(api.ents, ent) || C.hasEnt(api.ents, "all_types")) { return true; }
        return false;
    }

    root.FuiLicense = {
        init: init,
        activate: activate,
        deactivate: deactivate,
        can: can,
        state: snapshot,
        onChange: function (cb) { listeners.push(cb); },
        machineCode: function () { return api.machineCode; },
        TRIAL_DAYS: TRIAL_DAYS,
        _api: api
    };
})(typeof globalThis !== "undefined" ? globalThis :
    (typeof window !== "undefined" ? window : this));



