/**
 * fui_roles.jsx —— 角色表达式生成器（ES3，脚本侧）
 * ------------------------------------------------------------------
 * fuiBuildExpr(role, params) 返回该角色的"完整表达式字符串"。
 * 表达式运行时读取 MASTER 的 State / Transition / Ease 三个 Slider，
 * 部分可调标量参数读取元素层自身的 Expression Controls（由 fui_attach 注入）：
 *   - dataText : fui_decimals(Slider) / fui_padding(Slider) / fui_thousands(Checkbox)
 *   - progress : fui_min(Slider) / fui_max(Slider)
 *   - statusColor / statusText : 无标量参数，直接读 MASTER，无需元素控件
 * 状态解析 + 缓动补间内核严格对应 CONTRACT §3；格式化为 §5；缓动为 §4。
 */

/* ---------- 脚本侧字面量序列化 ---------- */
function fuiStrLit(v) {
    if (v === undefined || v === null) { v = ""; }
    var s = String(v);
    var out = "\"";
    for (var i = 0; i < s.length; i++) {
        var c = s.charAt(i);
        if (c === "\\") { out += "\\\\"; }
        else if (c === "\"") { out += "\\\""; }
        else if (c === "\n") { out += "\\n"; }
        else if (c === "\r") { out += "\\r"; }
        else if (c === "\t") { out += "\\t"; }
        else { out += c; }
    }
    return out + "\"";
}

function fuiNumLit(v) {
    var n = Number(v);
    if (v === undefined || v === null || v === "" || isNaN(n)) { return "0"; }
    return String(n);
}

function fuiNumArrLit(a) {
    var s = "[";
    if (!a) { a = []; }
    for (var i = 0; i < a.length; i++) {
        if (i > 0) { s += ","; }
        s += fuiNumLit(a[i]);
    }
    return s + "]";
}

function fuiColorArrLit(colors) {
    var s = "[";
    if (!colors) { colors = []; }
    for (var i = 0; i < colors.length; i++) {
        if (i > 0) { s += ","; }
        var c = colors[i];
        var cs = "[";
        for (var j = 0; j < c.length; j++) {
            if (j > 0) { cs += ","; }
            cs += fuiNumLit(c[j]);
        }
        cs += "]";
        s += cs;
    }
    return s + "]";
}

function fuiStrArrLit(arr) {
    var s = "[";
    if (!arr) { arr = []; }
    for (var i = 0; i < arr.length; i++) {
        if (i > 0) { s += ","; }
        s += fuiStrLit(arr[i]);
    }
    return s + "]";
}

/* ---------- 共享内核：状态解析 + 缓动补间（CONTRACT §3） ---------- */
/* 返回表达式代码行数组；生成的代码依赖：m / sp / time，并定义 val。 */
function fuiValueKernelLines(statesLit) {
    var L = [];
    L.push("var tp = m.effect(\"Transition\")(\"Slider\");");
    L.push("var ez = m.effect(\"Ease\")(\"Slider\");");
    L.push(fuiEaseJS());
    L.push("var states = " + statesLit + ";");
    L.push("var n = sp.numKeys;");
    L.push("var val;");
    L.push("if (n === 0) {");
    L.push("    val = (states.length > 0) ? states[0] : 0;");
    L.push("} else {");
    L.push("    var idx = 1;");
    L.push("    for (var i = 1; i <= n; i++) { if (sp.key(i).time <= time) { idx = i; } }");
    L.push("    var state = Math.round(sp.key(idx).value);");
    L.push("    var prevIdx = (idx - 1 < 1) ? 1 : (idx - 1);");
    L.push("    var prevState = Math.round(sp.key(prevIdx).value);");
    L.push("    var tStart = sp.key(idx).time;");
    L.push("    var dur = Math.max(0.0001, tp.value);");
    L.push("    var tt = Math.max(0, Math.min(1, (time - tStart) / dur));");
    L.push("    var e = easeFn(tt, Math.round(ez.value));");
    L.push("    var fromV, toV;");
    L.push("    if (idx <= 1) {");
    L.push("        fromV = (states[state] === undefined) ? states[0] : states[state];");
    L.push("        toV = fromV;");
    L.push("    } else {");
    L.push("        fromV = states[prevState];");
    L.push("        toV = states[state];");
    L.push("        if (fromV === undefined) { fromV = states[0]; }");
    L.push("        if (toV === undefined) { toV = states[states.length - 1]; }");
    L.push("    }");
    L.push("    val = fromV + (toV - fromV) * e;");
    L.push("}");
    return L;
}

function fuiPushAll(dst, src) {
    for (var i = 0; i < src.length; i++) { dst.push(src[i]); }
}

/* ---------- dataText（CONTRACT §5 格式化） ---------- */
function fuiExprDataText(p) {
    if (!p) { p = {}; }
    var statesLit = fuiNumArrLit(p.states);
    var L = [];
    L.push("(function () {");
    L.push("var m = thisComp.layer(\"MASTER\");");
    L.push("var sp = m.effect(\"State\")(\"Slider\");");
    fuiPushAll(L, fuiValueKernelLines(statesLit));
    L.push("var decimals = " + fuiNumLit(p.decimals) + ";");
    L.push("var padding = " + fuiNumLit(p.padding) + ";");
    L.push("var thousands = " + (p.thousands ? "true" : "false") + ";");
    L.push("try { decimals = Math.round(effect(\"fui_decimals\")(\"Slider\").value); } catch (eDec) {}");
    L.push("try { padding = Math.round(effect(\"fui_padding\")(\"Slider\").value); } catch (ePad) {}");
    L.push("try { thousands = (effect(\"fui_thousands\")(\"Checkbox\").value > 0); } catch (eThou) {}");
    L.push("var prefix = " + fuiStrLit(p.prefix) + ";");
    L.push("var suffix = " + fuiStrLit(p.suffix) + ";");
    L.push("var unit = " + fuiStrLit(p.unit) + ";");
    L.push("var neg = (val < 0);");
    L.push("var fixed = Math.abs(val).toFixed(decimals);");
    L.push("var dot = fixed.indexOf(\".\");");
    L.push("var intPart = (dot < 0) ? fixed : fixed.substring(0, dot);");
    L.push("var fracPart = (dot < 0) ? \"\" : fixed.substring(dot + 1);");
    L.push("while (intPart.length < padding) { intPart = \"0\" + intPart; }");
    L.push("if (thousands) {");
    L.push("    var grouped = \"\";");
    L.push("    var cnt = 0;");
    L.push("    for (var k = intPart.length - 1; k >= 0; k--) {");
    L.push("        grouped = intPart.charAt(k) + grouped;");
    L.push("        cnt++;");
    L.push("        if (cnt % 3 === 0 && k > 0) { grouped = \",\" + grouped; }");
    L.push("    }");
    L.push("    intPart = grouped;");
    L.push("}");
    L.push("var outStr = prefix + (neg ? \"-\" : \"\") + intPart + ((decimals > 0) ? (\".\" + fracPart) : \"\") + suffix + unit;");
    L.push("return outStr;");
    L.push("})()");
    return L.join("\n");
}

/* ---------- progress（驱动 transform.scale） ---------- */
function fuiExprProgress(p) {
    if (!p) { p = {}; }
    var statesLit = fuiNumArrLit(p.states);
    var axis = (p.axis === "y") ? "y" : "x";
    var L = [];
    L.push("(function () {");
    L.push("var m = thisComp.layer(\"MASTER\");");
    L.push("var sp = m.effect(\"State\")(\"Slider\");");
    fuiPushAll(L, fuiValueKernelLines(statesLit));
    L.push("var minV = " + fuiNumLit(p.min) + ";");
    L.push("var maxV = " + fuiNumLit((p.max === undefined) ? 100 : p.max) + ";");
    L.push("try { minV = effect(\"fui_min\")(\"Slider\").value; } catch (eMin) {}");
    L.push("try { maxV = effect(\"fui_max\")(\"Slider\").value; } catch (eMax) {}");
    L.push("var rng = maxV - minV;");
    L.push("var pct = (rng === 0) ? 0 : (100 * (val - minV) / rng);");
    if (axis === "y") {
        L.push("return [100, pct];");
    } else {
        L.push("return [pct, 100];");
    }
    L.push("})()");
    return L.join("\n");
}

/* ---------- statusColor（离散状态 → 颜色） ---------- */
function fuiExprStatusColor(p) {
    if (!p) { p = {}; }
    var colsLit = fuiColorArrLit(p.colors);
    var L = [];
    L.push("(function () {");
    L.push("var m = thisComp.layer(\"MASTER\");");
    L.push("var sp = m.effect(\"State\")(\"Slider\");");
    L.push("var cols = " + colsLit + ";");
    L.push("var s = 0;");
    L.push("var n = sp.numKeys;");
    L.push("if (n > 0) {");
    L.push("    for (var i = 1; i <= n; i++) { if (sp.key(i).time <= time) { s = Math.round(sp.key(i).value); } }");
    L.push("}");
    L.push("if (s < 0) { s = 0; }");
    L.push("if (s > cols.length - 1) { s = cols.length - 1; }");
    L.push("return cols[s];");
    L.push("})()");
    return L.join("\n");
}

/* ---------- statusText（离散状态 → 文案） ---------- */
function fuiExprStatusText(p) {
    if (!p) { p = {}; }
    var labsLit = fuiStrArrLit(p.labels);
    var L = [];
    L.push("(function () {");
    L.push("var m = thisComp.layer(\"MASTER\");");
    L.push("var sp = m.effect(\"State\")(\"Slider\");");
    L.push("var labs = " + labsLit + ";");
    L.push("var s = 0;");
    L.push("var n = sp.numKeys;");
    L.push("if (n > 0) {");
    L.push("    for (var i = 1; i <= n; i++) { if (sp.key(i).time <= time) { s = Math.round(sp.key(i).value); } }");
    L.push("}");
    L.push("if (s < 0) { s = 0; }");
    L.push("if (s > labs.length - 1) { s = labs.length - 1; }");
    L.push("return labs[s];");
    L.push("})()");
    return L.join("\n");
}

/* ---------- 统一入口 ---------- */
function fuiBuildExpr(role, params) {
    if (role === "dataText") { return fuiExprDataText(params); }
    if (role === "progress") { return fuiExprProgress(params); }
    if (role === "statusColor") { return fuiExprStatusColor(params); }
    if (role === "statusText") { return fuiExprStatusText(params); }
    throw new Error("fuiBuildExpr: 未知 role: " + role);
}
