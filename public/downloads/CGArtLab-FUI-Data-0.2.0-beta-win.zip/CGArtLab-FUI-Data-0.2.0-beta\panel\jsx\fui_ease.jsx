/**
 * fui_ease.jsx —— 缓动片段（ES3，脚本侧生成表达式字符串）
 * ------------------------------------------------------------------
 * fuiEaseJS() 返回一段"定义 easeFn(tt, em)"的表达式代码字符串。
 * 各角色表达式先 eval 到 tt / em，再调用 easeFn(tt, em) 得到缓动进度。
 * 公式严格对应 CONTRACT §4（输入 tt∈[0,1]，em 为 Ease 参数取整 0..4）。
 * 供 fui_roles.jsx 拼接，避免每种角色重复这一坨分支。
 */
function fuiEaseJS() {
    return "var easeFn = function (tt, em) {\n" +
        "    if (em <= 0) { return tt; }\n" +
        "    else if (em === 1) { return tt * tt * tt; }\n" +
        "    else if (em === 2) { return 1 - Math.pow(1 - tt, 3); }\n" +
        "    else if (em === 3) { return (tt < 0.5) ? (4 * tt * tt * tt) : (1 - Math.pow(-2 * tt + 2, 3) / 2); }\n" +
        "    else { return tt * tt * (3 - 2 * tt); }\n" +
        "};";
}
