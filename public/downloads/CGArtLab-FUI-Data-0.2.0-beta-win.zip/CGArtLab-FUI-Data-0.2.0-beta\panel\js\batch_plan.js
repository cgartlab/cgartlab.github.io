/**
 * batch_plan.js —— 批量模式的「参数能不能统一」判定（纯逻辑，无 DOM / 无 AE）
 *
 * 为什么单独抽出来：批量最容易出错的地方不是写入，而是「判断」——
 * 选了 3 个不同数据类型的图层时，小数位可以统一，货币汇率却不能；单位在类型不同时根本不可比。
 * 这类规则写在 UI 事件里就没法测，所以做成纯函数，由 Node 测试覆盖。
 *
 * 对外只用两个函数：
 *   FUI_BATCH.plan(layers)                     -> 这一批的可统一/不可统一清单
 *   FUI_BATCH.merge(layerState, uiState, dirty, plan, types) -> 某一层最终要写入的参数
 *
 * layers: [{ typeId, unitId, params: {...} }]（来自每层的检测结果，见 panel.js deriveLayerState）
 *   params 里放的是状态键：decimals / padding / prefixSpace / unitSpace / … / anchor
 * types:  注册表 { typeId: { format, units, baseUnit, ... } }
 */
(function (root, factory) {
    var api = factory();
    if (typeof module !== 'undefined' && module.exports) { module.exports = api; }
    if (root) { root.FUI_BATCH = api; }
})(typeof window !== 'undefined' ? window : null, function () {
    'use strict';

    /* 参数 <-> 能力：每个参数在什么类型的图层上有意义 */
    var KEYS = [
        'decimals', 'padding', 'thousands', 'prefixSpace', 'unitSpace', 'suffixSpace',
        'prefix', 'suffix', 'affixFont', 'affixFontSize',
        'align', 'tracking', 'numColor',
        'forceSign', 'rangeMin', 'rangeMax', 'allowNegative', 'clamp', 'decimalChar',
        'timerMs', 'timerMode', 'rate', 'rmbUppercase', 'hemisphere', 'anchor'
    ];

    function isText(t) { return (t && t.format === 'text') || t.id === 'plainText'; }
    function isTimecode(t) { return (t && (t.format === 'timecode')) || t.id === 'timer'; }
    function isCurrency(t) { return (t && t.format === 'currency') || t.id === 'currency'; }
    function isDms(t) { return (t && t.format === 'dms') || t.id === 'coordinate'; }
    function hasUnits(t) { return !!(t && t.units && t.units.length); }

    /**
     * 某个参数能不能作用在这种类型上。
     * 返回 false 表示「这种类型根本没有这个概念」，批量时不能强行写入。
     */
    function supports(key, type) {
        var t = type || {};
        if (key === 'typeId' || key === 'anchor') { return true; }
        if (key === 'unitId') { return hasUnits(t) && !isText(t); }
        if (isText(t)) { return false; }            // 纯文本只读，除锚点外都不写
        switch (key) {
            case 'rate':
            case 'rmbUppercase':
                return isCurrency(t);
            case 'timerMs':
            case 'timerMode':
                return isTimecode(t);
            case 'hemisphere':
                return isDms(t);
            case 'unitSpace':
                return hasUnits(t) && !isTimecode(t) && !isDms(t);
            case 'decimals':
            case 'thousands':
            case 'decimalChar':
                return !isTimecode(t) || key === 'decimals';
            case 'rangeMin':
            case 'rangeMax':
            case 'allowNegative':
            case 'clamp':
                return !isTimecode(t);
            default:
                return true;
        }
    }

    function normType(typeId, types) {
        var t = (types && types[typeId]) ? types[typeId] : null;
        if (!t) { t = { id: typeId, format: 'number', units: [] }; }
        if (!t.id) { t = { id: typeId, format: t.format, units: t.units, baseUnit: t.baseUnit }; }
        return t;
    }

    function same(a, b) { return String(a) === String(b); }

    /**
     * @param layers 每个已选文字层：{ typeId, unitId, params }
     * @param types  注册表
     * @return {
     *   count, sameType, typeId, sameUnit, unitId,
     *   keys: { key: { status:'all'|'partial'|'none', mixed, value, blockedReason } },
     *   overrides: {},          // 可统一但各层不同的参数（UI 显示「多值」，用户改了才统一）
     *   blockedKeys: [],        // 不能统一（禁用）
     *   note: ''                // 给用户看的一句话说明
     * }
     */
    function plan(layers, types) {
        layers = layers || [];
        var out = {
            count: layers.length, sameType: true, typeId: layers.length ? layers[0].typeId : '',
            sameUnit: true, unitId: layers.length ? layers[0].unitId : '',
            keys: {}, overrides: {}, blockedKeys: [], note: ''
        };
        if (!layers.length) { out.note = '没有可处理的文字图层'; return out; }

        var i, k;
        for (i = 1; i < layers.length; i++) {
            if (!same(layers[i].typeId, layers[0].typeId)) { out.sameType = false; }
            if (!same(layers[i].unitId, layers[0].unitId)) { out.sameUnit = false; }
        }
        out.sameUnit = out.sameUnit && out.sameType;
        out.typeId = out.sameType ? layers[0].typeId : '';
        out.unitId = out.sameUnit ? layers[0].unitId : '';

        var typeObjs = [];
        for (i = 0; i < layers.length; i++) { typeObjs.push(normType(layers[i].typeId, types)); }

        // 单位单独判定：它跨类型不可比
        var anyUnits = false, allUnits = true;
        for (i = 0; i < layers.length; i++) {
            if (hasUnits(typeObjs[i])) { anyUnits = true; } else { allUnits = false; }
        }
        out.keys.unitId = { status: 'all', okCount: layers.length, mixed: false, value: layers[0].unitId, blockedReason: '' };
        if (!out.sameType) {
            out.keys.unitId.status = 'partial';
            out.keys.unitId.blockedReason = '类型不同，单位不可比；先统一类型';
            out.blockedKeys.push('unitId');
        } else if (!anyUnits) {
            out.keys.unitId.status = 'none';
            out.keys.unitId.blockedReason = '所选类型没有单位';
            out.blockedKeys.push('unitId');
        } else if (!allUnits) {
            out.keys.unitId.status = 'partial';
            out.keys.unitId.blockedReason = '只有部分图层有单位';
            out.blockedKeys.push('unitId');
        } else if (!out.sameUnit) {
            out.keys.unitId.mixed = true;
            out.overrides.unitId = true;
        }

        for (k = 0; k < KEYS.length; k++) {
            var key = KEYS[k], okCount = 0;
            for (i = 0; i < layers.length; i++) {
                if (supports(key, typeObjs[i])) { okCount++; }
            }
            var status = 'none';
            if (okCount === layers.length) { status = 'all'; }
            else if (okCount > 0) { status = 'partial'; }
            var entry = { status: status, okCount: okCount, mixed: false, value: undefined, blockedReason: '' };
            if (status === 'all') {
                var firstVal = layers[0].params ? layers[0].params[key] : undefined;
                var isMixed = false;
                for (i = 1; i < layers.length; i++) {
                    var v = layers[i].params ? layers[i].params[key] : undefined;
                    if (!same(v, firstVal)) { isMixed = true; break; }
                }
                entry.value = firstVal;
                entry.mixed = isMixed;
                if (isMixed) { out.overrides[key] = true; }
            } else if (status === 'partial') {
                entry.blockedReason = '有 ' + (layers.length - okCount) + ' 个图层不支持该参数（类型不同）';
                out.blockedKeys.push(key);
            } else {
                entry.blockedReason = '所选类型都没有该参数';
                out.blockedKeys.push(key);
            }
            out.keys[key] = entry;

        }

        if (!out.sameType) {
            out.note = '所选 ' + layers.length + ' 层类型不同：不改类型就各写各的；改类型会把它们统一成同一类型';
        } else if (out.overrides && Object.keys(out.overrides).length) {
            out.note = '同类型 ' + layers.length + ' 层：标「— 多值」的参数各层不同，改它才会统一';
        } else {
            out.note = '同类型 ' + layers.length + ' 层：参数一致，可直接应用';
        }
        return out;
    }

    /**
     * 计算「某一层最终要写入的 state」。
     * 规则：用户改过的字段（dirty）且该层类型支持 → 用界面的值；
     *       否则用这一层自己的检测值；类型被用户改了 → 全层换成新类型。
     */
    function merge(layerState, uiState, dirty, planResult, types) {
        dirty = dirty || {};
        var typeId = dirty.typeId ? uiState.typeId : layerState.typeId;
        if (!typeId || typeId === '__mixed__') { typeId = layerState.typeId; }
        var t = normType(typeId, types);
        var typeChanged = !same(typeId, layerState.typeId);
        var res = { typeId: typeId }, dropped = [];

        // 单位：类型换了就回到该类型基准单位；没换且用户改过就用界面的
        var unitId = layerState.unitId;
        if (t.baseUnit) { unitId = t.baseUnit; }
        if (!typeChanged && dirty.unitId && uiState.unitId && uiState.unitId !== '__mixed__') {
            unitId = uiState.unitId;
        }
        if (!typeChanged && !dirty.unitId && layerState.unitId) { unitId = layerState.unitId; }
        if (hasUnits(t)) {
            var valid = false, units = t.units || [];
            for (var i = 0; i < units.length; i++) { if (units[i].id === unitId) { valid = true; break; } }
            if (!valid) { unitId = t.baseUnit || (units[0] ? units[0].id : ''); }
        } else {
            unitId = '';
        }
        res.unitId = unitId;

        for (var ki = 0; ki < KEYS.length; ki++) {
            var key = KEYS[ki];
            if (!supports(key, t)) { dropped.push(key); continue; }
            if (dirty[key] && uiState[key] !== undefined) { res[key] = uiState[key]; }
            else if (layerState.params && layerState.params[key] !== undefined) { res[key] = layerState.params[key]; }
        }
        res.__dropped = dropped;
        return res;
    }

    return {
        KEYS: KEYS,
        supports: supports,
        plan: plan,
        merge: merge
    };
});
