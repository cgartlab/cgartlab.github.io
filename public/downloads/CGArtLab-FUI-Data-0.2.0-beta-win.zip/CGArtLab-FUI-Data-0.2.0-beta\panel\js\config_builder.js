/**
 * config_builder.js —— 纯逻辑层（浏览器 / Node 共用，UMD 写法）
 * ------------------------------------------------------------------
 * 两套用途：
 *  A) 新「DATA & UNIT」子系统（DATATYPE.md）：量纲注册表默认值 + state→applyOptions
 *     FUI.DATATYPE_DEFAULTS / getType / typeList / typeDefaults
 *     FUI.defaultDataState / buildApplyOptions / validateDataState
 *  B) 旧「FUI 行为控制器」legacy（CONTRACT §10.2，面板已不再使用，保留以免破坏旧 e2e）
 *     FUI.roleParamSpec / defaultState / buildConfig / validateState
 * 不依赖 DOM，可在 node 下 require 单测。
 */
(function (global) {
    "use strict";

    /* =====================================================================
     * 新：DATA & UNIT 量纲注册表默认值（DATATYPE.md §6；真源为 src/datatype_spec.json，
     *     面板优先从宿主读取该文件，读不到时用这里的默认值兜底）
     * ===================================================================== */
    var DATATYPE_DEFAULTS = {
        plainText: {
            label: "纯文本", allowNegative: false, forceSign: false, decimals: 0, thousands: false, baseUnit: "",
            units: [], range: null, thresholds: [], prefix: "", suffix: "", format: "text", behavior: "manual", timerMode: "format"
        },
        temperature: {
            label: "温度", allowNegative: true, forceSign: false, decimals: 1, thousands: false, baseUnit: "°C",
            units: [
                { id: "°C", label: "°C", factor: 1, offset: 0 },
                { id: "°F", label: "°F", factor: 1.8, offset: 32 },
                { id: "K", label: "K", factor: 1, offset: 273.15 }
            ],
            range: { min: null, max: null, clamp: false }, thresholds: [],
            prefix: "", suffix: "", format: "number", behavior: "smooth", timerMode: "format"
        },
        currency: {
            label: "货币", allowNegative: true, forceSign: false, decimals: 2, thousands: true, baseUnit: "CNY",
            units: [
                { id: "CNY", label: "CNY ¥", factor: 1, offset: 0 },
                { id: "USD", label: "USD $", factor: 0.1389, offset: 0 },
                { id: "EUR", label: "EUR €", factor: 0.1279, offset: 0 },
                { id: "GBP", label: "GBP £", factor: 0.1098, offset: 0 },
                { id: "HKD", label: "HKD HK$", factor: 1.08, offset: 0 },
                { id: "JPY", label: "JPY JP¥", factor: 20.8333333333, offset: 0 }
            ],
            range: { min: null, max: null, clamp: false }, thresholds: [],
            prefix: "", suffix: "", format: "number", behavior: "smooth", timerMode: "format"
        },
        length: {
            label: "长度", allowNegative: true, forceSign: false, decimals: 2, thousands: true, baseUnit: "m",
            units: [
                { id: "m", label: "m", factor: 1, offset: 0 },
                { id: "mm", label: "mm", factor: 1000, offset: 0 },
                { id: "cm", label: "cm", factor: 100, offset: 0 },
                { id: "km", label: "km", factor: 0.001, offset: 0 },
                { id: "µm", label: "µm", factor: 1000000, offset: 0 },
                { id: "in", label: "in", factor: 39.37007874015748, offset: 0 },
                { id: "ft", label: "ft", factor: 3.280839895013123, offset: 0 }
            ],
            range: { min: 0, max: null, clamp: false }, thresholds: [],
            prefix: "", suffix: "", format: "number", behavior: "smooth", timerMode: "format"
        },
        heartRate: {
            label: "心率", allowNegative: true, forceSign: false, decimals: 0, thousands: false, baseUnit: "bpm",
            units: [{ id: "bpm", label: "bpm", factor: 1, offset: 0 }],
            range: { min: 0, max: 300, clamp: true },
            thresholds: [{ level: "warn", op: "lt", value: 60 }, { level: "warn", op: "gt", value: 100 }],
            prefix: "", suffix: "", format: "number", behavior: "wave", timerMode: "format"
        },
        oxygen: {
            label: "含氧量", allowNegative: true, forceSign: false, decimals: 0, thousands: false, baseUnit: "%",
            units: [{ id: "%", label: "%", factor: 1, offset: 0 }],
            range: { min: 0, max: 100, clamp: true }, thresholds: [{ level: "warn", op: "lt", value: 90 }],
            prefix: "", suffix: "", format: "number", behavior: "smooth", timerMode: "format"
        },
        generic: {
            label: "通用数字", allowNegative: true, forceSign: false, decimals: 1, thousands: false, baseUnit: "",
            units: [], range: { min: null, max: null, clamp: false }, thresholds: [],
            prefix: "", suffix: "", format: "number", behavior: "smooth", timerMode: "format"
        },
        timer: {
            label: "计时/秒表", allowNegative: false, forceSign: false, decimals: 0, thousands: false, baseUnit: "timecode",
            units: [], range: { min: null, max: null, clamp: false }, thresholds: [],
            prefix: "", suffix: "", format: "timecode", behavior: "linear", timerMode: "format"
        },
        pressure: {
            label: "大气压", allowNegative: true, forceSign: false, decimals: 1, thousands: true, baseUnit: "Pa",
            units: [
                { id: "Pa", label: "Pa", factor: 1, offset: 0 },
                { id: "kPa", label: "kPa", factor: 0.001, offset: 0 },
                { id: "bar", label: "bar", factor: 0.00001, offset: 0 },
                { id: "atm", label: "atm", factor: 0.0000098692, offset: 0 },
                { id: "mmHg", label: "mmHg", factor: 0.007500615758456563, offset: 0 },
                { id: "psi", label: "psi", factor: 0.00014504, offset: 0 }
            ],
            range: { min: null, max: null, clamp: false }, thresholds: [],
            prefix: "", suffix: "", format: "number", behavior: "step", timerMode: "format"
        },
        frequency: {
            label: "频率", allowNegative: true, forceSign: false, decimals: 2, thousands: true, baseUnit: "Hz",
            units: [
                { id: "Hz", label: "Hz", factor: 1, offset: 0 },
                { id: "kHz", label: "kHz", factor: 0.001, offset: 0 },
                { id: "MHz", label: "MHz", factor: 0.000001, offset: 0 },
                { id: "GHz", label: "GHz", factor: 0.000000001, offset: 0 }
            ],
            range: { min: null, max: null, clamp: false }, thresholds: [],
            prefix: "", suffix: "", format: "number", behavior: "wave", timerMode: "format"
        },
        voltage: {
            label: "电压", allowNegative: true, forceSign: false, decimals: 2, thousands: true, baseUnit: "V",
            units: [
                { id: "V", label: "V", factor: 1, offset: 0 },
                { id: "mV", label: "mV", factor: 1000, offset: 0 },
                { id: "kV", label: "kV", factor: 0.001, offset: 0 }
            ],
            range: { min: null, max: null, clamp: false }, thresholds: [],
            prefix: "", suffix: "", format: "number", behavior: "smooth", timerMode: "format"
        },
        weight: {
            label: "重量", allowNegative: true, forceSign: false, decimals: 2, thousands: true, baseUnit: "kg",
            units: [
                { id: "kg", label: "kg", factor: 1, offset: 0 },
                { id: "g", label: "g", factor: 1000, offset: 0 },
                { id: "mg", label: "mg", factor: 1000000, offset: 0 },
                { id: "t", label: "t", factor: 0.001, offset: 0 },
                { id: "lb", label: "lb", factor: 2.2046226218487757, offset: 0 },
                { id: "oz", label: "oz", factor: 35.27396194958041, offset: 0 },
                { id: "斤", label: "斤", factor: 2, offset: 0 },
                { id: "两", label: "两", factor: 20, offset: 0 }
            ],
            range: { min: null, max: null, clamp: false }, thresholds: [],
            prefix: "", suffix: "", format: "number", behavior: "smooth", timerMode: "format"
        },
        speed: {
            label: "速度", allowNegative: true, forceSign: false, decimals: 2, thousands: true, baseUnit: "m/s",
            units: [
                { id: "m/s", label: "m/s", factor: 1, offset: 0 },
                { id: "km/h", label: "km/h", factor: 3.6, offset: 0 },
                { id: "mph", label: "mph", factor: 2.2369362920544025, offset: 0 },
                { id: "kn", label: "kn", factor: 1.9438444924406046, offset: 0 }
            ],
            range: { min: null, max: null, clamp: false }, thresholds: [],
            prefix: "", suffix: "", format: "number", behavior: "smooth", timerMode: "format"
        },
        area: {
            label: "面积", allowNegative: true, forceSign: false, decimals: 2, thousands: true, baseUnit: "m²",
            units: [
                { id: "m²", label: "m²", factor: 1, offset: 0 },
                { id: "km²", label: "km²", factor: 0.000001, offset: 0 },
                { id: "cm²", label: "cm²", factor: 10000, offset: 0 },
                { id: "ha", label: "ha", factor: 0.0001, offset: 0 },
                { id: "ac", label: "ac", factor: 0.00024710538146717, offset: 0 },
                { id: "亩", label: "亩", factor: 0.0015, offset: 0 }
            ],
            range: { min: null, max: null, clamp: false }, thresholds: [],
            prefix: "", suffix: "", format: "number", behavior: "smooth", timerMode: "format"
        },
        volume: {
            label: "容积", allowNegative: true, forceSign: false, decimals: 2, thousands: true, baseUnit: "L",
            units: [
                { id: "L", label: "L", factor: 1, offset: 0 },
                { id: "mL", label: "mL", factor: 1000, offset: 0 },
                { id: "m³", label: "m³", factor: 0.001, offset: 0 },
                { id: "gal", label: "gal", factor: 0.26417205235814845, offset: 0 }
            ],
            range: { min: null, max: null, clamp: false }, thresholds: [],
            prefix: "", suffix: "", format: "number", behavior: "smooth", timerMode: "format"
        },
        coordinate: {
            label: "经纬度", allowNegative: true, forceSign: false, decimals: 6, thousands: false, baseUnit: "deg",
            units: [
                { id: "dms", label: "度分秒", factor: 1, offset: 0 },
                { id: "deg", label: "十进制度", factor: 1, offset: 0 }
            ],
            range: { min: null, max: null, clamp: false }, thresholds: [],
            prefix: "", suffix: "", format: "dms", behavior: "smooth", timerMode: "format"
        },
        angle: {
            label: "角度", allowNegative: true, forceSign: false, decimals: 1, thousands: false, baseUnit: "deg",
            units: [
                { id: "deg", label: "deg", factor: 1, offset: 0 },
                { id: "rad", label: "rad", factor: 0.0174533, offset: 0 }
            ],
            range: { min: null, max: null, clamp: false }, thresholds: [],
            prefix: "", suffix: "", format: "number", behavior: "smooth", timerMode: "format"
        },
        percent: {
            label: "百分比", allowNegative: true, forceSign: false, decimals: 0, thousands: false, baseUnit: "pct",
            units: [
                { id: "pct", label: "%", factor: 1, offset: 0 },
                { id: "permil", label: "‰", factor: 10, offset: 0 }
            ],
            range: { min: 0, max: 100, clamp: true }, thresholds: [],
            prefix: "", suffix: "", format: "number", behavior: "smooth", timerMode: "format"
        }
    };

    (function () {
        try {
            var FC = (typeof window !== "undefined") ? window.FUIFormatCore : null;
            if (FC && FC.REGISTRY) {
                for (var _k in FC.REGISTRY) {
                    if (Object.prototype.hasOwnProperty.call(FC.REGISTRY, _k)) {
                        if (!Object.prototype.hasOwnProperty.call(DATATYPE_DEFAULTS, _k)) {
                            DATATYPE_DEFAULTS[_k] = FC.REGISTRY[_k];
                        } else {
                            // 覆盖已有类型的单位/标签（否则新增单位/下拉文案不会进入面板）
                            try {
                                if (FC.REGISTRY[_k].units) { DATATYPE_DEFAULTS[_k].units = FC.REGISTRY[_k].units; }
                                if (FC.REGISTRY[_k].label) { DATATYPE_DEFAULTS[_k].label = FC.REGISTRY[_k].label; }
                            } catch (eOv) { }
                        }
                    }
                }
            }
        } catch (eMerge) { }
    })();

    var BEHAVIORS = ["manual", "smooth", "linear", "hold"];
    var FORMATS = ["number", "rmbUppercase", "timecode", "dms"];

    function dtOwn(o, k) { return Object.prototype.hasOwnProperty.call(o, k); }

    function dtGetType(typeId) {
        return dtOwn(DATATYPE_DEFAULTS, typeId) ? DATATYPE_DEFAULTS[typeId] : DATATYPE_DEFAULTS.generic;
    }

    function dtTypeList() {
        var arr = [];
        for (var k in DATATYPE_DEFAULTS) {
            if (dtOwn(DATATYPE_DEFAULTS, k)) { arr.push({ id: k, label: DATATYPE_DEFAULTS[k].label }); }
        }
        return arr;
    }

    function numOrNull(v) {
        if (v === undefined || v === null || v === "") { return null; }
        var n = Number(v);
        return isNaN(n) ? null : n;
    }

    /** 返回某量纲的字段默认值（供面板切换量纲时重置控件）。 */
    function dtTypeDefaults(typeId) {
        var t = dtGetType(typeId);
        var unitId = t.baseUnit || (t.units && t.units.length ? t.units[0].id : "");
        return {
            typeId: typeId,
            unitId: unitId,
            decimals: t.decimals,
            thousands: t.thousands,
            forceSign: t.forceSign,
            allowNegative: t.allowNegative,
            format: t.format,
            behavior: t.behavior,
            timerMode: t.timerMode || "format",
            rangeMin: (t.range && t.range.min !== null && t.range.min !== undefined) ? t.range.min : "",
            rangeMax: (t.range && t.range.max !== null && t.range.max !== undefined) ? t.range.max : "",
            clamp: !!(t.range && t.range.clamp),
            thresholds: clone(t.thresholds || []),
            prefix: t.prefix || "",
            suffix: t.suffix || ""
        };
    }

    /** 面板数据-单位流程的初始 state。 */
    function defaultDataState() {
        var base = dtTypeDefaults("generic");
        return {
            selectedLayer: "",
            batch: false,
            batchLayers: [],
            typeId: "generic",
            unitId: base.unitId,
            decimals: base.decimals,
            thousands: base.thousands,
            forceSign: base.forceSign,
            allowNegative: base.allowNegative,
            rangeMin: base.rangeMin,
            rangeMax: base.rangeMax,
            clamp: base.clamp,
            thresholds: base.thresholds,
            prefix: base.prefix,
            suffix: base.suffix,
            padding: 0,
            prefixSpace: 0,
            unitSpace: 0,
            suffixSpace: 0,
            behavior: "manual",
            bezier: [0.42, 0.0, 0.58, 1.0],
            numColor: "#ffffff",
            useColor: true,
            anchor: "",
            tracking: "",
            decimalChar: ".",
            align: "",
            fontMode: "",
            fontName: "",
            fontSize: "",
            affixFont: "",
            affixFontSize: "",
            hemisphere: "lat",
            timerMs: false,
            format: base.format,
            rate: "",
            rmbUppercase: false,
            timerMode: base.timerMode
        };
    }

    /** state → fuiApplyData 的 options 对象（DATATYPE.md §4/§7）。
     *  specOverride 可选：传入真实注册表条目（如 format_core 的 getType(typeId)）时优先用其 baseUnit/format，
     *  以保证单位 id（如 "C"/"F"）与核心一致。 */
    function buildApplyOptions(state, specOverride) {
        state = state || defaultDataState();
        var t = specOverride || dtGetType(state.typeId);
        var baseUnit = t.baseUnit || "";
        var unitId = state.unitId || baseUnit;

        var fmt = state.format || t.format || "number";
        if (state.typeId === "currency" && state.rmbUppercase) { fmt = "rmbUppercase"; }

        var thresholds = [];
        var srcTh = state.thresholds || [];
        for (var i = 0; i < srcTh.length; i++) {
            var th = srcTh[i] || {};
            var v = numOrNull(th.value);
            if (v === null) { continue; }
            thresholds.push({ level: (th.level === "crit" ? "crit" : "warn"), op: (th.op === "gt" ? "gt" : "lt"), value: v });
        }

        var rMin = numOrNull(state.rangeMin);
        var rMax = numOrNull(state.rangeMax);
        var rClamp = !!state.clamp;

        return {
            // 与 datatype_apply.jsx 的 fuiMergeSpec 键名对齐：
            unit: unitId,                 // 目标显示单位 id（engine 合并进 spec.unit）
            baseUnit: baseUnit,
            unitId: unitId,               // 兼容/展示用
            format: (state.rmbUppercase ? "rmbUppercase" : fmt),
            decimals: Math.round(toNumber(state.decimals, t.decimals)),
            padding: Math.max(0, Math.round(toNumber(state.padding, 0))),
            thousands: !!state.thousands,
            forceSign: !!state.forceSign,
            allowNegative: (state.allowNegative !== false),
            min: rMin,                    // engine 合并进 spec.range.min
            max: rMax,                    // engine 合并进 spec.range.max
            clamp: rClamp,                // engine 合并进 spec.range.clamp
            range: { min: rMin, max: rMax, clamp: rClamp }, // 兼容/展示用
            thresholds: thresholds,
            prefix: toStr(state.prefix, ""),
            suffix: toStr(state.suffix, ""),
            prefixSpace: numOrNull(state.prefixSpace),
            unitSpace: numOrNull(state.unitSpace),
            suffixSpace: numOrNull(state.suffixSpace),
            color: hexToRgb01(state.numColor),
            anchor: state.anchor || "",
            tracking: numOrNull(state.tracking),
            decimalChar: state.decimalChar || ".",
            align: state.align || "",
            font: "",
            fontSize: "",
            affixFont: toStr(state.affixFont, ""),
            affixFontSize: numOrNull(state.affixFontSize),
            hemisphere: (state.hemisphere || "lat"),
            timerMs: !!state.timerMs,
            behavior: (BEHAVIORS.indexOf(state.behavior) >= 0 ? state.behavior : "manual"),
            bezier: normalizeBezier(state.bezier),
            rate: numOrNull(state.rate),
            timerMode: "format",
            rmbUppercase: !!state.rmbUppercase
        };
    }

    /** 校验数据-单位 state → {ok, errors}。 */
    function validateDataState(state) {
        var errors = [];
        if (!state || typeof state !== "object") {
            return { ok: false, errors: ["state 为空或不是对象"] };
        }
        if (!dtOwn(DATATYPE_DEFAULTS, state.typeId)) {
            errors.push("量纲无效: " + state.typeId);
        }
        if (state.batch) {
            if (!state.batchLayers || !state.batchLayers.length) {
                errors.push("批量模式请至少勾选一个图层");
            }
        } else if (!state.selectedLayer) {
            errors.push("请先选择并检测一个目标图层");
        }
        return { ok: errors.length === 0, errors: errors };
    }

    /* =====================================================================
     * 通用工具（两套逻辑共用）
     * ===================================================================== */
    function clone(v) { return JSON.parse(JSON.stringify(v)); }
    function hexToRgb01(hex) {
        if (!hex) { return null; }
        var h = String(hex).replace("#", "");
        if (h.length === 3) { h = h[0] + h[0] + h[1] + h[1] + h[2] + h[2]; }
        if (h.length !== 6) { return null; }
        var r = parseInt(h.substr(0, 2), 16) / 255, g = parseInt(h.substr(2, 2), 16) / 255, b = parseInt(h.substr(4, 2), 16) / 255;
        if (isNaN(r) || isNaN(g) || isNaN(b)) { return null; }
        return [r, g, b];
    }
    function normalizeBezier(b) {
        if (!b || b.length !== 4) { return [0.42, 0.0, 0.58, 1.0]; }
        var a = [];
        for (var i = 0; i < 4; i++) { var n = Number(b[i]); a.push(isNaN(n) ? 0 : n); }
        a[0] = Math.max(0, Math.min(1, a[0]));
        a[2] = Math.max(0, Math.min(1, a[2]));
        return a;
    }
    function toNumber(v, d) {
        var n = Number(v);
        if (v === undefined || v === null || v === "" || isNaN(n)) { return d; }
        return n;
    }
    function toStr(v, d) {
        if (v === undefined || v === null) { return d; }
        return String(v);
    }

    /* =====================================================================
     * 旧 legacy：FUI 行为控制器（CONTRACT §10.2）—— 保留兼容
     * ===================================================================== */
    var ROLES = ["dataText", "progress", "statusColor", "statusText"];
    var ROLE_LABELS = { dataText: "数据文本", progress: "进度几何", statusColor: "状态颜色", statusText: "状态文案" };
    var ROLE_SPECS = {
        dataText: [
            { key: "states", label: "状态值", type: "numberArray", default: [22, 85, 30] },
            { key: "decimals", label: "小数位", type: "number", default: 1, min: 0, max: 10, step: 1 },
            { key: "padding", label: "整数补零", type: "number", default: 0, min: 0, max: 12, step: 1 },
            { key: "prefix", label: "前缀", type: "text", default: "" },
            { key: "suffix", label: "后缀", type: "text", default: "" },
            { key: "unit", label: "单位", type: "text", default: " °C" },
            { key: "thousands", label: "千分位", type: "bool", default: false }
        ],
        progress: [
            { key: "states", label: "状态值", type: "numberArray", default: [22, 85, 30] },
            { key: "min", label: "最小值", type: "number", default: 0 },
            { key: "max", label: "最大值", type: "number", default: 100 },
            { key: "axis", label: "方向", type: "text", default: "x", options: ["x", "y"] }
        ],
        statusColor: [
            { key: "colors", label: "状态颜色", type: "colorArray", default: [[0.20, 0.85, 0.40, 1], [1.00, 0.70, 0.10, 1], [1.00, 0.20, 0.20, 1]] }
        ],
        statusText: [
            { key: "labels", label: "状态文案", type: "textArray", default: ["NOMINAL", "WARNING", "CRITICAL"] }
        ]
    };
    var DEFAULT_COLORS = [[0.20, 0.85, 0.40, 1], [1.00, 0.70, 0.10, 1], [1.00, 0.20, 0.20, 1]];
    var DEFAULT_LABELS = ["NOMINAL", "WARNING", "CRITICAL"];
    var DEFAULT_STATES = [22, 85, 30];

    function clampStateCount(v) { var n = Math.round(toNumber(v, 3)); if (n < 2) { n = 2; } if (n > 5) { n = 5; } return n; }
    function normalizeRole(role) { return ROLES.indexOf(role) >= 0 ? role : "dataText"; }
    function normalizeColor(c) { c = c || []; return [toNumber(c[0], 0), toNumber(c[1], 0), toNumber(c[2], 0), (c[3] === undefined ? 1 : toNumber(c[3], 1))]; }
    function resizeNumbers(arr, n, fallback) {
        arr = arr || []; fallback = (fallback && fallback.length) ? fallback : [0];
        var out = [];
        for (var i = 0; i < n; i++) { var v = arr[i]; if (v === undefined || v === null || v === "" || isNaN(Number(v))) { v = fallback[Math.min(i, fallback.length - 1)]; } out.push(Number(v)); }
        return out;
    }
    function resizeColors(arr, n, fallback) {
        arr = arr || []; fallback = (fallback && fallback.length) ? fallback : [[0, 0, 0, 1]];
        var out = [];
        for (var i = 0; i < n; i++) { var c = arr[i]; if (!c || !c.length) { c = fallback[Math.min(i, fallback.length - 1)]; } out.push(normalizeColor(c)); }
        return out;
    }
    function resizeTexts(arr, n, fallback) {
        arr = arr || []; fallback = (fallback && fallback.length) ? fallback : [""];
        var out = [];
        for (var i = 0; i < n; i++) { var v = arr[i]; if (v === undefined || v === null) { v = fallback[Math.min(i, fallback.length - 1)]; } out.push(String(v)); }
        return out;
    }
    function roleParamSpec(role) { return clone(ROLE_SPECS[normalizeRole(role)]); }
    function legacyDefaultState() {
        return {
            stateCount: 3, transition: 0.8, ease: 2,
            elements: [{ role: "dataText", layer: "" }, { role: "progress", layer: "" }, { role: "statusColor", layer: "" }, { role: "statusText", layer: "" }]
        };
    }
    function legacyBuildConfig(state) {
        state = state || legacyDefaultState();
        var n = clampStateCount(state.stateCount);
        var srcEls = state.elements || [];
        var elements = [];
        for (var i = 0; i < srcEls.length; i++) {
            var se = srcEls[i] || {}; var role = normalizeRole(se.role);
            elements.push({ layer: toStr(se.layer, ""), role: role, params: legacyBuildParams(role, se, n) });
        }
        return {
            schemaVersion: 2, masterLayerName: "MASTER",
            master: { transition: toNumber(state.transition, 0.8), ease: Math.round(toNumber(state.ease, 2)) },
            elements: elements
        };
    }
    function legacyBuildParams(role, se, n) {
        if (role === "dataText") {
            return { states: resizeNumbers(se.states, n, DEFAULT_STATES), decimals: Math.round(toNumber(se.decimals, 1)), padding: Math.round(toNumber(se.padding, 0)), prefix: toStr(se.prefix, ""), suffix: toStr(se.suffix, ""), unit: toStr(se.unit, " °C"), thousands: !!se.thousands };
        }
        if (role === "progress") { return { states: resizeNumbers(se.states, n, DEFAULT_STATES), min: toNumber(se.min, 0), max: toNumber(se.max, 100), axis: (se.axis === "y") ? "y" : "x" }; }
        if (role === "statusColor") { return { colors: resizeColors(se.colors, n, DEFAULT_COLORS) }; }
        if (role === "statusText") { return { labels: resizeTexts(se.labels, n, DEFAULT_LABELS) }; }
        return {};
    }
    function legacyValidateState(state) {
        var errors = [];
        if (!state || typeof state !== "object") { return { ok: false, errors: ["state 为空或不是对象"] }; }
        var sc = state.stateCount;
        if (typeof sc !== "number" || isNaN(sc) || sc % 1 !== 0 || sc < 2 || sc > 5) { errors.push("状态数(stateCount)必须为 2–5 的整数，当前: " + sc); }
        var els = state.elements || [];
        if (!els.length) { errors.push("至少需要一个元素"); }
        for (var i = 0; i < els.length; i++) { var e = els[i] || {}; if (!e.layer || String(e.layer).replace(/\s/g, "") === "") { errors.push("元素[" + (i + 1) + "]: 图层名不能为空"); } if (ROLES.indexOf(e.role) < 0) { errors.push("元素[" + (i + 1) + "]: 角色无效: " + e.role); } }
        return { ok: errors.length === 0, errors: errors };
    }
    function roleLabel(role) { return ROLE_LABELS[normalizeRole(role)] || role; }

    /* =====================================================================
     * 导出
     * ===================================================================== */
    var FUI = {
        // ---- 新 DATA & UNIT ----
        DATATYPE_DEFAULTS: DATATYPE_DEFAULTS,
        BEHAVIORS: BEHAVIORS.slice(),
        FORMATS: FORMATS.slice(),
        getType: dtGetType,
        typeList: dtTypeList,
        typeDefaults: dtTypeDefaults,
        defaultDataState: defaultDataState,
        buildApplyOptions: buildApplyOptions,
        validateDataState: validateDataState,

        // ---- 旧 legacy（保留兼容） ----
        ROLES: ROLES.slice(),
        roleLabel: roleLabel,
        roleParamSpec: roleParamSpec,
        defaultState: legacyDefaultState,
        buildConfig: legacyBuildConfig,
        validateState: legacyValidateState,

        _internal: {
            clampStateCount: clampStateCount,
            resizeNumbers: resizeNumbers, resizeColors: resizeColors, resizeTexts: resizeTexts,
            numOrNull: numOrNull
        }
    };

    if (typeof module !== "undefined" && module.exports) { module.exports = FUI; }
    if (typeof window !== "undefined") { window.FUI = FUI; }
    if (global && !global.FUI) { global.FUI = FUI; }

})(typeof globalThis !== "undefined" ? globalThis : this);

