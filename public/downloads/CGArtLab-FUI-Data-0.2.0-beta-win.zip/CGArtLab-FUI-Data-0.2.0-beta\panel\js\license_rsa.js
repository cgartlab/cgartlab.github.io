/**
 * license_rsa.js —— 许可证签名校验（仅 CEP 面板 / Node 使用，依赖 BigInt）
 * © 2026 CGArtLab · https://cgartlab.com · CGArtLab FUI Data
 * ------------------------------------------------------------------
 * RSA-2048 / PKCS#1 v1.5 / SHA-256。ExtendScript 没有 BigInt，所以签名校验只在
 * 面板侧做；JSX 侧收到的是面板签发、用 HMAC 保护的一次性令牌（见 license_core.issueToken）。
 *
 * 公钥在首次 `genkey` 后由 tools/license/keygen.js 写入 PUBLIC_KEY 常量。
 */
(function (root, factory) {
    if (typeof module === "object" && module && module.exports) {
        // Node：源码布局同目录，交付包布局在 ../jsx/
        var core;
        try { core = require("./license_core.js"); }
        catch (e) { core = require("../jsx/license_core.js"); }
        module.exports = factory(core);
    } else {
        root.FuiLicenseRsa = factory(root.FuiLicenseCore);
    }
})((typeof globalThis !== "undefined") ? globalThis :
    ((typeof self !== "undefined") ? self :
        ((typeof window !== "undefined") ? window : this)), function (C) {

    /* genkey 后替换：模数 n（十六进制）与指数 e（十六进制） */
    var PUBLIC_KEY = {
        n: "9e5f6ae70e8cb469da0a8365309eb18ad3089c1f071ba830c83cd1438261bcd9c7d40254350f3e75584639a9d673c61f7896c30f144a83c3e52cc08d02784b28de20f4c114910c292d6ae85079ffa97b6619f05d7f68adbfe6f237535e1cc048f286ddca82cbbd3ac6587a3d7a5f8f1397f960b6f141e4f2f799c7c411647fd4104d9b8b82437720d3ae535cb6a25e1dee7bc6e7715829f9ab687cd6e7b84c3fdb5f57dfc67f5581815c9046e71325c2168a576637972997924d4a000e4ba5b8719b2094e1c7f8fa4812246438d76e226757cfa14942deec7fc8cc1d5e33d23e73a7513fdedc83a94b2c5cc9738b2178beb1477d7e702f90ac74904863050e15",
        e: "010001"
    };

    var SHA256_DIGESTINFO = "3031300d060960864801650304020105000420";

    BigInt.prototype.toJSON = BigInt.prototype.toJSON || function () { return this.toString(); };

    function modPow(base, exp, mod) {
        var result = BigInt(1);
        base = base % mod;
        while (exp > BigInt(0)) {
            if (exp & BigInt(1)) { result = (result * base) % mod; }
            base = (base * base) % mod;
            exp >>= BigInt(1);
        }
        return result;
    }

    function hexToBigInt(hex) {
        return BigInt("0x" + (String(hex).replace(/[^0-9a-fA-F]/g, "") || "0"));
    }

    function bigIntToHex(num, byteLen) {
        var s = num.toString(16);
        while (s.length < byteLen * 2) { s = "0" + s; }
        return s;
    }

    /**
     * 校验签名。
     * @param {string} payloadStr 被签名的原文（规范化 JSON）
     * @param {string} sigBase64  签名（base64）
     * @param {string} [nHex]     模数，缺省用内置公钥
     * @param {string} [eHex]     指数，缺省用内置公钥
     */
    function verify(payloadStr, sigBase64, nHex, eHex) {
        nHex = nHex || PUBLIC_KEY.n;
        eHex = eHex || PUBLIC_KEY.e;
        if (!nHex || nHex.indexOf("{{") === 0) {
            return { ok: false, reason: "no-public-key" };
        }
        var n = hexToBigInt(nHex);
        var e = hexToBigInt(eHex);
        var k = Math.ceil(nHex.replace(/^0+/, "").length / 2);
        var sig = C.base64ToBytes(sigBase64);
        if (sig.length !== k) { return { ok: false, reason: "bad-sig-length" }; }

        var sigHex = C.bytesToHex(sig);
        var s = hexToBigInt(sigHex);
        if (s >= n) { return { ok: false, reason: "sig-out-of-range" }; }
        var m = modPow(s, e, n);
        var emHex = bigIntToHex(m, k);

        // PKCS#1 v1.5: 00 01 FF...FF 00 <DigestInfo>
        if (emHex.substring(0, 4) !== "0001") { return { ok: false, reason: "bad-padding" }; }
        var sep = emHex.indexOf("00", 4);
        if (sep < 0) { return { ok: false, reason: "bad-padding" }; }
        var psLen = (sep - 4) / 2;
        if (psLen < 8) { return { ok: false, reason: "bad-padding" }; }
        for (var i = 4; i < sep; i += 2) {
            if (emHex.substring(i, i + 2) !== "ff") { return { ok: false, reason: "bad-padding" }; }
        }
        var t = emHex.substring(sep + 2);
        var expected = SHA256_DIGESTINFO + C.sha256Hex(payloadStr);
        if (t !== expected) { return { ok: false, reason: "digest-mismatch" }; }
        return { ok: true };
    }

    /** 校验整张许可证：拆 sig，验签，返回 payload */
    function verifyLicense(licenseObj, nHex, eHex) {
        if (!licenseObj || typeof licenseObj !== "object") { return { ok: false, reason: "no-license" }; }
        if (licenseObj.sig === undefined) { return { ok: false, reason: "no-sig" }; }
        var payload = {};
        for (var k in licenseObj) {
            if (licenseObj.hasOwnProperty(k) && k !== "sig") { payload[k] = licenseObj[k]; }
        }
        var r = verify(C.canonical(payload), licenseObj.sig, nHex, eHex);
        if (!r.ok) { return r; }
        payload.sig = licenseObj.sig;
        return { ok: true, payload: payload };
    }

    return {
        PUBLIC_KEY: PUBLIC_KEY,
        verify: verify,
        verifyLicense: verifyLicense
    };
});
