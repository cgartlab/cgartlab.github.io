/**
 * fui_panel_host.jsx —— CEP 面板宿主入口（ES3，仅在 AE 内执行）
 * ------------------------------------------------------------------
 * 由 manifest 的 <ScriptPath> 在扩展加载时求值，暴露给面板 evalScript 调用：
 *   fuiPanelApplyFromFile(path, compHint?)  读临时 JSON → fuiAttach → 写 _result.json
 *   fuiGetLayerListJSON()                   当前 active CompItem 图层名 JSON 数组
 *   fuiBuildDemoComp()                      建/重置 FUI_Demo 合成（返回 CompItem）
 *   fuiSetStateAtTime(idx)                  在 comp.time 处给 MASTER.State 打点
 * 引擎 fui_ease/roles/attach 通过 $.evalFile 从同目录加载。
 * 全程 ES3；不改其它图层、不保存工程；undo/suppressDialogs 包裹。
 */

var FUI_PANEL_ENGINE_LOADED = false;

/* 加载本文件时（ScriptPath 求值）固化宿主目录，供后续 evalScript 调用稳定定位引擎 */
var FUI_PANEL_HOST_DIR = "";
try { FUI_PANEL_HOST_DIR = File($.fileName).parent.fsName; } catch (eHostDir) { FUI_PANEL_HOST_DIR = ""; }

/* 云端下发的全量规格（面板调 fuiSetDatatypeSpec 写入）；有值时优先于本地 .enc */
var __fuiCloudSpecJSON = null;

/* ---------- 基础 ---------- */
function fuiPanelHostDir() {
    if (FUI_PANEL_HOST_DIR) { return FUI_PANEL_HOST_DIR; }
    try { return File($.fileName).parent.fsName; } catch (e) { return ""; }
}

/* 面板在 boot 时显式传入扩展 jsx 目录（$.fileName 在 CEP 自动加载时不可靠）*/
function fuiPanelSetHostDir(d) {
    try { FUI_PANEL_HOST_DIR = String(d); } catch (e) { }
    return "ok|" + FUI_PANEL_HOST_DIR;
}

function fuiPanelLoadEngine() {
    if (FUI_PANEL_ENGINE_LOADED) { return true; }
    var dir = fuiPanelHostDir();
    if (!dir) { return false; }
    var files = ["fui_ease.jsx", "fui_roles.jsx", "fui_attach.jsx", "license_gate.jsx"];
    for (var i = 0; i < files.length; i++) {
        var f = new File(dir + "/" + files[i]);
        if (f.exists) {
            try { $.evalFile(f); } catch (eEval) {}
        }
    }
    FUI_PANEL_ENGINE_LOADED = (typeof fuiAttach === "function");
    return FUI_PANEL_ENGINE_LOADED;
}

function fuiPanelJson(o) {
    try { return JSON.stringify(o); } catch (e) {
        return "{\"ok\":false,\"applied\":[],\"errors\":[\"JSON.stringify failed\"]}";
    }
}

function fuiPanelWriteResult(jsonPath, obj) {
    try {
        var base = String(jsonPath).replace(/\\/g, "/");
        var outPath = base.replace(/\.json$/i, "") + "_result.json";
        var f = new File(outPath);
        f.encoding = "UTF-8";
        if (f.open("w")) {
            f.write(fuiPanelJson(obj));
            f.close();
        }
        return outPath;
    } catch (e) { return ""; }
}

/* ---------- 定位合成 / 图层 ---------- */
function fuiPanelFindCompByName(name) {
    var proj = app.project;
    if (!proj) { return null; }
    for (var i = 1; i <= proj.numItems; i++) {
        var it = null;
        try { it = proj.item(i); } catch (eItem) { it = null; }
        if (it && it instanceof CompItem && it.name === name) { return it; }
    }
    return null;
}

function fuiPanelResolveComp(compHint) {
    // 1) 显式 hint：名字或 CompItem
    if (compHint) {
        if (typeof compHint === "string") {
            var byName = fuiPanelFindCompByName(compHint);
            if (byName) { return byName; }
        } else {
            try { if (compHint instanceof CompItem) { return compHint; } } catch (eC) {}
        }
    }
    // 2) 默认 activeItem（须 CompItem）
    var active = null;
    try { active = app.project ? app.project.activeItem : null; } catch (eA) { active = null; }
    if (active && active instanceof CompItem) { return active; }
    // 3) 回退：名为 FUI_Demo 的合成
    return fuiPanelFindCompByName("FUI_Demo");
}

function fuiPanelFindLayerByName(comp, name) {
    for (var i = 1; i <= comp.numLayers; i++) {
        if (comp.layer(i).name === name) { return comp.layer(i); }
    }
    return null;
}

/* ---------- 10.3: 应用配置 ---------- */
function fuiPanelApplyFromFile(jsonPath, compHint) {
    var res = { ok: false, applied: [], errors: [], comp: "" };
    if (!fuiHostLicenseAllow("batch")) {
        res.errors.push("LICENSE_REQUIRED");
        res.error = "LICENSE_REQUIRED";
        try { fuiPanelWriteResult(jsonPath, res); } catch (e0) { }
        return res;
    }
    try {
        var f = new File(jsonPath);
        if (!f.exists) {
            res.errors.push("配置文件不存在: " + jsonPath);
            fuiPanelWriteResult(jsonPath, res);
            return fuiPanelJson(res);
        }
        f.encoding = "UTF-8";
        if (!f.open("r")) {
            res.errors.push("无法读取配置文件: " + jsonPath);
            fuiPanelWriteResult(jsonPath, res);
            return fuiPanelJson(res);
        }
        var txt = f.read();
        f.close();

        var config = null;
        try { config = JSON.parse(txt); } catch (eParse) {
            res.errors.push("JSON 解析失败: " + String(eParse));
            fuiPanelWriteResult(jsonPath, res);
            return fuiPanelJson(res);
        }

        var comp = fuiPanelResolveComp(compHint);
        if (!comp) {
            res.errors.push("未找到可用合成：请激活一个合成或先点[生成Demo]");
            fuiPanelWriteResult(jsonPath, res);
            return fuiPanelJson(res);
        }
        res.comp = comp.name;

        if (!fuiPanelLoadEngine() || typeof fuiAttach !== "function") {
            res.errors.push("引擎加载失败：fui_ease/fui_roles/fui_attach 缺失或不就绪");
            fuiPanelWriteResult(jsonPath, res);
            return fuiPanelJson(res);
        }

        var r = fuiAttach(config, comp);
        res.ok = !!r.ok;
        res.applied = r.applied || [];
        res.errors = r.errors || [];
    } catch (e) {
        res.ok = false;
        res.errors.push("fatal: " + String(e) + " @" + (e.line !== undefined ? e.line : "?"));
    }
    fuiPanelWriteResult(jsonPath, res);
    return fuiPanelJson(res);
}

/* ---------- 10.3: 图层列表（可选 compHint：优先定位指定合成，缺省 activeItem→FUI_Demo） ---------- */
function fuiGetLayerListJSON(compHint) {
    try {
        var comp = fuiPanelResolveComp(compHint);
        if (!comp || !(comp instanceof CompItem)) { return "[]"; }
        var names = [];
        for (var i = 1; i <= comp.numLayers; i++) {
            names.push(comp.layer(i).name);
        }
        return fuiPanelJson(names);
    } catch (e) {
        return "[]";
    }
}

/* ---------- 10.3: 生成 Demo 合成 ---------- */
function fuiPanelFitLayer(layer, dur) {
    try { layer.inPoint = 0; } catch (eIn) {}
    try { layer.outPoint = dur; } catch (eOut) {}
}

function fuiBuildDemoComp() {
    var comp = null;
    try { app.beginSuppressDialogs(0); } catch (eS) {}
    try {
        app.beginUndoGroup("FUI Build Demo Comp");

        var existing = fuiPanelFindCompByName("FUI_Demo");
        if (existing) {
            try { existing.remove(); } catch (eRm) {}
        }

        comp = app.project.items.addComp("FUI_Demo", 1280, 720, 1, 10, 30);
        var dur = comp.duration;

        // 1) VAL_TEMP —— 文本
        var valTemp = comp.layers.addText("22.0 °C");
        valTemp.name = "VAL_TEMP";
        try { valTemp.property("ADBE Transform Group").property("ADBE Position").setValue([640, 260]); } catch (e1) {}
        fuiPanelFitLayer(valTemp, dur);

        // 2) BAR_FILL —— 实色（进度几何用）
        var bar = comp.layers.addSolid([0.20, 0.70, 1.0], "BAR_FILL", 800, 64, 1, dur);
        try { bar.property("ADBE Transform Group").property("ADBE Position").setValue([640, 380]); } catch (e2) {}
        fuiPanelFitLayer(bar, dur);

        // 3) STATUS_LIGHT —— 形状（含矢量填充色，供 statusColor 用）
        var light = comp.layers.addShape();
        light.name = "STATUS_LIGHT";
        try { light.property("ADBE Transform Group").property("ADBE Position").setValue([820, 480]); } catch (e3) {}
        try {
            var root = light.property("ADBE Root Vectors Group");
            var grp = root.addProperty("ADBE Vector Group");
            var gc = grp.property("ADBE Vectors Group");
            gc.addProperty("ADBE Vector Shape - Rect");
            gc.addProperty("ADBE Vector Graphic - Fill");
        } catch (eShape) {}
        fuiPanelFitLayer(light, dur);

        // 4) STATUS_TEXT —— 文本
        var statusText = comp.layers.addText("NOMINAL");
        statusText.name = "STATUS_TEXT";
        try { statusText.property("ADBE Transform Group").property("ADBE Position").setValue([640, 500]); } catch (e4) {}
        fuiPanelFitLayer(statusText, dur);

    } catch (eFatal) {
        comp = comp ? comp : fuiPanelFindCompByName("FUI_Demo");
    } finally {
        try { app.endUndoGroup(); } catch (eU) {}
        try { app.endSuppressDialogs(true); } catch (eR) {}
    }
    return comp;
}

/* ---------- 10.3: 在当前时间打点（可选 compHint） ---------- */
function fuiSetStateAtTime(idx, compHint) {
    var res = { ok: false, applied: [], errors: [] };
    try {
        var comp = fuiPanelResolveComp(compHint);
        if (!comp) { res.errors.push("未找到可用合成"); return fuiPanelJson(res); }
        var master = fuiPanelFindLayerByName(comp, "MASTER");
        if (!master) { res.errors.push("未找到 MASTER 层，请先[应用到AE]"); return fuiPanelJson(res); }
        var fx = null;
        try { fx = master.effect("State"); } catch (eFx) { fx = null; }
        if (!fx) { res.errors.push("MASTER 缺少 State 控件"); return fuiPanelJson(res); }
        var prop = fx.property("ADBE Slider Control-0001");
        var t = comp.time;
        prop.setValueAtTime(t, Number(idx));
        res.ok = true;
        res.applied.push("State@" + t.toFixed(3) + "s = " + idx);
    } catch (e) {
        res.errors.push("fatal: " + String(e));
    }
    return fuiPanelJson(res);
}

/* ==================================================================
 * DATA & UNIT 子系统（DATATYPE.md §7）
 *   fuiDetectLayer(layerName?)              检测文字/数字/单位/建议量纲
 *   fuiApplyData(layerNames, typeId, opts)  应用到目标层（单层或数组）
 *   fuiGetDatatypeSpecJSON()                读取 src/datatype_spec.json 原文（无则 "null"）
 *   fuiGetActiveCompName()                  当前目标合成名
 * 引擎 src/format_core.js + src/datatype_apply.jsx 通过 $.evalFile 从 panel/jsx 或 ../src 加载。
 * 注意：引擎也定义了 fuiDetectLayer/fuiApplyData，加载时捕获为“引擎原版”后把全局名恢复为
 *       本文件的宿主包装，保证面板 evalScript 用 (layerName / layerNames) 的稳定签名。
 * ================================================================== */
var FUI_DATA_ENGINE_LOADED = false;
var FUI_ENGINE_DETECT = null;   // datatype_apply.jsx 的 fuiDetectLayer(layer)
var FUI_ENGINE_APPLY = null;    // datatype_apply.jsx 的 fuiApplyData(targetOrSelection, typeId, options)

function fuiPanelSrcDir() {
    var dir = fuiPanelHostDir();
    if (!dir) { return ""; }
    try { return File(dir).parent.parent.fsName + "/src"; } catch (e) { return ""; }
}

/* 先在 panel/jsx（sync 产物）找，再回退 ../../src */
function fuiPanelDataFilePath(name) {
    var cands = [];
    var dir = fuiPanelHostDir();
    if (dir) { cands.push(dir + "/" + name); }
    var sd = fuiPanelSrcDir();
    if (sd) { cands.push(sd + "/" + name); }
    for (var i = 0; i < cands.length; i++) {
        var f = new File(cands[i]);
        if (f.exists) { return cands[i]; }
    }
    return "";
}

function fuiPanelLoadDataEngine() {
    if (FUI_DATA_ENGINE_LOADED && (FUI_ENGINE_DETECT !== null || FUI_ENGINE_APPLY !== null)) {
        return true;
    }
    var hostDetect = (typeof fuiDetectLayer === "function") ? fuiDetectLayer : null;
    var hostApply = (typeof fuiApplyData === "function") ? fuiApplyData : null;

    var corePath = fuiPanelDataFilePath("format_core.js");
    if (corePath) { try { $.evalFile(new File(corePath)); } catch (eCore) {} }
    var applyPath = fuiPanelDataFilePath("datatype_apply.jsx");
    if (applyPath) { try { $.evalFile(new File(applyPath)); } catch (eApply) {} }

    // 捕获引擎原版（evalFile 覆盖了同名全局）
    if (typeof fuiDetectLayer === "function" && fuiDetectLayer !== hostDetect) { FUI_ENGINE_DETECT = fuiDetectLayer; }
    if (typeof fuiApplyData === "function" && fuiApplyData !== hostApply) { FUI_ENGINE_APPLY = fuiApplyData; }

    // 恢复本文件宿主包装
    if (hostDetect) { fuiDetectLayer = hostDetect; }
    if (hostApply) { fuiApplyData = hostApply; }

    FUI_DATA_ENGINE_LOADED = true;
    // 已授权时把全量规格注入引擎注册表；未授权则保持免费档子集
    try { if (typeof fuiReloadSpecRegistry === "function") { fuiReloadSpecRegistry(); } } catch (eReg) { }
    return (FUI_ENGINE_DETECT !== null || FUI_ENGINE_APPLY !== null);
}

function fuiPanelResolveLayer(comp, layerName) {
    if (layerName !== undefined && layerName !== null && layerName !== "") {
        return fuiPanelFindLayerByName(comp, String(layerName));
    }
    try {
        var sel = comp.selectedLayers;
        if (sel && sel.length) { return sel[0]; }
    } catch (eSel) {}
    return null;
}

function fuiPanelResolveTargets(comp, layerNames) {
    var out = { layers: [], errors: [] };
    if (layerNames === undefined || layerNames === null || layerNames === "") {
        try {
            var sel = comp.selectedLayers;
            for (var s = 0; s < sel.length; s++) { out.layers.push(sel[s]); }
        } catch (eSel) {}
        return out;
    }
    if (Object.prototype.toString.call(layerNames) === "[object Array]") {
        for (var i = 0; i < layerNames.length; i++) {
            var l = fuiPanelFindLayerByName(comp, String(layerNames[i]));
            if (l) { out.layers.push(l); } else { out.errors.push("层未找到: " + layerNames[i]); }
        }
        return out;
    }
    var one = fuiPanelFindLayerByName(comp, String(layerNames));
    if (one) { out.layers.push(one); } else { out.errors.push("层未找到: " + layerNames); }
    return out;
}

/* 批量应用：每个图层可带不同的 type/options（用于多选混合值） */
/* ---------------- 授权闸门（fail-closed） ----------------
 * 免费档类型（只读/无付费数据表）不依赖授权模块，直接放行；
 * 付费类型与批量入口必须由 license_gate.jsx 明确放行。
 * 注意：不要用 `typeof fuiLicenseRequire === "function" && ...`，
 * 那样删掉/损坏 license_gate.jsx 就等于自动解锁（fail-open）。 */
var FUI_FREE_TYPE_IDS_HOST = ["plainText", "generic", "temperature", "percent"];

function fuiHostLicenseAllow(ent) {
    if (typeof fuiLicenseRequire !== "function") { return false; }
    try { return !!fuiLicenseRequire(ent); } catch (eGate) { return false; }
}
function fuiHostIsFreeType(typeId) {
    var t = String(typeId || "");
    for (var i = 0; i < FUI_FREE_TYPE_IDS_HOST.length; i++) {
        if (FUI_FREE_TYPE_IDS_HOST[i] === t) { return true; }
    }
    return false;
}
function fuiHostLicenseAllowType(typeId) {
    if (fuiHostIsFreeType(typeId)) { return true; }
    return fuiHostLicenseAllow("datatype");
}

function fuiApplyBatch(itemsJson) {
    if (!fuiHostLicenseAllow("batch")) {
        return fuiPanelJson({
            ok: false, error: "LICENSE_REQUIRED", errors: ["LICENSE_REQUIRED"],
            applied: [], results: []
        });
    }
    var items = [];
    try { items = JSON.parse(itemsJson); } catch (e) { items = []; }
    var out = { ok: true, errors: [], applied: [], results: [] };
    for (var i = 0; i < items.length; i++) {
        var it = items[i] || {};
        var r = null;
        try { r = fuiApplyData(it.name, it.type, it.options || {}); } catch (eOne) { r = { ok: false, errors: [String(eOne)], applied: [] }; }
        out.results.push(r);
        if (!r || !r.ok) { out.ok = false; }
        var er = (r && r.errors) || [];
        for (var e = 0; e < er.length; e++) { out.errors.push(String(er[e])); }
        var ap = (r && r.applied) || [];
        for (var a = 0; a < ap.length; a++) { out.applied.push(String(ap[a])); }
    }
    return fuiPanelJson(out);
}

/* 当前 Value 控件状态（Slider/Point 兼容） */
function fuiValueStatus(layer) {
    try {
        var fx = null;
        try { fx = layer.effect("数值"); } catch (e1) { fx = null; }
        if (!fx) { try { fx = layer.effect("Value"); } catch (e2) { fx = null; } }
        if (!fx) { return null; }
        var p = null, isPoint = false;
        try { p = fx.property("ADBE Point Control-0001"); if (p) { isPoint = true; } } catch (e3) { p = null; }
        if (!p) { try { p = fx.property("ADBE Slider Control-0001"); } catch (e4) { p = null; } }
        if (!p) { return null; }
        var v = p.value; if (isPoint) { v = v[0]; }
        var keyed = (p.numKeys > 0);
        var atKey = false;
        var comp = layer.containingComp;
        var t = comp ? comp.time : 0;
        if (keyed) {
            var fr = comp ? comp.frameRate : 25;
            for (var i = 1; i <= p.numKeys; i++) { if (Math.abs(p.keyTime(i) - t) < 0.5 / fr) { atKey = true; break; } }
        }
        return { value: v, keyed: keyed, atKeyframe: atKey, keys: p.numKeys, isPoint: isPoint, prop: p, compTime: t };
    } catch (e) { return null; }
}
function fuiGetValueState(layerName) {
    var comp = fuiPanelResolveComp(null); if (!comp) { return fuiPanelJson({ ok: false }); }
    var layer = null;
    if (layerName) { layer = fuiPanelResolveLayer(comp, String(layerName)); }
    else { try { layer = comp.selectedLayers[0]; } catch (e) { layer = null; } }
    var st = layer ? fuiValueStatus(layer) : null;
    if (!st) { return fuiPanelJson({ ok: false }); }
    return fuiPanelJson({ ok: true, value: st.value, keyed: st.keyed, atKeyframe: st.atKeyframe, keys: st.keys });
}
function fuiSetValueDirect(layerName, value) {
    var comp = fuiPanelResolveComp(null); if (!comp) { return fuiPanelJson({ ok: false, error: "no comp" }); }
    var layer = fuiPanelResolveLayer(comp, String(layerName || ""));
    var st = layer ? fuiValueStatus(layer) : null; if (!st) { return fuiPanelJson({ ok: false, error: "no value control" }); }
    var v = Number(value); if (!isFinite(v)) { return fuiPanelJson({ ok: false, error: "bad value" }); }
    try {
        if (st.keyed) { st.prop.setValueAtTime(st.compTime, st.isPoint ? [v, 0] : v); }
        else { st.prop.setValue(st.isPoint ? [v, 0] : v); }
        return fuiPanelJson({ ok: true, value: v, keyed: st.keyed });
    } catch (e) { return fuiPanelJson({ ok: false, error: String(e) }); }
}
function fuiKeyframeValue(layerName) {
    var comp = fuiPanelResolveComp(null); if (!comp) { return fuiPanelJson({ ok: false, error: "no comp" }); }
    var layer = fuiPanelResolveLayer(comp, String(layerName || ""));
    var st = layer ? fuiValueStatus(layer) : null; if (!st) { return fuiPanelJson({ ok: false, error: "no value control" }); }
    try {
        if (!st.keyed) { st.prop.setValueAtTime(st.compTime, st.isPoint ? [st.value, 0] : st.value); }
        return fuiPanelJson({ ok: true, keyed: true });
    } catch (e) { return fuiPanelJson({ ok: false, error: String(e) }); }
}

/* 通用参数 Effect 映射（面板 K 帧按钮使用） */
var FUI_PARAM_MAP = {
    decimals: ["小数位", "FUI_Decimals", "slider"],
    padding: ["前导零", "FUI_Padding", "slider"],
    prefixSpace: ["前缀空格", "FUI_PrefixSpace", "slider"],
    unitSpace: ["单位空格", "FUI_UnitSpace", "slider"],
    suffixSpace: ["后缀空格", "FUI_SuffixSpace", "slider"],
    thousands: ["千分位", "FUI_Thousands", "checkbox"],
    timerMs: ["毫秒", null, "checkbox"],
    timerMode: ["自动计时", null, "checkbox"],
    numColor: ["颜色", null, "color"]
};
function fuiFindParamProp(layer, key) {
    var def = FUI_PARAM_MAP[key]; if (!def) { return null; }
    var fx = null;
    for (var i = 0; i < 2; i++) { var nm = def[i]; if (!nm) { continue; } try { fx = layer.effect(nm); } catch (e) { fx = null; } if (fx) { break; } }
    if (!fx) { return null; }
    var prop = null;
    try { if (def[2] === "checkbox") { prop = fx.property("ADBE Checkbox Control-0001"); } else if (def[2] === "color") { prop = fx.property("ADBE Fill-0002"); } else { prop = fx.property("ADBE Slider Control-0001"); } } catch (e2) { prop = null; }
    return prop ? { prop: prop, type: def[2] } : null;
}
function fuiGetParamStates(layerName) {
    var comp = fuiPanelResolveComp(null); if (!comp) { return fuiPanelJson({ ok: false }); }
    var layer = layerName ? fuiPanelResolveLayer(comp, String(layerName)) : null;
    if (!layer) { return fuiPanelJson({ ok: false }); }
    var out = { ok: true, params: {} };
    var t = comp.time, fr = comp.frameRate || 25;
    for (var key in FUI_PARAM_MAP) {
        if (!FUI_PARAM_MAP.hasOwnProperty(key)) { continue; }
        var pp = fuiFindParamProp(layer, key); if (!pp) { continue; }
        var keyed = pp.prop.numKeys > 0, atK = false;
        if (keyed) { for (var k = 1; k <= pp.prop.numKeys; k++) { if (Math.abs(pp.prop.keyTime(k) - t) < 0.5 / fr) { atK = true; break; } } }
        var val = pp.prop.value; if (pp.type === "color" && val && val.length) { val = [val[0], val[1], val[2]]; }
        out.params[key] = { keyed: keyed, atKeyframe: atK, value: val };
    }
    return fuiPanelJson(out);
}
function fuiSetParamDirect(layerName, key, valueJson) {
    var comp = fuiPanelResolveComp(null); if (!comp) { return fuiPanelJson({ ok: false }); }
    var layer = fuiPanelResolveLayer(comp, String(layerName || "")); if (!layer) { return fuiPanelJson({ ok: false }); }
    var pp = fuiFindParamProp(layer, key); if (!pp) { return fuiPanelJson({ ok: false, error: "no control" }); }
    var val = valueJson;
    try { if (typeof valueJson === "string" && valueJson.charAt(0) === "[") { val = JSON.parse(valueJson); } } catch (eJ) { }
    try {
        if (pp.type === "checkbox") { val = (val === true || val === 1 || val === "1" || val === "true") ? 1 : 0; }
        else if (pp.type === "color") {
            if (typeof val === "string" && val.charAt(0) === "#") {
                val = [parseInt(val.substr(1, 2), 16) / 255, parseInt(val.substr(3, 2), 16) / 255, parseInt(val.substr(5, 2), 16) / 255];
            }
        } else { val = Number(val); if (!isFinite(val)) { return fuiPanelJson({ ok: false }); } }
        if (pp.prop.numKeys > 0) { pp.prop.setValueAtTime(comp.time, val); } else { pp.prop.setValue(val); }
        return fuiPanelJson({ ok: true });
    } catch (e) { return fuiPanelJson({ ok: false, error: String(e) }); }
}
function fuiKeyframeParam(layerName, key) {
    var comp = fuiPanelResolveComp(null); if (!comp) { return fuiPanelJson({ ok: false }); }
    var layer = fuiPanelResolveLayer(comp, String(layerName || "")); if (!layer) { return fuiPanelJson({ ok: false }); }
    var pp = fuiFindParamProp(layer, key); if (!pp) { return fuiPanelJson({ ok: false, error: "no control" }); }
    try {
        if (pp.prop.numKeys === 0) { pp.prop.setValueAtTime(comp.time, pp.prop.value); }
        return fuiPanelJson({ ok: true });
    } catch (e) { return fuiPanelJson({ ok: false, error: String(e) }); }
}

function fuiSetPlainText(layerName, text) {
    var comp = fuiPanelResolveComp(null); if (!comp) { return fuiPanelJson({ ok: false, error: "no comp" }); }
    var layer = fuiPanelResolveLayer(comp, String(layerName || "")); if (!layer) { return fuiPanelJson({ ok: false, error: "no layer" }); }
    try {
        var src = layer.property("Source Text");
        var td = src.value;
        // contenteditable 可能产生不换行空格，AE 文本中统一为普通空格
        td.text = String(text === null || text === undefined ? "" : text).replace(/\u00A0/g, " ");
        src.setValue(td);
        return fuiPanelJson({ ok: true, text: td.text });
    } catch (e) { return fuiPanelJson({ ok: false, error: String(e) }); }
}

function fuiDetectLayers(namesJson, deep) {
    var names = [];
    try { names = JSON.parse(namesJson); } catch (e) { names = []; }
    var items = [];
    for (var i = 0; i < names.length; i++) { items.push(fuiDetectLayer(names[i], deep === true)); }
    return fuiPanelJson({ ok: true, items: items });
}

/* 云端：面板从 /v1/spec 取到规格后调用，注入引擎并置为云端已授权 */
function fuiSetDatatypeSpec(jsonStr, plan) {
    try {
        var spec = JSON.parse(jsonStr);
        var types = (spec && spec.types) ? spec.types : spec;
        if (!types || typeof types !== "object") { return "{\"ok\":false,\"error\":\"bad-spec\"}"; }
        if (typeof FUIFormatCore === "undefined" || !FUIFormatCore.setRegistry) {
            return "{\"ok\":false,\"error\":\"no-engine\"}";
        }
        FUIFormatCore.setRegistry(types);
        __fuiCloudSpecJSON = JSON.stringify({ schemaVersion: 1, types: types });
        if (typeof fuiLicenseSetCloud === "function") {
            try { fuiLicenseSetCloud(JSON.stringify({ plan: plan || "buyout", ents: ["all_types", "batch"] })); } catch (eCl) {}
        }
        var n = 0, k;
        for (k in types) { if (types.hasOwnProperty(k)) { n++; } }
        return "{\"ok\":true,\"types\":" + n + "}";
    } catch (e) {
        return "{\"ok\":false,\"error\":\"" + String(e).replace(/"/g, "'") + "\"}";
    }
}

/* 授权后把全量规格注入引擎注册表（无授权时静默跳过，保持免费档） */
function fuiReloadSpecRegistry() {
    try {
        if (typeof fuiLicenseDecryptSpec !== "function") { return "{\"ok\":false,\"error\":\"no-gate\"}"; }
        if (typeof fuiLicenseRequire !== "function" || !fuiLicenseRequire("all_types")) {
            return "{\"ok\":false,\"error\":\"LICENSE_REQUIRED\"}";
        }
        var encPath = fuiPanelDataFilePath("datatype_spec.enc");
        if (!encPath) { return "{\"ok\":false,\"error\":\"no-enc\"}"; }
        var json = fuiLicenseDecryptSpec(encPath);
        var spec = JSON.parse(json);
        var types = spec && spec.types ? spec.types : spec;
        if (typeof FUIFormatCore === "undefined" || !FUIFormatCore.setRegistry) {
            return "{\"ok\":false,\"error\":\"no-engine\"}";
        }
        FUIFormatCore.setRegistry(types);
        var n = 0, k;
        for (k in types) { if (types.hasOwnProperty(k)) { n++; } }
        return "{\"ok\":true,\"types\":" + n + "}";
    } catch (e) {
        return "{\"ok\":false,\"error\":\"" + String(e).replace(/"/g, "'") + "\"}";
    }
}

function fuiGetDatatypeSpecJSON() {
    try {
        // 0) 云端已注入：直接返回（薄客户端从 /v1/spec 拉取后由 fuiSetDatatypeSpec 写入）
        if (__fuiCloudSpecJSON) { return __fuiCloudSpecJSON; }
        // 1) 已授权：解密全量规格（datatype_spec.enc）
        try {
            if (typeof fuiLicenseRequire === "function" && fuiLicenseRequire("all_types") &&
                typeof fuiLicenseDecryptSpec === "function") {
                var encPath = fuiPanelDataFilePath("datatype_spec.enc");
                if (encPath) {
                    var full = fuiLicenseDecryptSpec(encPath);
                    if (full) { return full; }
                }
            }
        } catch (eLic) { /* 解密失败则退到免费档，不打断面板 */ }

        // 2) 免费档：明文子集
        var freePath = fuiPanelDataFilePath("datatype_spec.free.json");
        if (freePath) {
            var ff = new File(freePath);
            ff.encoding = "UTF-8";
            if (ff.open("r")) { var ft = ff.read(); ff.close(); return ft; }
        }

        // 3) 兼容旧结构（未加密时的整份明文）
        var p = fuiPanelDataFilePath("datatype_spec.json");
        if (!p) { return "null"; }
        var f = new File(p);
        f.encoding = "UTF-8";
        if (!f.open("r")) { return "null"; }
        var txt = f.read();
        f.close();
        return txt;
    } catch (e) { return "null"; }
}

function fuiGetActiveCompName() {
    try {
        var c = fuiPanelResolveComp(null);
        return c ? String(c.name) : "";
    } catch (e) { return ""; }
}

/* 返回当前合成中所有选中图层：[{i:图层索引, n:图层名}]（索引用于稳定判重，名称用于应用） */
function fuiGetSelection() {
    try {
        var comp = fuiPanelResolveComp(null);
        if (!comp) { return "[]"; }
        var sel = comp.selectedLayers;
        var arr = [];
        for (var i = 0; i < sel.length; i++) { arr.push({ i: sel[i].index, n: sel[i].name }); }
        return fuiPanelJson(arr);
    } catch (e) { return "[]"; }
}

/* 面板对外：检测图层（layerName 可为 名称字符串 / Layer 对象；缺省用当前选中层）
 * 返回“对象”（供引擎内部以对象使用），并挂 toString→JSON，供 evalScript 直接调用时也能转字符串。 */
function fuiDetectLayer(layerName, deep) {
    var res = {
        ok: false, isText: false, isNumeric: false, text: "",
        parsedValue: null, parsedUnit: "", suggestedType: "", layerName: "", errors: []
    };
    res.toString = function () { return fuiPanelJson(res); };
    var allowText = (deep === true);
    try {
        fuiPanelLoadDataEngine();
        var layer = null;
        if (layerName && typeof layerName === "object") {
            layer = layerName; // 引擎内部以 Layer 对象回调本函数（如 apply 的初值检测）
        } else {
            var comp = fuiPanelResolveComp(null);
            if (!comp) { res.errors.push("当前没有可用合成"); return res; }
            layer = fuiPanelResolveLayer(comp, layerName);
        }
        if (!layer) { res.errors.push("请先在 AE 中选中一个图层（或从下拉选择）"); return res; }
        res.layerName = layer.name;
        if (FUI_ENGINE_DETECT === null) {
            res.errors.push("检测引擎未就绪：src/datatype_apply.jsx 缺失或未加载");
            return res;
        }
        var r = null;
        if (allowText) {
            r = FUI_ENGINE_DETECT(layer);
            if (r && typeof r === "object") {
                res.isText = (r.isText === undefined) ? true : !!r.isText;
                res.text = (r.text !== undefined) ? String(r.text) : ((r.raw !== undefined) ? String(r.raw) : "");
                res.parsedValue = (r.parsedValue !== undefined) ? r.parsedValue : ((r.value !== undefined) ? r.value : null);
                res.parsedUnit = (r.parsedUnit !== undefined) ? String(r.parsedUnit) : ((r.unit !== undefined) ? String(r.unit) : "");
                res.suggestedType = (r.suggestedType === undefined || r.suggestedType === null) ? "" : String(r.suggestedType);
                res.isNumeric = (r.isNumeric === undefined) ? (res.parsedValue !== null) : !!r.isNumeric;
                if (r.prefix !== undefined && r.prefix !== null) { res.prefix = String(r.prefix).replace(/^[+\-]/, "").replace(/^\s+|\s+$/g, ""); }
                if (r.suffix !== undefined && r.suffix !== null) { res.suffix = String(r.suffix).replace(/^\s+|\s+$/g, ""); }
                if (r.forceSign !== undefined) { res.forceSign = !!r.forceSign; }
            }
        } else {
            // 安全模式：绝不实例化 Source Text；类型/单位从 apply 写入的 comment 标记读取
            try { res.isText = (layer instanceof TextLayer); } catch (eSafeText) { res.isText = false; }
            var scmt = String(layer.comment || "");
            var smt = scmt.match(/FUI_TYPE:([A-Za-z0-9_\-]+)/);
            var smu = scmt.match(/FUI_UNIT:([^\s]+)/);
            res.suggestedType = (smt && smt[1]) ? smt[1] : "plainText";
            res.parsedUnit = (smu && smu[1]) ? smu[1] : "";
            res.isNumeric = (res.suggestedType !== "plainText");
            res.parsedValue = null;
            res.text = "";
        }
        res.ok = true;
        // 优先读取应用时写入的类型标记，解决同单位跨类型回读歧义（% 氧气/百分比、g 重量/加速度等）
        try {
            var cmt = String(layer.comment || "");
            var mt = cmt.match(/FUI_TYPE:([A-Za-z0-9_\-]+)/);
            if (mt && FUIFormatCore && FUIFormatCore.getType && FUIFormatCore.getType(mt[1])) {
                res.suggestedType = mt[1];
            }
        } catch (eCmtType) { }
        try {
            var vst = fuiValueStatus(layer);
            if (vst) { res.valueCurrent = vst.value; res.valueKeyed = vst.keyed; res.valueAtKeyframe = vst.atKeyframe; res.valueKeyCount = vst.keys; res.hasValueControl = true; if (res.parsedValue === null || res.parsedValue === undefined) { res.parsedValue = vst.value; } }
            else { res.hasValueControl = false; }
        } catch (eVst) { res.hasValueControl = false; }
        // 回读图层上的 FUI_* 效果控件（若已应用过），供面板识别当前参数
        try {
            var ctrls = {}, any = false;
            var lyr = layer;
            var map = { decimals: ["小数位", "FUI_Decimals"], padding: ["前导零", "FUI_Padding"], prefixSpace: ["前缀空格"], unitSpace: ["单位空格"], suffixSpace: ["后缀空格"] };
            for (var ck in map) {
                if (map.hasOwnProperty(ck)) {
                    var arr = map[ck], fx = null;
                    for (var j = 0; j < arr.length; j++) {
                        try { fx = lyr.effect(arr[j]); } catch (eC1) { fx = null; }
                        if (fx) { break; }
                    }
                    if (fx) { try { ctrls[ck] = fx.property("ADBE Slider Control-0001").value; any = true; } catch (eC2) { } }
                }
            }
            var tfx = null;
            try { tfx = lyr.effect("千分位"); } catch (eC3) { tfx = null; }
            if (!tfx) { try { tfx = lyr.effect("FUI_Thousands"); } catch (eC3b) { tfx = null; } }
            if (tfx) { try { ctrls.thousands = tfx.property("ADBE Checkbox Control-0001").value > 0; any = true; } catch (eC4) { } }
            var msfx = null; try { msfx = lyr.effect("毫秒"); } catch (eC7) { msfx = null; }
            if (msfx) { try { res.timerMs = msfx.property("ADBE Checkbox Control-0001").value > 0; any = true; } catch (eC8) { } }
            if (any) { res.controls = ctrls; }
        } catch (eCtl) { }
        // 回读段落对齐/字体/字距（仅在显式深检测时读取 Source Text）
        if (allowText) {
            try {
                var stv = layer.property("Source Text").value;
                var jj = stv.justification;
                if (jj === ParagraphJustification.RIGHT_JUSTIFY) { res.align = "right"; }
                else if (jj === ParagraphJustification.CENTER_JUSTIFY) { res.align = "center"; }
                else { res.align = "left"; }
            } catch (eAl) { }
            try { res.font = String(layer.property("Source Text").value.font); } catch (eFnt) { }
            try { res.fontSize = layer.property("Source Text").value.fontSize; } catch (eFsz) { }
            try { res.tracking = layer.property("Source Text").value.tracking; } catch (eTrk) { }
        }
        // 颜色回读：优先 Effect Controls 的「颜色」Fill 效果（可K帧），否则回落到文本填充色
        try {
            var cfx = null;
            try { cfx = layer.effect("颜色"); } catch (eCfx0) { cfx = null; }
            if (!cfx) {
                try {
                    var paradeC = layer.property("ADBE Effect Parade");
                    for (var cP = 1; cP <= paradeC.numProperties; cP++) {
                        var pC = paradeC.property(cP);
                        try { if (pC.matchName === "ADBE Fill") { cfx = pC; break; } } catch (eCp) { }
                    }
                } catch (eCpar) { }
            }
            if (cfx) { var cc = cfx.property("ADBE Fill-0002").value; res.fillColor = [cc[0], cc[1], cc[2]]; res.hasColorFx = true; }
            else if (allowText) { var fcv = layer.property("Source Text").value.fillColor; res.fillColor = [fcv[0], fcv[1], fcv[2]]; }
        } catch (eFc) { }
        // 回读前后缀（独立子层）仅显式深检测
        if (allowText) {
        try {
            var compA = layer.containingComp;
            var pTxt = "", sTxt = "", uTxt = "", foundA = false;
            function isUnderA(L, root) {
                var p = L, d = 0;
                while (p && d < 10) { var par = null; try { par = p.parent; } catch (e) { par = null; } if (par === root) { return true; } p = par; d++; }
                return false;
            }
            for (var ka = 1; ka <= compA.numLayers; ka++) {
                var KK = compA.layer(ka);
                try {
                    if (isUnderA(KK, layer)) {
                        if (/^FUI前缀/.test(KK.name)) { pTxt = String(KK.property("Source Text").value.text); foundA = true; }
                        else if (/^FUI后缀/.test(KK.name)) { sTxt = String(KK.property("Source Text").value.text); foundA = true; }
                        else if (/^FUI单位/.test(KK.name)) { uTxt = String(KK.property("Source Text").value.text); foundA = true; }
                    }
                } catch (eKk) { }
            }
            if (foundA) { res.prefix = pTxt.replace(/^[+\-]/, ""); res.suffix = sTxt; res.unitLabel = uTxt.replace(/^[+\-]/, ""); }
            // 单位拆层后，文本里无单位 → 用单位子层推断单位与类型，避免被误判为通用数字
            if (uTxt) {
                try {
                    if (!res.parsedUnit) { res.parsedUnit = uTxt; }
                    if (!res.suggestedType || res.suggestedType === "generic") {
                        var FC = (typeof FUIFormatCore !== "undefined") ? FUIFormatCore : null;
                        var reg = FC ? FC.REGISTRY : null;
                        if (reg) {
                            var foundT = "";
                            for (var tp in reg) {
                                if (!reg.hasOwnProperty(tp)) { continue; }
                                if (reg[tp].format === "dms") { continue; } // 经纬度不拆单位层，避免 "°" 歧义
                                var uns = reg[tp].units || [];
                                for (var uu = 0; uu < uns.length; uu++) {
                                    if (uns[uu].label === uTxt || uns[uu].id === uTxt) { foundT = tp; break; }
                                }
                                if (foundT) { break; }
                            }
                            if (foundT) { res.suggestedType = foundT; }
                        }
                    }
                } catch (eUT) { }
            }
        } catch (eAff2) { }
        }
    } catch (e) {
        res.ok = false;
        res.errors.push("fatal: " + String(e) + " @" + (e.line !== undefined ? e.line : "?"));
    }
    return res;
}

/* 面板对外：应用数据到目标层（layerNames 可为 名称 / 名称数组 / Layer / Layer 数组；空=当前选中）
 * 返回“对象”（引擎内部批量递归同样以对象使用），并挂 toString→JSON。 */
function fuiApplyData(layerNames, typeId, options) {
    var res = { ok: false, applied: [], errors: [] };
    res.toString = function () { return fuiPanelJson(res); };
    // 付费类型必须先过授权闸门；免费类型（纯文本/通用数字/温度/百分比）直接放行
    if (!fuiHostLicenseAllowType(typeId)) {
        res.error = "LICENSE_REQUIRED";
        res.errors.push("LICENSE_REQUIRED");
        return res;
    }
    try {
        fuiPanelLoadDataEngine();
        if (FUI_ENGINE_APPLY === null) {
            res.errors.push("应用引擎未就绪：src/datatype_apply.jsx 缺失或未加载");
            return res;
        }
        // 仅当传入的是 Layer 对象或其数组时才直传引擎；名字数组/字符串走下方名字解析
        if (layerNames && typeof layerNames === "object") {
            var isLayerArg = false;
            try {
                if (layerNames instanceof Array) {
                    isLayerArg = layerNames.length > 0 && layerNames[0] && (typeof layerNames[0].property === "function");
                } else {
                    isLayerArg = (typeof layerNames.property === "function");
                }
            } catch (eLA) { isLayerArg = false; }
            if (isLayerArg) {
                var rObj = FUI_ENGINE_APPLY(layerNames, typeId, options);
                res.ok = !!(rObj && rObj.ok);
                res.applied = (rObj && rObj.applied) || [];
                if (rObj && rObj.errors) { for (var q = 0; q < rObj.errors.length; q++) { res.errors.push(rObj.errors[q]); } }
                return res;
            }
        }
        var comp = fuiPanelResolveComp(null);
        if (!comp) { res.errors.push("当前没有可用合成"); return res; }
        var tr = fuiPanelResolveTargets(comp, layerNames);
        for (var e = 0; e < tr.errors.length; e++) { res.errors.push(tr.errors[e]); }
        if (!tr.layers.length) {
            if (!res.errors.length) { res.errors.push("没有可用目标图层"); }
            return res;
        }
        var target = (tr.layers.length === 1) ? tr.layers[0] : tr.layers;
        var r = FUI_ENGINE_APPLY(target, typeId, options);
        if (r && typeof r === "object") {
            res.ok = !!r.ok;
            res.applied = r.applied || [];
            if (r.errors) { for (var k = 0; k < r.errors.length; k++) { res.errors.push(r.errors[k]); } }
        } else {
            res.ok = true;
        }
    } catch (e) {
        res.ok = false;
        res.errors.push("fatal: " + String(e) + " @" + (e.line !== undefined ? e.line : "?"));
    }
    return res;
}

/* 扩展加载时预载旧引擎，让 evalScript 直接可调用（失败静默，调用时再懒加载） */
try { fuiPanelLoadEngine(); } catch (eBoot) {}

