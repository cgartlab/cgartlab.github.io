@echo off
chcp 65001 >nul
title CGArtLab FUI Data 安装程序
echo.
echo 正在启动安装程序，请稍候...
echo.
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0install.ps1"
if errorlevel 1 (
  echo.
  echo 安装未完成，请查看上面的提示。
)
pause
