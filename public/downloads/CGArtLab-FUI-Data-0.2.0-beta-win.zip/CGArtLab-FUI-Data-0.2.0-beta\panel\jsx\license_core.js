/**
 * license_core.js —— 授权内核（UMD，Node / CEP 面板 / ExtendScript 三处共用）
 * © 2026 CGArtLab · https://cgartlab.com · CGArtLab FUI Data
 * ------------------------------------------------------------------
 * 只做纯计算：UTF-8、SHA-256、HMAC-SHA256、CTR 流加密、Base64、规范化 JSON、
 * 授权令牌签发/校验、机器码派生。无 DOM、无 AE API、无 Node 依赖。
 *
 * ES3 安全（仅 var / 无箭头 / 无模板串 / 无 typed array），
 * 以便 ExtendScript 通过 $.evalFile 直接加载。
 *
 * 挂在 globalThis.FuiLicenseCore（浏览器/JSX）或 module.exports（Node）。
 */
(function (root, factory) {
    if (typeof module === "object" && module && module.exports) {
        module.exports = factory();
    } else {
        root.FuiLicenseCore = factory();
    }
})((typeof globalThis !== "undefined") ? globalThis :
    ((typeof self !== "undefined") ? self :
        ((typeof window !== "undefined") ? window :
            ((typeof $ !== "undefined" && $.global) ? $.global : this))), function () {

    var PRODUCT = "cgartlab-fui-data";
    var CORE_VERSION = 2;      // 2 = RC4 + 折叠 MAC（v1 的 SHA-CTR 在 AE 里要 36 秒）
    var LEGACY_VERSION = 1;

    /* 免费档开放的数据类型（付费档给全量）。改动后需重新生成 datatype_spec.free.json。
     * plainText 也放进免费档：它是只读类型（不写表达式、不换算），不含任何付费数据表，
     * 且新文字图层默认会落到该类型；若免费档没有它，新手会看到「类型莫名变成通用数字」。 */
    var FREE_TYPE_IDS = ["plainText", "generic", "temperature", "percent"];

    /* 令牌/试用状态的 MAC key。仅防“手改令牌”，不是密码学边界。 */
    var GATE_KEY = "cgartlab.fui.gate.v1|7f3c1a9e5b2d4c6089ab";

    /* ---------------- 基础：UTF-8 / hex / base64 ---------------- */

    function utf8Bytes(str) {
        var out = [], i, c;
        str = String(str);
        for (i = 0; i < str.length; i++) {
            c = str.charCodeAt(i);
            if (c < 0x80) {
                out.push(c);
            } else if (c < 0x800) {
                out.push(0xC0 | (c >> 6), 0x80 | (c & 0x3F));
            } else if (c >= 0xD800 && c <= 0xDBFF && i + 1 < str.length) {
                var c2 = str.charCodeAt(i + 1);
                if (c2 >= 0xDC00 && c2 <= 0xDFFF) {
                    var cp = 0x10000 + ((c - 0xD800) << 10) + (c2 - 0xDC00);
                    out.push(0xF0 | (cp >> 18), 0x80 | ((cp >> 12) & 0x3F),
                        0x80 | ((cp >> 6) & 0x3F), 0x80 | (cp & 0x3F));
                    i++;
                } else {
                    out.push(0xEF, 0xBF, 0xBD);
                }
            } else {
                out.push(0xE0 | (c >> 12), 0x80 | ((c >> 6) & 0x3F), 0x80 | (c & 0x3F));
            }
        }
        return out;
    }

    var HEX_TAB = "0123456789abcdef";

    /* ExtendScript 已知坑：String.fromCharCode.apply(null, 大数组) 会让 AE 直接崩溃
     * （不是抛错，是进程退出）。这里统一用小段 += 拼接，单段上限 256 个码点。 */
    function codesToStr(codes) {
        var s = "", i, n = codes.length, seg = "";
        for (i = 0; i < n; i++) {
            seg += String.fromCharCode(codes[i] & 0xFFFF);
            if (seg.length >= 256) { s += seg; seg = ""; }
        }
        return s + seg;
    }
    var HEX_VAL = null;
    function hexValTable() {
        if (HEX_VAL) { return HEX_VAL; }
        HEX_VAL = [];
        var i, code;
        for (i = 0; i < 256; i++) { HEX_VAL[i] = -1; }
        for (i = 0; i < 16; i++) {
            code = HEX_TAB.charCodeAt(i);
            HEX_VAL[code] = i;
            HEX_VAL[String.fromCharCode(code).toUpperCase().charCodeAt(0)] = i;
        }
        return HEX_VAL;
    }

    /* 注意：ExtendScript 里逐字符 s += ... 是 O(n²)，42 KB 会跑到分钟级。
     * 一律「先放进数组、每 4096 字节用 fromCharCode 拼一次」。 */
    function bytesToHex(bytes) {
        var parts = [], buf = [], i, n = bytes.length, b;
        for (i = 0; i < n; i++) {
            b = bytes[i] & 0xFF;
            buf.push(HEX_TAB.charAt(b >> 4), HEX_TAB.charAt(b & 15));
            if (buf.length >= 8192) { parts.push(buf.join("")); buf = []; }
        }
        parts.push(buf.join(""));
        return parts.join("");
    }

    function hexToBytes(hex) {
        var out = [], i, n, c1, c2, tab = hexValTable();
        hex = String(hex);
        n = hex.length;
        for (i = 0; i + 1 < n; i += 2) {
            c1 = tab[hex.charCodeAt(i)];
            c2 = tab[hex.charCodeAt(i + 1)];
            if (c1 < 0 || c2 < 0) { continue; }   // 忽略换行/空格等分隔符
            out.push((c1 << 4) | c2);
        }
        return out;
    }

    var B64 = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";

    function bytesToBase64(bytes) {
        var s = "", i, b0, b1, b2;
        for (i = 0; i < bytes.length; i += 3) {
            b0 = bytes[i];
            b1 = i + 1 < bytes.length ? bytes[i + 1] : NaN;
            b2 = i + 2 < bytes.length ? bytes[i + 2] : NaN;
            s += B64.charAt(b0 >> 2);
            s += B64.charAt(((b0 & 3) << 4) | (isNaN(b1) ? 0 : b1 >> 4));
            s += isNaN(b1) ? "=" : B64.charAt(((b1 & 15) << 2) | (isNaN(b2) ? 0 : b2 >> 6));
            s += isNaN(b2) ? "=" : B64.charAt(b2 & 63);
        }
        return s;
    }

    function base64ToBytes(b64) {
        var out = [], i, n = 0, bits = 0, idx, ch;
        // 注意：ES3（ExtendScript）不允许字符类里出现未转义的 "/"，
        // 写成 [^A-Za-z0-9+/] 会让整个文件在 AE 里报 SyntaxError。
        b64 = String(b64).replace(/[^A-Za-z0-9+\/]/g, "");
        for (i = 0; i < b64.length; i++) {
            ch = b64.charAt(i);
            idx = B64.indexOf(ch);
            if (idx < 0) { continue; }
            n = (n << 6) | idx;
            bits += 6;
            if (bits >= 8) {
                bits -= 8;
                out.push((n >> bits) & 0xFF);
            }
        }
        return out;
    }

    /* ---------------- SHA-256 ---------------- */

    var K = [
        0x428a2f98, 0x71374491, 0xb5c0fbcf, 0xe9b5dba5, 0x3956c25b, 0x59f111f1, 0x923f82a4, 0xab1c5ed5,
        0xd807aa98, 0x12835b01, 0x243185be, 0x550c7dc3, 0x72be5d74, 0x80deb1fe, 0x9bdc06a7, 0xc19bf174,
        0xe49b69c1, 0xefbe4786, 0x0fc19dc6, 0x240ca1cc, 0x2de92c6f, 0x4a7484aa, 0x5cb0a9dc, 0x76f988da,
        0x983e5152, 0xa831c66d, 0xb00327c8, 0xbf597fc7, 0xc6e00bf3, 0xd5a79147, 0x06ca6351, 0x14292967,
        0x27b70a85, 0x2e1b2138, 0x4d2c6dfc, 0x53380d13, 0x650a7354, 0x766a0abb, 0x81c2c92e, 0x92722c85,
        0xa2bfe8a1, 0xa81a664b, 0xc24b8b70, 0xc76c51a3, 0xd192e819, 0xd6990624, 0xf40e3585, 0x106aa070,
        0x19a4c116, 0x1e376c08, 0x2748774c, 0x34b0bcb5, 0x391c0cb3, 0x4ed8aa4a, 0x5b9cca4f, 0x682e6ff3,
        0x748f82ee, 0x78a5636f, 0x84c87814, 0x8cc70208, 0x90befffa, 0xa4506ceb, 0xbef9a3f7, 0xc67178f2
    ];

    function ror(x, n) { return (x >>> n) | (x << (32 - n)); }

    function sha256Bytes(bytes) {
        var H = [0x6a09e667, 0xbb67ae85, 0x3c6ef372, 0xa54ff53a,
                 0x510e527f, 0x9b05688c, 0x1f83d9ab, 0x5be0cd19];
        var msg = bytes.slice ? bytes.slice(0) : bytes.concat([]);
        var l = msg.length * 8;
        msg.push(0x80);
        while (msg.length % 64 !== 56) { msg.push(0); }
        // 64-bit big-endian length（高位按 0 处理，安全够用）
        msg.push(0, 0, 0, 0,
            (l >>> 24) & 0xFF, (l >>> 16) & 0xFF, (l >>> 8) & 0xFF, l & 0xFF);

        var w = [], i, j, a, b, c, d, e, f, g, h, s0, s1, ch, maj, t1, t2;
        for (i = 0; i < msg.length; i += 64) {
            for (j = 0; j < 16; j++) {
                w[j] = (msg[i + j * 4] << 24) | (msg[i + j * 4 + 1] << 16) |
                       (msg[i + j * 4 + 2] << 8) | msg[i + j * 4 + 3];
            }
            for (j = 16; j < 64; j++) {
                s0 = ror(w[j - 15], 7) ^ ror(w[j - 15], 18) ^ (w[j - 15] >>> 3);
                s1 = ror(w[j - 2], 17) ^ ror(w[j - 2], 19) ^ (w[j - 2] >>> 10);
                w[j] = (w[j - 16] + s0 + w[j - 7] + s1) | 0;
            }
            a = H[0]; b = H[1]; c = H[2]; d = H[3];
            e = H[4]; f = H[5]; g = H[6]; h = H[7];
            for (j = 0; j < 64; j++) {
                s1 = ror(e, 6) ^ ror(e, 11) ^ ror(e, 25);
                ch = (e & f) ^ ((~e) & g);
                t1 = (h + s1 + ch + K[j] + w[j]) | 0;
                s0 = ror(a, 2) ^ ror(a, 13) ^ ror(a, 22);
                maj = (a & b) ^ (a & c) ^ (b & c);
                t2 = (s0 + maj) | 0;
                h = g; g = f; f = e; e = (d + t1) | 0;
                d = c; c = b; b = a; a = (t1 + t2) | 0;
            }
            H[0] = (H[0] + a) | 0; H[1] = (H[1] + b) | 0;
            H[2] = (H[2] + c) | 0; H[3] = (H[3] + d) | 0;
            H[4] = (H[4] + e) | 0; H[5] = (H[5] + f) | 0;
            H[6] = (H[6] + g) | 0; H[7] = (H[7] + h) | 0;
        }
        var out = [];
        for (i = 0; i < 8; i++) {
            out.push((H[i] >>> 24) & 0xFF, (H[i] >>> 16) & 0xFF, (H[i] >>> 8) & 0xFF, H[i] & 0xFF);
        }
        return out;
    }

    function sha256Hex(str) { return bytesToHex(sha256Bytes(utf8Bytes(str))); }
    function sha256Base64(str) { return bytesToBase64(sha256Bytes(utf8Bytes(str))); }

    function hmacSha256(keyBytes, msgBytes) {
        var block = [], i, k = keyBytes.slice ? keyBytes.slice(0) : keyBytes.concat([]);
        if (k.length > 64) { k = sha256Bytes(k); }
        for (i = 0; i < 64; i++) { block.push(i < k.length ? k[i] : 0); }
        var ipad = [], opad = [];
        for (i = 0; i < 64; i++) {
            ipad.push(block[i] ^ 0x36);
            opad.push(block[i] ^ 0x5c);
        }
        return sha256Bytes(opad.concat(sha256Bytes(ipad.concat(msgBytes))));
    }

    function hmacHex(keyStr, msgStr) {
        return bytesToHex(hmacSha256(utf8Bytes(keyStr), utf8Bytes(msgStr)));
    }

    /* ---------------- CTR 流加密（SHA-256 计数器模式） ---------------- */

    function ctrCrypt(keyStr, dataBytes, nonceHex) {
        var key = utf8Bytes(keyStr);
        var nonce = hexToBytes(nonceHex || "0000000000000000");
        var out = [], ctr = 0, block, i, off;
        while (out.length < dataBytes.length) {
            block = sha256Bytes(key.concat(nonce, [
                (ctr >>> 24) & 0xFF, (ctr >>> 16) & 0xFF, (ctr >>> 8) & 0xFF, ctr & 0xFF
            ]));
            for (i = 0; i < block.length && out.length < dataBytes.length; i++) {
                off = out.length;
                out.push(dataBytes[off] ^ block[i]);
            }
            ctr++;
        }
        return out;
    }

    /* v2 流加密：一次 SHA-256 派生密钥 + RC4（纯字节运算）。
     * ExtendScript 里 42 KB 约几百毫秒，而 v1 的 SHA-CTR 要 30 秒以上。 */
    function rc4Crypt(keyBytes, dataBytes) {
        var S = [], i, j = 0, tmp, out = [], klen = keyBytes.length, a = 0, b = 0, k;
        for (i = 0; i < 256; i++) { S[i] = i; }
        for (i = 0; i < 256; i++) {
            j = (j + S[i] + (keyBytes[i % klen] & 0xFF)) & 0xFF;
            tmp = S[i]; S[i] = S[j]; S[j] = tmp;
        }
        for (i = 0; i < dataBytes.length; i++) {
            a = (a + 1) & 0xFF;
            b = (b + S[a]) & 0xFF;
            tmp = S[a]; S[a] = S[b]; S[b] = tmp;
            k = S[(S[a] + S[b]) & 0xFF];
            out.push((dataBytes[i] ^ k) & 0xFF);
        }
        return out;
    }

    /* 32 字节折叠：任何位置的改动都会改变结果，代价是一次 O(n) 遍历。
     * 强度低于全长 HMAC，但足以发现被改过的规格文件。 */
    function fold32(bytes) {
        var acc = [], i;
        for (i = 0; i < 32; i++) { acc[i] = 0; }
        for (i = 0; i < bytes.length; i++) { acc[i & 31] ^= bytes[i]; }
        return acc;
    }

    function payloadTag(keyStr, ctBytes, nonceHex) {
        var probe = fold32(ctBytes).concat(hexToBytes(nonceHex));
        var n = ctBytes.length;
        probe.push((n >>> 24) & 0xFF, (n >>> 16) & 0xFF, (n >>> 8) & 0xFF, n & 0xFF);
        return bytesToHex(hmacSha256(utf8Bytes(keyStr + "|tag"), probe)).substring(0, 32);
    }

    var nonceCounter = 0;
    /* 8 字节随机 nonce：同一把 key 加密两次不能得到相同 keystream，
     * 否则两份密文异或就等于两份明文异或（CTR 复用）。 */
    function randomNonceHex() {
        nonceCounter = (nonceCounter + 1) & 0xFFFF;
        var seed = "nonce|" + (new Date().getTime()) + "|" + nonceCounter + "|" +
            Math.random() + "|" + Math.random();
        var h = sha256Hex(seed);
        return h.substring(0, 16);
    }

    function encryptPayload(keyStr, plainStr) {
        var nonce = randomNonceHex();
        var bin = utf8ToBin(plainStr);
        var ctBin = xorStream(keyStr, nonce, bin);
        return {
            v: CORE_VERSION,
            nonce: nonce,
            tag: binDigest(keyStr, ctBin, nonce),
            ct: binToHex(ctBin)
        };
    }

    /* ---------------- v2 快速路径：用「二进制字符串」代替数组 ----------------
     * ExtendScript 里 42k 元素数组的 push/下标读取要 1.5–2 秒，
     * 而分块 String.fromCharCode + charCodeAt 只要 20–100 毫秒（实测差 50–100 倍）。
     *  quindi：解密热路径全部走二进制字符串，数组版保留给 Node/旧接口。 */
    function hexToBin(hex) {
        var tab = hexValTable(), s = String(hex), n = s.length, i, c1, c2, chunk = [], out = [];
        for (i = 0; i + 1 < n; i += 2) {
            c1 = tab[s.charCodeAt(i)]; c2 = tab[s.charCodeAt(i + 1)];
            if (c1 < 0 || c2 < 0) { continue; }
            chunk.push((c1 << 4) | c2);
            if (chunk.length >= 256) { out.push(codesToStr(chunk)); chunk = []; }
        }
        if (chunk.length) { out.push(codesToStr(chunk)); }
        return out.join("");
    }

    function binToHex(bin) {
        var out = [], chunk = [], n = bin.length, i, b;
        for (i = 0; i < n; i++) {
            b = bin.charCodeAt(i) & 0xFF;
            chunk.push(HEX_TAB.charAt(b >> 4), HEX_TAB.charAt(b & 15));
            if (chunk.length >= 4096) { out.push(chunk.join("")); chunk = []; }
        }
        if (chunk.length) { out.push(chunk.join("")); }
        return out.join("");
    }

    function rc4CryptBin(keyBytes, bin) {
        var S = [], i, j = 0, tmp, klen = keyBytes.length, n = bin.length;
        for (i = 0; i < 256; i++) { S[i] = i; }
        for (i = 0; i < 256; i++) {
            j = (j + S[i] + (keyBytes[i % klen] & 0xFF)) & 0xFF;
            tmp = S[i]; S[i] = S[j]; S[j] = tmp;
        }
        var a = 0, b = 0, chunk = [], out = [];
        for (i = 0; i < n; i++) {
            a = (a + 1) & 0xFF;
            b = (b + S[a]) & 0xFF;
            tmp = S[a]; S[a] = S[b]; S[b] = tmp;
            chunk.push((bin.charCodeAt(i) ^ S[(S[a] + S[b]) & 0xFF]) & 0xFF);
            if (chunk.length >= 256) { out.push(codesToStr(chunk)); chunk = []; }
        }
        if (chunk.length) { out.push(codesToStr(chunk)); }
        return out.join("");
    }

    function fold32Bin(bin) {
        var acc = [], i, n = bin.length;
        for (i = 0; i < 32; i++) { acc[i] = 0; }
        for (i = 0; i < n; i++) { acc[i & 31] ^= bin.charCodeAt(i) & 0xFF; }
        return acc;
    }

    function payloadTagBin(keyStr, bin, nonceHex) {
        var probe = fold32Bin(bin).concat(hexToBytes(nonceHex));
        var n = bin.length;
        probe.push((n >>> 24) & 0xFF, (n >>> 16) & 0xFF, (n >>> 8) & 0xFF, n & 0xFF);
        return bytesToHex(hmacSha256(utf8Bytes(keyStr + "|tag"), probe)).substring(0, 32);
    }

    function utf8DecodeBin(bin) {
        var parts = [], chunk = [], i = 0, b, cp, c1, c2, c3, n = bin.length;
        while (i < n) {
            b = bin.charCodeAt(i++) & 0xFF;
            if (b < 0x80) { chunk.push(b); }
            else if (b >= 0xC0 && b < 0xE0) {
                c1 = bin.charCodeAt(i++) & 0xFF;
                if (i > n || (c1 & 0xC0) !== 0x80) { throw new Error("bad utf8 (2-byte)"); }
                chunk.push(((b & 0x1F) << 6) | (c1 & 0x3F));
            } else if (b >= 0xE0 && b < 0xF0) {
                c1 = bin.charCodeAt(i++) & 0xFF; c2 = bin.charCodeAt(i++) & 0xFF;
                if ((c1 & 0xC0) !== 0x80 || (c2 & 0xC0) !== 0x80) { throw new Error("bad utf8 (3-byte)"); }
                chunk.push(((b & 0x0F) << 12) | ((c1 & 0x3F) << 6) | (c2 & 0x3F));
            } else if (b >= 0xF0 && b < 0xF8) {
                c1 = bin.charCodeAt(i++) & 0xFF; c2 = bin.charCodeAt(i++) & 0xFF; c3 = bin.charCodeAt(i++) & 0xFF;
                if ((c1 & 0xC0) !== 0x80 || (c2 & 0xC0) !== 0x80 || (c3 & 0xC0) !== 0x80) { throw new Error("bad utf8 (4-byte)"); }
                cp = ((b & 0x07) << 18) | ((c1 & 0x3F) << 12) | ((c2 & 0x3F) << 6) | (c3 & 0x3F);
                cp -= 0x10000;
                chunk.push(0xD800 + (cp >> 10), 0xDC00 + (cp & 0x3FF));
            } else { throw new Error("bad utf8 lead byte"); }
            if (chunk.length >= 256) { parts.push(codesToStr(chunk)); chunk = []; }
        }
        if (chunk.length) { parts.push(codesToStr(chunk)); }
        return parts.join("");
    }

    /* ---------------- v2 快速流：整数 xorshift（不碰数组） ----------------
     * RC4 每字节要做 6 次 256 项数组访问，在 ExtendScript 里 42 KB 要 10 秒；
     * 这里用 SHA-256 派生种子 + xorshift128 整数运算，每字节只有几次位运算，
     * 42 KB 约 0.2–0.5 秒。强度低于正规流密码，定位与 RC4 相同：提高改造成本。 */
    function utf8ToBin(str) {
        return codesToStr(utf8Bytes(str));
    }

    function seedWords(keyStr, nonceHex) {
        var kb = sha256Bytes(utf8Bytes(keyStr + "|" + nonceHex));
        var s = [];
        for (var i = 0; i < 4; i++) {
            s.push(((kb[i * 4] << 24) | (kb[i * 4 + 1] << 16) | (kb[i * 4 + 2] << 8) | kb[i * 4 + 3]) | 0);
        }
        // 避免全零状态（xorshift 会卡死在 0）
        if ((s[0] | s[1] | s[2] | s[3]) === 0) { s[0] = 0x12345678; }
        return s;
    }

    function xorStream(keyStr, nonceHex, bin) {
        var s = seedWords(keyStr, nonceHex);
        var s0 = s[0], s1 = s[1], s2 = s[2], s3 = s[3];
        var n = bin.length, i, chunk = [], out = [], t;
        for (i = 0; i < n; i += 4) {
            t = (s0 ^ (s0 << 11)) | 0; s0 = s1; s1 = s2; s2 = s3;
            s3 = (s3 ^ (s3 >>> 19)) ^ (t ^ (t >>> 8)); s3 = s3 | 0;
            chunk.push(((bin.charCodeAt(i) & 0xFF) ^ (s3 & 0xFF)) & 0xFF);
            if (i + 1 < n) { chunk.push(((bin.charCodeAt(i + 1) & 0xFF) ^ ((s3 >>> 8) & 0xFF)) & 0xFF); }
            if (i + 2 < n) { chunk.push(((bin.charCodeAt(i + 2) & 0xFF) ^ ((s3 >>> 16) & 0xFF)) & 0xFF); }
            if (i + 3 < n) { chunk.push(((bin.charCodeAt(i + 3) & 0xFF) ^ ((s3 >>> 24) & 0xFF)) & 0xFF); }
            if (chunk.length >= 256) { out.push(codesToStr(chunk)); chunk = []; }
        }
        if (chunk.length) { out.push(codesToStr(chunk)); }
        return out.join("");
    }

    /* 轻量完整性校验：FNV 风格的双 32 位滚动，纯整数运算。
     * 任何位置改动都会改变结果；强度足够发现「手改规格」，不等于密码学 MAC。 */
    function binDigest(keyStr, bin, nonceHex) {
        var h1 = 0x811c9dc5, h2 = 0x01000193, i, c, n = bin.length;
        for (i = 0; i < n; i++) {
            c = bin.charCodeAt(i) & 0xFF;
            h1 = ((h1 ^ c) * 16777619) | 0;
            h1 = ((h1 << 13) | (h1 >>> 19)) | 0;
            h2 = ((h2 + ((c + 1) * 2654435761)) | 0);
            h2 = ((h2 << 7) | (h2 >>> 25)) | 0;
        }
        var probe = [h1 & 0xFF, (h1 >>> 8) & 0xFF, (h1 >>> 16) & 0xFF, (h1 >>> 24) & 0xFF,
                     h2 & 0xFF, (h2 >>> 8) & 0xFF, (h2 >>> 16) & 0xFF, (h2 >>> 24) & 0xFF,
                     (n >>> 24) & 0xFF, (n >>> 16) & 0xFF, (n >>> 8) & 0xFF, n & 0xFF]
            .concat(hexToBytes(nonceHex).slice(0, 8));
        return bytesToHex(hmacSha256(utf8Bytes(keyStr + "|tag"), probe)).substring(0, 32);
    }

    function decryptPayload(keyStr, box) {
        if (!box || !box.ct || !box.nonce) { throw new Error("bad payload"); }
        var ver = (box.v === undefined) ? LEGACY_VERSION : Number(box.v);
        if (ver !== CORE_VERSION && ver !== LEGACY_VERSION) {
            throw new Error("payload version mismatch: " + box.v);
        }
        if (ver === LEGACY_VERSION) {
            // 旧包（SHA-CTR）：只解密，不再生成；保留兼容是为了已发出的 dist 仍能升级
            // 注意：数组版 hexToBytes 很慢，只在走旧格式时才转换
            var ct = hexToBytes(box.ct);
            var oldTag = bytesToHex(hmacSha256(utf8Bytes(keyStr + "|tag"), ct)).substring(0, 32);
            if (oldTag !== box.tag) { throw new Error("payload tag mismatch (v1)"); }
            return utf8Decode(ctrCrypt(keyStr, ct, box.nonce));
        }
        var bin = hexToBin(box.ct);
        if (binDigest(keyStr, bin, box.nonce) !== box.tag) { throw new Error("payload tag mismatch"); }
        return utf8DecodeBin(xorStream(keyStr, box.nonce, bin));
    }

    /* 严格 UTF-8 解码：遇到截断/非法续字节直接抛错，
     * 避免「解密成功但内容是乱码」这种难定位的故障。 */
    function utf8Decode(bytes) {
        var parts = [], buf = [], i = 0, b, cp, c1, c2, c3;
        while (i < bytes.length) {
            b = bytes[i++];
            if (b < 0x80) {
                buf.push(b);
            } else if (b >= 0xC0 && b < 0xE0) {
                c1 = bytes[i++];
                if (c1 === undefined || (c1 & 0xC0) !== 0x80) { throw new Error("bad utf8 (2-byte) at " + (i - 1)); }
                buf.push(((b & 0x1F) << 6) | (c1 & 0x3F));
            } else if (b >= 0xE0 && b < 0xF0) {
                c1 = bytes[i++]; c2 = bytes[i++];
                if (c1 === undefined || c2 === undefined ||
                    (c1 & 0xC0) !== 0x80 || (c2 & 0xC0) !== 0x80) { throw new Error("bad utf8 (3-byte) at " + (i - 2)); }
                cp = ((b & 0x0F) << 12) | ((c1 & 0x3F) << 6) | (c2 & 0x3F);
                buf.push(cp);
            } else if (b >= 0xF0 && b < 0xF8) {
                c1 = bytes[i++]; c2 = bytes[i++]; c3 = bytes[i++];
                if (c1 === undefined || c2 === undefined || c3 === undefined ||
                    (c1 & 0xC0) !== 0x80 || (c2 & 0xC0) !== 0x80 || (c3 & 0xC0) !== 0x80) {
                    throw new Error("bad utf8 (4-byte) at " + (i - 3));
                }
                cp = ((b & 0x07) << 18) | ((c1 & 0x3F) << 12) | ((c2 & 0x3F) << 6) | (c3 & 0x3F);
                cp -= 0x10000;
                buf.push(0xD800 + (cp >> 10), 0xDC00 + (cp & 0x3FF));
            } else {
                throw new Error("bad utf8 lead byte 0x" + b.toString(16) + " at " + (i - 1));
            }
            if (buf.length >= 256) { parts.push(codesToStr(buf)); buf = []; }
        }
        if (buf.length) { parts.push(codesToStr(buf)); }
        return parts.join("");
    }

    /* ---------------- 规范化 JSON（键排序，供签名） ---------------- */

    function canonical(obj) {
        if (obj === null || typeof obj !== "object") { return JSON.stringify(obj); }
        if (obj instanceof Array) {
            var parts = [];
            for (var i = 0; i < obj.length; i++) { parts.push(canonical(obj[i])); }
            return "[" + parts.join(",") + "]";
        }
        var keys = [], k;
        for (k in obj) { if (Object.prototype.hasOwnProperty.call(obj, k)) { keys.push(k); } }
        keys.sort();
        var out = [];
        for (var j = 0; j < keys.length; j++) {
            out.push(JSON.stringify(keys[j]) + ":" + canonical(obj[keys[j]]));
        }
        return "{" + out.join(",") + "}";
    }

    /* ---------------- 授权令牌（面板 → JSX） ---------------- */

    function issueToken(claims) {
        var payload = {
            v: CORE_VERSION,
            product: PRODUCT,
            plan: claims.plan || "none",
            ents: claims.ents || [],
            exp: claims.exp || null,
            fp: claims.fp || "",
            specKey: claims.specKey || "",
            iat: claims.iat || 0
        };
        payload.mac = hmacHex(GATE_KEY, canonical(payload));
        return payload;
    }

    function verifyToken(token, ownFp, nowMs) {
        if (!token || typeof token !== "object") { return { ok: false, reason: "no-token" }; }
        var mac = token.mac;
        var probe = {};
        for (var k in token) {
            if (Object.prototype.hasOwnProperty.call(token, k) && k !== "mac") { probe[k] = token[k]; }
        }
        if (hmacHex(GATE_KEY, canonical(probe)) !== mac) { return { ok: false, reason: "bad-mac" }; }
        if (token.product !== PRODUCT) { return { ok: false, reason: "wrong-product" }; }
        // 指纹必须双方都存在且一致：空指纹一律视为无效（否则删掉 fp 字段就能绕过机器绑定）
        if (!token.fp || !ownFp) { return { ok: false, reason: "no-fingerprint" }; }
        if (token.fp !== ownFp) { return { ok: false, reason: "machine-mismatch" }; }
        // 过期时间必须存在且可解析：缺失 = 永不过期是 fail-open
        if (!token.exp) { return { ok: false, reason: "no-expiry" }; }
        var expMs = parseIsoMs(token.exp);
        if (isNaN(expMs)) { return { ok: false, reason: "bad-expiry" }; }
        if (nowMs > expMs) { return { ok: false, reason: "expired" }; }
        return { ok: true, plan: token.plan, ents: token.ents || [], specKey: token.specKey || "" };
    }

    function hasEnt(ents, name) {
        if (!ents) { return false; }
        for (var i = 0; i < ents.length; i++) { if (ents[i] === name) { return true; } }
        return false;
    }

    /* ---------------- 时间解析 ----------------
     * ExtendScript（ES3）的 Date.parse 解析 ISO 8601 会给出错误结果
     * （实测 '2027-01-01T00:00:00Z' → 1906 年），所以许可证/令牌的到期判断
     * 一律走这里，用 Date.UTC 自己算，浏览器与 AE 结果一致。 */
    function parseIsoMs(s) {
        if (s === null || s === undefined || s === "") { return NaN; }
        if (typeof s === "number") { return s; }
        var m = String(s).match(/^(\d{4})-(\d{2})-(\d{2})(?:[T ](\d{2}):(\d{2})(?::(\d{2})(?:\.(\d{1,3}))?)?)?\s*(Z|[+-]\d{2}:?\d{2})?$/);
        if (!m) { return NaN; }
        var y = Number(m[1]), mo = Number(m[2]) - 1, d = Number(m[3]);
        var h = m[4] ? Number(m[4]) : 0, mi = m[5] ? Number(m[5]) : 0;
        var se = m[6] ? Number(m[6]) : 0;
        var ms = 0;
        if (m[7]) { ms = Number((m[7] + "00").substring(0, 3)); }
        var t = Date.UTC(y, mo, d, h, mi, se, ms);
        if (isNaN(t)) { return NaN; }
        var off = m[8];
        if (off && off !== "Z") {
            var sign = off.charAt(0) === "-" ? -1 : 1;
            var oh = Number(off.substring(1, 3));
            var om = Number(off.substring(4, 6)) || 0;
            t -= sign * (oh * 60 + om) * 60000;
        }
        return t;
    }

    function toIsoMs(ms) {
        var d = new Date(ms);
        function p2(n) { return (n < 10 ? "0" : "") + n; }
        return d.getUTCFullYear() + "-" + p2(d.getUTCMonth() + 1) + "-" + p2(d.getUTCDate()) +
            "T" + p2(d.getUTCHours()) + ":" + p2(d.getUTCMinutes()) + ":" + p2(d.getUTCSeconds()) + "Z";
    }


    /** 由原始机器标识（如 BIOS UUID）派生可展示的机器码。 */
    /* ---------------- 机器码 ---------------- */

    /** 由原始机器标识（如 BIOS UUID）派生可展示的机器码。 */
    function machineCode(rawId, salt) {
        var norm = String(rawId || "").replace(/[^0-9a-zA-Z]/g, "").toLowerCase();
        var h = sha256Hex("fp|" + (salt || PRODUCT) + "|" + norm);
        return (h.substring(0, 4) + "-" + h.substring(4, 8) + "-" +
                h.substring(8, 12) + "-" + h.substring(12, 16)).toUpperCase();
    }

    /** 与 machineCode 同源的 16 位指纹（令牌里比对用） */
    function fp16(rawId, salt) {
        return machineCode(rawId, salt).replace(/-/g, "");
    }

    /** 许可证签名后的 spec 解密密钥 */
    function specKeyFromLicense(sigB64) {
        return sha256Hex("spec|" + String(sigB64 || "").replace(/[^A-Za-z0-9+\/=]/g, ""));
    }

    return {
        PRODUCT: PRODUCT,
        CORE_VERSION: CORE_VERSION,
        FREE_TYPE_IDS: FREE_TYPE_IDS,
        GATE_KEY: GATE_KEY,
        utf8Bytes: utf8Bytes,
        utf8Decode: utf8Decode,
        bytesToHex: bytesToHex,
        hexToBytes: hexToBytes,
        bytesToBase64: bytesToBase64,
        base64ToBytes: base64ToBytes,
        sha256Bytes: sha256Bytes,
        sha256Hex: sha256Hex,
        sha256Base64: sha256Base64,
        hmacSha256: hmacSha256,
        hmacHex: hmacHex,
        ctrCrypt: ctrCrypt,
        hexToBin: hexToBin,
        binToHex: binToHex,
        xorStream: xorStream,
        binDigest: binDigest,
        utf8DecodeBin: utf8DecodeBin,
        codesToStr: codesToStr,
        rc4Crypt: rc4Crypt,
        fold32: fold32,
        encryptPayload: encryptPayload,
        decryptPayload: decryptPayload,
        canonical: canonical,
        issueToken: issueToken,
        verifyToken: verifyToken,
        hasEnt: hasEnt,
        machineCode: machineCode,
        fp16: fp16,
        specKeyFromLicense: specKeyFromLicense,
        parseIsoMs: parseIsoMs,
        toIsoMs: toIsoMs
    };
});










