/**
 * format_core.js —— 数据 + 单位 纯逻辑内核（UMD，Node + ExtendScript 共用）
 * © 2026 CGArtLab · https://cgartlab.com · CGArtLab FUI Data
 * ------------------------------------------------------------------
 * 无 DOM / 无 AE API；只做「解析 / 换算 / 格式化 / 检测」。
 * 统一写法：ES3 安全（仅 var、无箭头、无模板串），便于被 AE 脚本 $.evalFile 载入。
 *
 * 对外 API（挂到 globalThis.FUIFormatCore / module.exports）：
 *   REGISTRY, getType(id), listTypes()
 *   parseNumberText(text) -> {isNumeric,value,unit,prefix,suffix,negative,raw,unitType}
 *   convert(value, unit, toUnit?)           // unit/toUnit 可为单位描述对象或单位 id
 *   formatValue(value, spec) -> string      // value 以 spec.baseUnit 计
 *   rmbUppercase(n) -> string
 *   timecode(sec, spec?) -> string
 *   dms(deg, spec?) -> string
 *   detectParse(text) -> {isNumeric,value,unit,suggestedType,prefix,suffix}
 *   evaluateThresholds(value, spec) -> 'ok'|'warn'|'crit'
 *   expressionBundle() -> string            // 供 AE 表达式内联使用的自包含格式化源码
 */
(function (root, factory) {
    if (typeof module === "object" && module && module.exports) {
        module.exports = factory();
    } else {
        root.FUIFormatCore = factory();
    }
})((typeof globalThis !== "undefined") ? globalThis :
    ((typeof self !== "undefined") ? self :
        ((typeof window !== "undefined") ? window :
            ((typeof $ !== "undefined" && $.global) ? $.global : this))), function () {

    "use strict";

    /* ---------------- 通用小工具 ---------------- */
    function numOr(v, d) {
        var n = Number(v);
        return isNaN(n) ? d : n;
    }

    function groupThousands(intStr, sep) {
        sep = sep || ",";
        var out = "";
        var cnt = 0;
        for (var i = intStr.length - 1; i >= 0; i--) {
            out = intStr.charAt(i) + out;
            cnt++;
            if (cnt % 3 === 0 && i > 0) { out = sep + out; }
        }
        return out;
    }

    function repeatZero(n) {
        var s = "";
        for (var i = 0; i < n; i++) { s += "0"; }
        return s;
    }

    function pad2(n) { return (n < 10) ? ("0" + n) : ("" + n); }
    function pad3(n) { return (n < 10) ? ("00" + n) : ((n < 100) ? ("0" + n) : ("" + n)); }

    function trimNum(x, dec) {
        if (dec === undefined || dec === null) { dec = 2; }
        var s = Number(x).toFixed(dec);
        if (s.indexOf(".") >= 0) {
            s = s.replace(/0+$/, "");
            s = s.replace(/\.$/, "");
        }
        return s;
    }

    /* ---------------- 数字格式化（含符号/千分位/小数） ---------------- */
    function fmtNumber(v, dec, thousands, pad, decChar) {
        dec = (dec === undefined || dec === null) ? 0 : Math.round(Number(dec));
        if (isNaN(dec) || dec < 0) { dec = 0; }
        if (dec > 100) { dec = 100; }   // 防 toFixed 越界
        var neg = (v < 0);
        var av = Math.abs(v);
        if (!isFinite(av)) { av = 0; neg = false; }
        var p = Math.pow(10, dec);
        av = Math.round(av * p + 1e-9 * Math.max(1, p)) / p;   // 稳定四舍五入（按小数位缩放 epsilon，修正 31.219999 类误差）
        if (av === 0) { neg = false; }         // 避免 -0.00
        var s = av.toFixed(dec);
        var dot = s.indexOf(".");
        var intPart = (dot < 0) ? s : s.substring(0, dot);
        var fracPart = (dot < 0) ? "" : s.substring(dot + 1);
        var pd = (pad === undefined || pad === null) ? 0 : Math.round(Number(pad));
        if (isNaN(pd) || pd < 0) { pd = 0; }
        if (pd > 100) { pd = 100; }   // 防超长补零卡顿
        if (pd > 0) { while (intPart.length < pd) { intPart = "0" + intPart; } }
        if (thousands && !(pd > 0)) {
            var sep = (decChar !== undefined && decChar !== null && /[，,]/.test(String(decChar))) ? " " : ",";
            intPart = groupThousands(intPart, sep);
        }
        var out = (neg ? "-" : "") + intPart;
        if (dec > 0) {
            if (fracPart.length === 0) { fracPart = repeatZero(dec); }
            var dc = (decChar === undefined || decChar === null || decChar === "") ? "." : String(decChar);
            out += dc + fracPart;
        }
        return out;
    }

    /* ---------------- 单位解析 ---------------- */
    function resolveUnit(spec) {
        if (!spec) { return null; }
        var units = spec.units || [];
        if (units.length === 0) { return null; }
        var sel = spec.unit;
        if (sel) {
            if (typeof sel === "object") { return sel; }
            for (var i = 0; i < units.length; i++) {
                if (units[i].id === sel || units[i].label === sel) { return units[i]; }
            }
            // 兼容旧工程：微符号曾用希腊 μ（U+03BC），注册表已统一为 µ（U+00B5）
            var norm = function (x) { return String(x || "").replace(/\u03BC/g, "\u00B5"); };
            var selN = norm(sel);
            for (var j = 0; j < units.length; j++) {
                if (norm(units[j].id) === selN || norm(units[j].label) === selN) { return units[j]; }
            }
        }
        return units[0];
    }

    function convertDisplay(v, unit, spec) {
        if (!unit) { return v; }
        var factor = (unit.factor === undefined) ? 1 : numOr(unit.factor, 1);
        var offset = (unit.offset === undefined) ? 0 : numOr(unit.offset, 0);
        // 货币固定汇率：rate = 1 目标货币 折合多少基准货币（如 USD→CNY≈7.2），故除以 rate
        if (spec && spec.rate !== undefined && spec.rate !== null &&
            unit.id !== spec.baseUnit) {
            var r = numOr(spec.rate, 0);
            if (r) { return v / r; }
        }
        return v * factor + offset;
    }

    function findUnitById(id) {
        for (var t in REGISTRY) {
            if (REGISTRY.hasOwnProperty(t)) {
                var units = REGISTRY[t].units || [];
                for (var i = 0; i < units.length; i++) {
                    if (units[i].id === id) { return units[i]; }
                }
            }
        }
        return null;
    }

    /* ---------------- convert ---------------- */
    /* convert(value, unit)        : base -> display（unit 为描述对象或单位 id）
       convert(value, from, to)    : 单位间换算（均需可解析到描述对象或 id） */
    function convert(value, unit, toUnit) {
        var v = numOr(value, 0);
        function asDesc(u) {
            if (u && typeof u === "object") { return u; }
            if (typeof u === "string") { return findUnitById(u); }
            return null;
        }
        if (toUnit === undefined) {
            var d = asDesc(unit);
            if (!d) { return v; }
            return v * numOr(d.factor, 1) + numOr(d.offset, 0);
        }
        var f = asDesc(unit);
        var t = asDesc(toUnit);
        if (!f || !t) { return v; }
        var base = (v - numOr(f.offset, 0)) / numOr(f.factor, 1);
        return base * numOr(t.factor, 1) + numOr(t.offset, 0);
    }

    /* ---------------- 人民币中文大写 ---------------- */
    function rmbUppercase(n) {
        var v = Number(n);
        if (isNaN(v)) { return ""; }
        var head = (v < 0) ? "负" : "";
        var fenTotal = Math.round(Math.abs(v) * 100);
        if (fenTotal === 0) { return "零元整"; }
        var digit = ["零", "壹", "贰", "叁", "肆", "伍", "陆", "柒", "捌", "玖"];
        var unitSmall = ["", "拾", "佰", "仟"];
        var unitBig = ["", "万", "亿", "万亿"];

        function groupToChinese(g) {
            var d = [g % 10, Math.floor(g / 10) % 10, Math.floor(g / 100) % 10, Math.floor(g / 1000) % 10];
            var out = "";
            var zero = false;
            for (var i = 3; i >= 0; i--) {
                if (d[i] === 0) { zero = true; }
                else {
                    if (zero && out !== "") { out += digit[0]; }
                    zero = false;
                    out += digit[d[i]] + unitSmall[i];
                }
            }
            return out;
        }

        function intToChinese(num) {
            if (num === 0) { return ""; }
            var groups = [];
            var x = num;
            while (x > 0) { groups.push(x % 10000); x = Math.floor(x / 10000); }
            var out = "";
            for (var gi = groups.length - 1; gi >= 0; gi--) {
                var g = groups[gi];
                var gs = groupToChinese(g);
                if (gs === "") {
                    if (out !== "" && !/零$/.test(out)) { out += "零"; }
                } else {
                    if (out !== "" && g < 1000 && !/零$/.test(out)) { out += "零"; }
                    out += gs + unitBig[gi];
                }
            }
            out = out.replace(/零+$/, "");
            return out;
        }

        var yuan = Math.floor(fenTotal / 100);
        var jiao = Math.floor((fenTotal % 100) / 10);
        var fen = fenTotal % 10;

        var intStr = (yuan === 0) ? "" : (intToChinese(yuan) + "元");

        var s = "";
        if (jiao === 0 && fen === 0) {
            s = (yuan === 0) ? "零元整" : "整";
        } else {
            if (jiao > 0) { s += digit[jiao] + "角"; }
            else if (fen > 0 && yuan > 0) { s += "零"; }
            if (fen > 0) { s += digit[fen] + "分"; }
        }
        return head + intStr + s;
    }

    /* ---------------- 时间码 ---------------- */
    function timecode(sec, spec) {
        var v = numOr(sec, 0);
        var neg = (v < 0);
        v = Math.abs(v);
        var h = Math.floor(v / 3600);
        var m = Math.floor((v - h * 3600) / 60);
        var s = Math.floor(v - h * 3600 - m * 60);
        var frac = v - Math.floor(v);
        var ms = Math.round(frac * 1000);
        if (ms >= 1000) {
            ms = 0; s += 1;
            if (s >= 60) { s = 0; m += 1; if (m >= 60) { m = 0; h += 1; } }
        }
        var showMs = false;
        if (spec && spec.timerMs === true) { showMs = true; }
        var out = pad2(h) + ":" + pad2(m) + ":" + pad2(s);
        if (showMs) { out += "." + pad3(ms); }
        return (neg ? "-" : "") + out;
    }

    /* ---------------- 度分秒 ---------------- */
    function twoDigitSec(secF) {
        var s = secF.toFixed(2);
        var parts = s.split(".");
        var ip = parts[0]; if (ip.length < 2) { ip = "0" + ip; }
        var fp = parts[1] || "00";
        return ip + "." + fp;
    }

    function dms(deg, spec) {
        var v = numOr(deg, 0);
        var neg = (v < 0);
        v = Math.abs(v);
        var d = Math.floor(v);
        var minF = (v - d) * 60;
        var m = Math.floor(minF);
        var secF = (minF - m) * 60;
        var sStr = twoDigitSec(secF);
        if (Number(sStr) >= 60) {
            sStr = "00.00"; m += 1;
            if (m >= 60) { m = 0; d += 1; }
        }
        var mode = (spec && spec.hemisphere) ? spec.hemisphere : "lat";
        var hemi = "";
        if (mode === "lon") { hemi = neg ? "W" : "E"; }
        else if (mode === "none") { hemi = ""; }
        else { hemi = neg ? "S" : "N"; }
        var sign = (mode === "none" && neg) ? "-" : "";
        return sign + d + "°" + m + "\u2032" + sStr + "\u2033" + hemi;
    }

    /* ---------------- formatValue ---------------- */
    function padSpaces(n) { var s = ""; for (var i = 0; i < n; i++) { s += " "; } return s; }
    /* 单位标签显示：直接输出注册表里的标准符号。
     * 曾经为了「不拥挤」在基字与 ²/³ 之间插入细空格，结果变成 m ² —— 不符合 SI 写法，
     * 复制到别处也不对，这里保持原样（m²、m/s²、kgf/cm²）。 */
    function displayUnitLabel(label) {
        return String(label || "");
    }
    /* 间距以「空格个数」计：单层文本无法精确像素定位，用空格数量近似 */
    function nSpaces(spec, key, def) {
        var d = (def === "space") ? 1 : (Number(def) || 0);
        var v = (spec && spec[key] !== undefined && spec[key] !== null && spec[key] !== "") ? Number(spec[key]) : d;
        if (isNaN(v) || v < 0) { v = d; }
        var n = Math.round(v); if (n > 20) { n = 20; }
        return padSpaces(n);
    }
    function formatValue(value, spec) {
        spec = spec || {};
        var v = numOr(value, 0);
        if (!isFinite(v)) { v = 0; }
        if (spec.allowNegative === false && v < 0) { v = 0; }

        var fmt = spec.format || "number";
        if (fmt === "text") { return (spec.__text !== undefined && spec.__text !== null) ? String(spec.__text) : String(value === null || value === undefined ? "" : value); }

        if (fmt === "rmbUppercase") {
            var rate = (spec.rate !== undefined && spec.rate !== null) ? numOr(spec.rate, 1) : 1;
            return (spec.prefix ? spec.prefix + nSpaces(spec, "prefixSpace", 0) : "") + rmbUppercase(v * rate) + (spec.suffix ? nSpaces(spec, "suffixSpace", 0) + spec.suffix : "");
        }

        if (fmt === "timecode") {
            return (spec.prefix ? spec.prefix + nSpaces(spec, "prefixSpace", 0) : "") + timecode(v, spec) + (spec.suffix ? nSpaces(spec, "suffixSpace", 0) + spec.suffix : "");
        }

        if (fmt === "dms") {
            // 经纬度范围校验：纬度 ±90、经度 ±180（超界钳制）
            var mode0 = (spec && spec.hemisphere) ? spec.hemisphere : "lat";
            if (mode0 === "lat") { if (v > 90) { v = 90; } else if (v < -90) { v = -90; } }
            else if (mode0 === "lon") { if (v > 180) { v = 180; } else if (v < -180) { v = -180; } }
            var du = resolveUnit(spec);
            if (!du || du.id === "dms") {
                return (spec.prefix ? spec.prefix + nSpaces(spec, "prefixSpace", 0) : "") + dms(v, spec) + (spec.suffix ? nSpaces(spec, "suffixSpace", 0) + spec.suffix : "");
            }
            // 否则按十进制度走 number 分支
        }

        // 十进制度(deg)：自动带 N/S/E/W 方向（负值 → S/W），不再显示负号
        var coordHemi = "";
        if (fmt === "dms") {
            var du2 = resolveUnit(spec);
            if (du2 && du2.id === "deg") {
                var mode1 = (spec && spec.hemisphere) ? spec.hemisphere : "lat";
                if (mode1 === "lat" || mode1 === "lon") {
                    if (v < 0) { coordHemi = (mode1 === "lon") ? "W" : "S"; v = Math.abs(v); }
                    else { coordHemi = (mode1 === "lon") ? "E" : "N"; }
                }
            }
        }

        // 范围钳制：按「基准单位」值在换算到显示单位之前钳制（避免如 %→‰ 被 0–100 误钳）
        if (spec.range) {
            var clamp = (spec.range.clamp !== false);
            if (clamp) {
                var rmin = spec.range.min;
                var rmax = spec.range.max;
                // 允许负数时，不再用 min(通常为 0) 下钳，以便表示“减少/降低”
                if (rmin !== undefined && rmin !== null && spec.allowNegative !== true && v < rmin) { v = rmin; }
                if (rmax !== undefined && rmax !== null && v > rmax) { v = rmax; }
            }
        }

        var unit = resolveUnit(spec);
        var disp = convertDisplay(v, unit, spec);

        var dec = (spec.decimals === undefined || spec.decimals === null) ? 0 : spec.decimals;
        var numStr = fmtNumber(disp, dec, !!spec.thousands, spec.padding, spec.decimalChar);

        var sign = "";
        if (disp > 0 && spec.forceSign) { sign = "+"; }

        var label = spec.omitUnit ? "" : (unit ? displayUnitLabel(unit.label || "") : "");
        var place = (unit && unit.place) ? unit.place : "suffix";
        var unitSp = nSpaces(spec, "unitSpace", (unit && unit.space) ? "space" : 0);
        var preSp = nSpaces(spec, "prefixSpace", 0);
        var sufSp = nSpaces(spec, "suffixSpace", 0);
        var core = sign + numStr;
        if (spec.noSign && (core.charAt(0) === "-" || core.charAt(0) === "+")) { core = core.substring(1); }
        var leadSign = "";
        if (core.charAt(0) === "-" || core.charAt(0) === "+") { leadSign = core.charAt(0); core = core.substring(1); }
        var out = "";
        if (spec.prefix) { out += spec.prefix + preSp; }
        if (label && place === "prefix") {
            out += label + unitSp + core;
        } else {
            out += core;
            if (label) { out += unitSp + label; }
        }
        if (coordHemi) { out += coordHemi; }
        if (spec.suffix) { out += sufSp + spec.suffix; }
        // 单位在前（货币符号）时：负号/正号与货币符号的距离 = 货币符号与数字的距离
        var signSp = (label && place === "prefix") ? unitSp : "";
        return leadSign + (leadSign ? signSp : "") + out;
    }

    /* ---------------- 阈值 ---------------- */
    function evaluateThresholds(value, spec) {
        if (!spec || !spec.thresholds) { return "ok"; }
        var v = numOr(value, 0);
        var level = "ok";
        for (var i = 0; i < spec.thresholds.length; i++) {
            var t = spec.thresholds[i];
            var hit = false;
            if (t.op === "lt") { hit = (v < t.value); }
            else if (t.op === "gt") { hit = (v > t.value); }
            else if (t.op === "le") { hit = (v <= t.value); }
            else if (t.op === "ge") { hit = (v >= t.value); }
            if (hit) {
                if (t.level === "crit") { return "crit"; }
                if (t.level === "warn") { level = "warn"; }
            }
        }
        return level;
    }

    /* ---------------- 检测 / 解析 ---------------- */
    var UNIT_TOKENS = [
        ["mmHg", "pressure"], ["hPa", "pressure"], ["kPa", "pressure"], ["psi", "pressure"], ["atm", "pressure"],
        ["bar", "pressure"], ["Pa", "pressure"],
        ["GHz", "frequency"], ["MHz", "frequency"], ["kHz", "frequency"], ["Hz", "frequency"],
        ["mV", "voltage"], ["kV", "voltage"], ["V", "voltage"],
        ["kg", "weight"], ["mg", "weight"], ["lb", "weight"], ["oz", "weight"], ["g", "weight"], ["t", "weight"],
        ["km/h", "speed"], ["km/s", "speed"], ["m/s", "speed"], ["mph", "speed"], ["kn", "speed"],
        ["km²", "area"], ["cm²", "area"], ["m²", "area"], ["ha", "area"], ["ac", "area"],
        ["mL", "volume"], ["m³", "volume"], ["gal", "volume"], ["L", "volume"],
        ["km", "length"], ["cm", "length"], ["mm", "length"], ["µm", "length"], ["μm", "length"], ["m", "length"],
        ["°C", "temperature"], ["℃", "temperature"], ["°F", "temperature"], ["K", "temperature"],
        ["CNY", "currency"], ["USD", "currency"], ["EUR", "currency"], ["GBP", "currency"],
        ["$", "currency"], ["¥", "currency"], ["€", "currency"], ["£", "currency"], ["元", "currency"], ["HK$", "currency"], ["JP¥", "currency"],
        ["斤", "weight"], ["两", "weight"], ["亩", "area"],
        ["%", "percent"], ["‰", "percent"], ["bpm", "heartRate"],
        ["deg", "angle"], ["rad", "angle"], ["度", "angle"], ["grad", "angle"], ["arcmin", "angle"], ["arcsec", "angle"], ["turn", "angle"], ["mil", "angle"], ["°", "angle"],
        ["ms", "timer"], ["s", "timer"],
        ["kW", "power"], ["MW", "power"], ["W", "power"], ["hp", "power"], ["PS", "power"], ["马力", "power"],
        ["kJ", "energy"], ["kcal", "energy"], ["kWh", "energy"], ["Wh", "energy"], ["MJ", "energy"], ["eV", "energy"], ["BTU", "energy"], ["cal", "energy"], ["J", "energy"],
        ["kN", "force"], ["MN", "force"], ["kgf", "force"], ["lbf", "force"], ["dyn", "force"], ["gf", "force"], ["N", "force"],
        ["N·m", "torque"], ["kgf·m", "torque"], ["lbf·ft", "torque"], ["lbf·in", "torque"],
        ["m/s²", "acceleration"], ["ft/s²", "acceleration"], ["Gal", "acceleration"],
        ["mA", "current"], ["µA", "current"], ["kA", "current"], ["MA", "current"], ["A", "current"],
        ["MΩ", "resistance"], ["kΩ", "resistance"], ["mΩ", "resistance"], ["Ω", "resistance"],
        ["µF", "capacitance"], ["nF", "capacitance"], ["pF", "capacitance"], ["mF", "capacitance"], ["F", "capacitance"],
        ["mAh", "charge"], ["Ah", "charge"], ["µAh", "charge"], ["mC", "charge"], ["µC", "charge"], ["C", "charge"],
        ["m³/s", "flow"], ["m³/h", "flow"], ["L/min", "flow"], ["L/s", "flow"], ["GPM", "flow"], ["CFM", "flow"],
        ["kg/m³", "density"], ["g/cm³", "density"], ["lb/ft³", "density"],
        ["mg/L", "concentration"], ["µg/L", "concentration"], ["g/L", "concentration"], ["ppm", "concentration"], ["ppb", "concentration"],
        ["TB", "data"], ["GB", "data"], ["MB", "data"], ["KB", "data"], ["Gbit", "data"], ["Mbit", "data"], ["kbit", "data"], ["bit", "data"], ["B", "data"],
        ["klx", "illuminance"], ["lx", "illuminance"], ["fc", "illuminance"],
        ["mSv", "radiation"], ["µSv", "radiation"], ["mrem", "radiation"], ["rem", "radiation"], ["Sv", "radiation"],
        ["GBq", "radioactivity"], ["MBq", "radioactivity"], ["kBq", "radioactivity"], ["Bq", "radioactivity"], ["Ci", "radioactivity"],
        ["nmi", "length"], ["yd", "length"], ["mi", "length"], ["ft", "length"], ["in", "length"], ["AU", "length"], ["ly", "length"], ["pc", "length"], ["里", "length"], ["尺", "length"], ["寸", "length"],
        ["kgf/cm²", "pressure"], ["Torr", "pressure"], ["inHg", "pressure"], ["MPa", "pressure"],
        ["rpm", "frequency"], ["ft/s", "speed"], ["Mach", "speed"], ["c", "speed"],
        ["DMS", "coordinate"], ["′", "angle"], ["″", "angle"], ["tTNT", "energy"], ["吨TNT", "energy"], ["kg/L", "density"], ["g₀", "acceleration"]
    ];
    // 按 token 长度降序（最长优先，避免 Pa/kPa、Hz/kHz、m/bpm 误判）
    UNIT_TOKENS.sort(function (a, b) { return b[0].length - a[0].length; });

    function matchUnitAtStart(str) {
        for (var i = 0; i < UNIT_TOKENS.length; i++) {
            var tok = UNIT_TOKENS[i][0];
            if (str.indexOf(tok) === 0) {
                var rest = str.substring(tok.length);
                // 字母单位后若紧跟字母（如 m/more、mi/min、in/inch）则不认
                if (/^[A-Za-z]+$/.test(tok) && /^[A-Za-z]/.test(rest)) { continue; }
                return { unit: tok, type: UNIT_TOKENS[i][1] };
            }
        }
        return null;
    }

    function matchUnitAtEnd(str) {
        for (var i = 0; i < UNIT_TOKENS.length; i++) {
            var tok = UNIT_TOKENS[i][0];
            if (str.length >= tok.length && str.substring(str.length - tok.length) === tok) {
                var pre = str.substring(0, str.length - tok.length);
                if (/^[A-Za-z]+$/.test(tok) && pre.length > 0 && /[A-Za-z]$/.test(pre)) { continue; }
                return { unit: tok, type: UNIT_TOKENS[i][1] };
            }
        }
        return null;
    }

    function detectRmbUppercase(text) {
        return /[壹贰叁肆伍陆柒捌玖拾佰仟万亿零元角分整]/.test(text);
    }

    function parseNumberText(text) {
        var res = {
            isNumeric: false, value: null, unit: "", prefix: "", suffix: "",
            negative: false, raw: (text === null || text === undefined) ? "" : String(text), unitType: ""
        };
        if (text === null || text === undefined) { return res; }
        var s = String(text);
        s = s.replace(/−/g, "-"); // 统一负号

        var m = s.match(/[-+]?\d{1,3}(?:,\d{3})+(?:\.\d+)?|[-+]?\d+(?:\.\d+)?/);
        if (!m) { return res; }
        var numStr = m[0];
        var v = parseFloat(numStr.replace(/,/g, ""));
        if (isNaN(v)) { return res; }

        res.isNumeric = true;
        res.value = v;
        res.negative = v < 0;

        var idx = s.indexOf(numStr);
        var before = s.substring(0, idx).replace(/\s+$/, "");
        var after = s.substring(idx + numStr.length).replace(/^\s+/, "");

        // 1) 后缀单位
        var u = matchUnitAtStart(after);
        if (u) {
            res.unit = u.unit;
            res.unitType = u.type;
            var tail = after.substring(u.unit.length).replace(/^\s+/, "");
            res.suffix = tail;
            res.prefix = before.replace(/\s+$/, "");
        } else {
            // 2) 前缀符号单位（如 $1,234）
            var up = matchUnitAtEnd(before);
            if (up) {
                res.unit = up.unit;
                res.unitType = up.type;
                res.prefix = before.substring(0, before.length - up.unit.length);
                res.suffix = after;
            } else {
                res.prefix = before;
                res.suffix = after;
            }
        }
        return res;
    }

    function suggestedTypeOf(unitType, text, isNumericUnit) {
        if (unitType) {
            // 计时单位 s/ms 与 angle 的冲突等，按优先：timecode 文本含冒号→timer
            if (/^\d{1,2}:\d{2}(:\d{2})?/.test(text)) { return "timer"; }
            if (unitType === "timer") { return "timer"; }
            return unitType;
        }
        return "generic";
    }

    function detectParse(text) {
        var out = {
            isNumeric: false, value: null, unit: "", suggestedType: "plainText",
            prefix: "", suffix: ""
        };
        if (text === null || text === undefined) { return out; }
        var raw = String(text);
        // 忽略单位标签中的细/窄空格（用于 m ² / m ³ 等显示）
        raw = raw.replace(/[\u2009\u200A\u202F]/g, "");

        // 度分秒形态：31°13'12"N / 121°30'00"E
        var dmsM = raw.match(/([\d.]+)\s*°\s*([\d.]+)\s*'\s*([\d.]+)\s*"\s*([NSEWnsew]?)/);
        if (dmsM) {
            var deg = Number(dmsM[1]);
            var minu = Number(dmsM[2]);
            var secd = Number(dmsM[3]);
            var hemi = dmsM[4] ? dmsM[4].toUpperCase() : "";
            var dec = deg + minu / 60 + secd / 3600;
            if (hemi === "S" || hemi === "W") { dec = -dec; }
            out.isNumeric = true;
            out.value = dec;
            out.unit = "dms";
            out.suggestedType = "coordinate";
            out.hemisphere = (hemi === "E" || hemi === "W") ? "lon" : "lat";
            return out;
        }

        // 十进制度 + 方向：31.22°N / 121.5°W（区别于角度：带方向才视为经纬度）
        var degM = raw.match(/^\s*([-+]?\d+(?:\.\d+)?)\s*°\s*([NSEWnsew])\s*$/);
        if (degM) {
            var dval = Number(degM[1]);
            var dhemi = degM[2].toUpperCase();
            if (dhemi === "S" || dhemi === "W") { dval = -Math.abs(dval); } else { dval = Math.abs(dval); }
            out.isNumeric = true;
            out.value = dval;
            out.unit = "deg";
            out.suggestedType = "coordinate";
            out.hemisphere = (dhemi === "E" || dhemi === "W") ? "lon" : "lat";
            return out;
        }

        // 时间码形态 HH:MM:SS
        var tc = raw.match(/(\d{1,2}):(\d{2})(?::(\d{2}))?(?:\.(\d{1,3}))?/);
        if (tc) {
            var hh = Number(tc[1]);
            var mm = Number(tc[2]);
            var ss = tc[3] !== undefined ? Number(tc[3]) : 0;
            var ms = tc[4] !== undefined ? Number(("0." + tc[4])) : 0;
            out.isNumeric = true;
            out.value = hh * 3600 + mm * 60 + ss + ms;
            out.unit = "timecode";
            out.suggestedType = "timer";
            return out;
        }

        var p = parseNumberText(raw);
        if (p.isNumeric) {
            out.isNumeric = true;
            var val = p.value;
            // 负号可能在全角前缀之前（如 -约$13.89），不是紧贴数字：按文本开头的符号补回负值
            var lm = raw.match(/^\s*([+\-])/);
            if (lm) { var av = Math.abs(Number(val)); val = (lm[1] === "-") ? -av : av; }
            out.value = val;
            out.forceSign = !!(lm && lm[1] === "+");
            out.unit = p.unit;
            out.prefix = p.prefix;
            out.suffix = p.suffix;
            out.suggestedType = suggestedTypeOf(p.unitType, raw, true);
            return out;
        }

        // 人民币大写：不可数值化，但建议 currency
        if (detectRmbUppercase(raw)) {
            out.isNumeric = false;
            out.value = null;
            out.unit = "CNY";
            out.suggestedType = "currency";
            out.formatHint = "rmbUppercase";
            return out;
        }
        return out;
    }

    /* ---------------- 内置注册表（§6） ---------------- */
    var REGISTRY = {
        plainText: {
            id: "plainText", label: "纯文本", allowNegative: false, forceSign: false,
            decimals: 0, thousands: false, baseUnit: "", format: "text", behavior: "manual",
            prefix: "", suffix: "", range: null, units: []
        },
        temperature: {
            id: "temperature", label: "温度", allowNegative: true, forceSign: false,
            decimals: 1, thousands: false, baseUnit: "C", format: "number", behavior: "smooth",
            prefix: "", suffix: "", range: null,
            units: [
                { id: "C", label: "°C", factor: 1, offset: 0, place: "suffix", space: true },
                { id: "F", label: "°F", factor: 1.8, offset: 32, place: "suffix", space: true },
                { id: "K", label: "K", factor: 1, offset: 273.15, place: "suffix", space: true }
            ]
        },
        currency: {
            id: "currency", label: "货币", allowNegative: true, forceSign: false,
            decimals: 2, thousands: true, baseUnit: "CNY", format: "number", behavior: "smooth",
            prefix: "", suffix: "", rate: null,
            units: [
                { id: "CNY", label: "¥", factor: 1, offset: 0, place: "prefix", space: false },
                { id: "USD", label: "$", factor: 0.1388888888888889, offset: 0, place: "prefix", space: false },
                { id: "EUR", label: "€", factor: 0.1282051282051282, offset: 0, place: "prefix", space: false },
                { id: "GBP", label: "£", factor: 0.1098901098901099, offset: 0, place: "prefix", space: false },
                { id: "HKD", label: "HK$", factor: 1.08, offset: 0, place: "prefix", space: false },
                { id: "JPY", label: "JP¥", factor: 20.8333333333, offset: 0, place: "prefix", space: false }
            ]
        },
        length: {
            id: "length", label: "长度", allowNegative: true, forceSign: false,
            decimals: 2, thousands: true, baseUnit: "m", format: "number", behavior: "smooth",
            prefix: "", suffix: "", range: { min: 0, max: null, clamp: true },
            units: [
                { id: "m", label: "m", factor: 1, offset: 0, place: "suffix", space: true },
                { id: "mm", label: "mm", factor: 1000, offset: 0, place: "suffix", space: true },
                { id: "cm", label: "cm", factor: 100, offset: 0, place: "suffix", space: true },
                { id: "km", label: "km", factor: 0.001, offset: 0, place: "suffix", space: true },
                { id: "µm", label: "µm", factor: 1000000, offset: 0, place: "suffix", space: true },
                { id: "in", label: "in", factor: 39.37007874015748, offset: 0, place: "suffix", space: true },
                { id: "ft", label: "ft", factor: 3.280839895013123, offset: 0, place: "suffix", space: true },
                { id: "yd", label: "yd", factor: 1.093613298337708, offset: 0, place: "suffix", space: true },
                { id: "mi", label: "mi", factor: 0.0006213711922373, offset: 0, place: "suffix", space: true },
                { id: "nmi", label: "nmi", factor: 0.0005399568034557, offset: 0, place: "suffix", space: true },
                { id: "里", label: "里", factor: 0.002, offset: 0, place: "suffix", space: true },
                { id: "尺", label: "尺", factor: 3, offset: 0, place: "suffix", space: true },
                { id: "寸", label: "寸", factor: 30, offset: 0, place: "suffix", space: true },
                { id: "AU", label: "AU", factor: 0.000000000006684587, offset: 0, place: "suffix", space: true },
                { id: "ly", label: "ly", factor: 0.0000000000000001057, offset: 0, place: "suffix", space: true },
                { id: "pc", label: "pc", factor: 0.0000000000000000324, offset: 0, place: "suffix", space: true }
            ]
        },
        heartRate: {
            id: "heartRate", label: "心率", allowNegative: true, forceSign: false,
            decimals: 0, thousands: false, baseUnit: "bpm", format: "number", behavior: "wave",
            prefix: "", suffix: "", range: { min: 0, max: 300, clamp: true },
            thresholds: [
                { level: "warn", op: "lt", value: 60 },
                { level: "warn", op: "gt", value: 100 }
            ],
            units: [
                { id: "bpm", label: "bpm", factor: 1, offset: 0, place: "suffix", space: true }
            ]
        },
        oxygen: {
            id: "oxygen", label: "含氧量", allowNegative: true, forceSign: false,
            decimals: 0, thousands: false, baseUnit: "pct", format: "number", behavior: "smooth",
            prefix: "", suffix: "", range: { min: 0, max: 100, clamp: true },
            thresholds: [ { level: "warn", op: "lt", value: 90 } ],
            units: [
                { id: "pct", label: "%", factor: 1, offset: 0, place: "suffix", space: false }
            ]
        },
        generic: {
            id: "generic", label: "通用数字", allowNegative: true, forceSign: false,
            decimals: 2, thousands: false, baseUnit: "", format: "number", behavior: "smooth",
            prefix: "", suffix: "", range: null,
            units: [
                { id: "none", label: "", factor: 1, offset: 0, place: "suffix", space: false }
            ]
        },
        timer: {
            id: "timer", label: "计时/秒表", allowNegative: false, forceSign: false,
            decimals: 0, thousands: false, baseUnit: "s", format: "timecode", behavior: "linear",
            prefix: "", suffix: "", timerMode: "format", timerMs: false, range: null,
            units: [
                { id: "s", label: "", factor: 1, offset: 0, place: "suffix", space: false }
            ]
        },
        pressure: {
            id: "pressure", label: "大气压", allowNegative: true, forceSign: false,
            decimals: 1, thousands: true, baseUnit: "Pa", format: "number", behavior: "step",
            prefix: "", suffix: "", range: null,
            units: [
                { id: "Pa", label: "Pa", factor: 1, offset: 0, place: "suffix", space: true },
                { id: "hPa", label: "hPa", factor: 0.01, offset: 0, place: "suffix", space: true },
                { id: "kPa", label: "kPa", factor: 0.001, offset: 0, place: "suffix", space: true },
                { id: "bar", label: "bar", factor: 0.00001, offset: 0, place: "suffix", space: true },
                { id: "atm", label: "atm", factor: 1 / 101325, offset: 0, place: "suffix", space: true },
                { id: "mmHg", label: "mmHg", factor: 0.007500615758456563, offset: 0, place: "suffix", space: true },
                { id: "psi", label: "psi", factor: 0.0001450377377302092, offset: 0, place: "suffix", space: true },
                { id: "MPa", label: "MPa", factor: 0.000001, offset: 0, place: "suffix", space: true },
                { id: "Torr", label: "Torr", factor: 0.007500616827041698, offset: 0, place: "suffix", space: true },
                { id: "kgf/cm²", label: "kgf/cm²", factor: 0.0000101971621298, offset: 0, place: "suffix", space: true },
                { id: "inHg", label: "inHg", factor: 0.0002952998307145, offset: 0, place: "suffix", space: true }
            ]
        },
        frequency: {
            id: "frequency", label: "频率", allowNegative: true, forceSign: false,
            decimals: 2, thousands: true, baseUnit: "Hz", format: "number", behavior: "wave",
            prefix: "", suffix: "", range: null,
            units: [
                { id: "Hz", label: "Hz", factor: 1, offset: 0, place: "suffix", space: true },
                { id: "kHz", label: "kHz", factor: 0.001, offset: 0, place: "suffix", space: true },
                { id: "MHz", label: "MHz", factor: 0.000001, offset: 0, place: "suffix", space: true },
                { id: "GHz", label: "GHz", factor: 0.000000001, offset: 0, place: "suffix", space: true },
                { id: "rpm", label: "rpm", factor: 60, offset: 0, place: "suffix", space: true }
            ]
        },
        voltage: {
            id: "voltage", label: "电压", allowNegative: true, forceSign: false,
            decimals: 2, thousands: true, baseUnit: "V", format: "number", behavior: "smooth",
            prefix: "", suffix: "", range: null,
            units: [
                { id: "V", label: "V", factor: 1, offset: 0, place: "suffix", space: true },
                { id: "mV", label: "mV", factor: 1000, offset: 0, place: "suffix", space: true },
                { id: "kV", label: "kV", factor: 0.001, offset: 0, place: "suffix", space: true }
            ]
        },
        weight: {
            id: "weight", label: "重量", allowNegative: true, forceSign: false,
            decimals: 2, thousands: true, baseUnit: "kg", format: "number", behavior: "smooth",
            prefix: "", suffix: "", range: null,
            units: [
                { id: "kg", label: "kg", factor: 1, offset: 0, place: "suffix", space: true },
                { id: "g", label: "g", factor: 1000, offset: 0, place: "suffix", space: true },
                { id: "mg", label: "mg", factor: 1000000, offset: 0, place: "suffix", space: true },
                { id: "t", label: "t", factor: 0.001, offset: 0, place: "suffix", space: true },
                { id: "lb", label: "lb", factor: 2.2046226218487757, offset: 0, place: "suffix", space: true },
                { id: "oz", label: "oz", factor: 35.27396194958041, offset: 0, place: "suffix", space: true },
                { id: "斤", label: "斤", factor: 2, offset: 0, place: "suffix", space: true },
                { id: "两", label: "两", factor: 20, offset: 0, place: "suffix", space: true }
            ]
        },
        speed: {
            id: "speed", label: "速度", allowNegative: true, forceSign: false,
            decimals: 2, thousands: true, baseUnit: "m/s", format: "number", behavior: "smooth",
            prefix: "", suffix: "", range: null,
            units: [
                { id: "m/s", label: "m/s", factor: 1, offset: 0, place: "suffix", space: true },
                { id: "km/s", label: "km/s", factor: 0.001, offset: 0, place: "suffix", space: true },
                { id: "km/h", label: "km/h", factor: 3.6, offset: 0, place: "suffix", space: true },
                { id: "mph", label: "mph", factor: 2.2369362920544025, offset: 0, place: "suffix", space: true },
                { id: "kn", label: "kn", factor: 1.9438444924406046, offset: 0, place: "suffix", space: true },
                { id: "ft/s", label: "ft/s", factor: 3.280839895013123, offset: 0, place: "suffix", space: true },
                { id: "Mach", label: "Mach", factor: 0.002938583895093, offset: 0, place: "suffix", space: true },
                { id: "c", label: "c", factor: 0.000000003335640952, offset: 0, place: "suffix", space: true }
            ]
        },
        area: {
            id: "area", label: "面积", allowNegative: true, forceSign: false,
            decimals: 2, thousands: true, baseUnit: "m²", format: "number", behavior: "smooth",
            prefix: "", suffix: "", range: null,
            units: [
                { id: "m²", label: "m²", factor: 1, offset: 0, place: "suffix", space: true },
                { id: "km²", label: "km²", factor: 0.000001, offset: 0, place: "suffix", space: true },
                { id: "cm²", label: "cm²", factor: 10000, offset: 0, place: "suffix", space: true },
                { id: "ha", label: "ha", factor: 0.0001, offset: 0, place: "suffix", space: true },
                { id: "ac", label: "ac", factor: 0.00024710538146717, offset: 0, place: "suffix", space: true },
                { id: "亩", label: "亩", factor: 0.0015, offset: 0, place: "suffix", space: true }
            ]
        },
        volume: {
            id: "volume", label: "容积", allowNegative: true, forceSign: false,
            decimals: 2, thousands: true, baseUnit: "L", format: "number", behavior: "smooth",
            prefix: "", suffix: "", range: null,
            units: [
                { id: "L", label: "L", factor: 1, offset: 0, place: "suffix", space: true },
                { id: "mL", label: "mL", factor: 1000, offset: 0, place: "suffix", space: true },
                { id: "m³", label: "m³", factor: 0.001, offset: 0, place: "suffix", space: true },
                { id: "gal", label: "gal", selectLabel: "gal（美制）", factor: 0.26417205235814845, offset: 0, place: "suffix", space: true }
            ]
        },
        coordinate: {
            id: "coordinate", label: "经纬度", allowNegative: true, forceSign: false,
            decimals: 6, thousands: false, baseUnit: "deg", format: "dms", behavior: "smooth",
            prefix: "", suffix: "", range: null, hemisphere: "lat",
            units: [
                { id: "dms", label: "DMS", selectLabel: "度分秒（DMS）", factor: 1, offset: 0, place: "suffix", space: false },
                { id: "deg", label: "°", selectLabel: "十进制度（含方向）", factor: 1, offset: 0, place: "suffix", space: false }
            ]
        },
        angle: {
            id: "angle", label: "角度", allowNegative: true, forceSign: false,
            decimals: 1, thousands: false, baseUnit: "deg", format: "number", behavior: "smooth",
            prefix: "", suffix: "", range: null,
            units: [
                { id: "deg", label: "°", factor: 1, offset: 0, place: "suffix", space: false },
                { id: "rad", label: "rad", factor: Math.PI / 180, offset: 0, place: "suffix", space: true },
                { id: "grad", label: "grad", factor: 10 / 9, offset: 0, place: "suffix", space: true },
                { id: "arcmin", label: "′", factor: 60, offset: 0, place: "suffix", space: false },
                { id: "arcsec", label: "″", factor: 3600, offset: 0, place: "suffix", space: false },
                { id: "turn", label: "turn", factor: 1 / 360, offset: 0, place: "suffix", space: true },
                { id: "mil", label: "mil", factor: 17.77777777777778, offset: 0, place: "suffix", space: true }
            ]
        },
        percent: {
            id: "percent", label: "百分比", allowNegative: true, forceSign: false,
            decimals: 0, thousands: false, baseUnit: "pct", format: "number", behavior: "smooth",
            prefix: "", suffix: "", range: { min: 0, max: 100, clamp: true },
            units: [
                { id: "pct", label: "%", factor: 1, offset: 0, place: "suffix", space: false },
                { id: "permil", label: "‰", factor: 10, offset: 0, place: "suffix", space: false }
            ]
        },
        power: {
            id: "power", label: "功率", allowNegative: true, forceSign: false,
            decimals: 2, thousands: true, baseUnit: "W", format: "number", behavior: "smooth",
            prefix: "", suffix: "", range: null,
            units: [
                { id: "W", label: "W", factor: 1, offset: 0, place: "suffix", space: true },
                { id: "kW", label: "kW", factor: 0.001, offset: 0, place: "suffix", space: true },
                { id: "MW", label: "MW", factor: 0.000001, offset: 0, place: "suffix", space: true },
                { id: "hp", label: "hp", factor: 0.001341022089595, offset: 0, place: "suffix", space: true },
                { id: "PS", label: "PS", factor: 0.0013596216173039043, offset: 0, place: "suffix", space: true }
            ]
        },
        energy: {
            id: "energy", label: "能量", allowNegative: true, forceSign: false,
            decimals: 2, thousands: true, baseUnit: "J", format: "number", behavior: "smooth",
            prefix: "", suffix: "", range: null,
            units: [
                { id: "J", label: "J", factor: 1, offset: 0, place: "suffix", space: true },
                { id: "kJ", label: "kJ", factor: 0.001, offset: 0, place: "suffix", space: true },
                { id: "MJ", label: "MJ", factor: 0.000001, offset: 0, place: "suffix", space: true },
                { id: "cal", label: "cal", factor: 0.2390057361377, offset: 0, place: "suffix", space: true },
                { id: "kcal", label: "kcal", factor: 0.0002390057361377, offset: 0, place: "suffix", space: true },
                { id: "Wh", label: "Wh", factor: 0.0002777777777778, offset: 0, place: "suffix", space: true },
                { id: "kWh", label: "kWh", factor: 0.0000002777777778, offset: 0, place: "suffix", space: true },
                { id: "eV", label: "eV", factor: 6241509074460762000, offset: 0, place: "suffix", space: true },
                { id: "BTU", label: "BTU", factor: 0.0009478171203133, offset: 0, place: "suffix", space: true },
                { id: "tTNT", label: "tTNT", factor: 0.0000000002390057361, offset: 0, place: "suffix", space: true }
            ]
        },
        force: {
            id: "force", label: "力", allowNegative: true, forceSign: false,
            decimals: 2, thousands: true, baseUnit: "N", format: "number", behavior: "smooth",
            prefix: "", suffix: "", range: null,
            units: [
                { id: "N", label: "N", factor: 1, offset: 0, place: "suffix", space: true },
                { id: "kN", label: "kN", factor: 0.001, offset: 0, place: "suffix", space: true },
                { id: "MN", label: "MN", factor: 0.000001, offset: 0, place: "suffix", space: true },
                { id: "kgf", label: "kgf", factor: 0.1019716212978, offset: 0, place: "suffix", space: true },
                { id: "lbf", label: "lbf", factor: 0.2248089430997, offset: 0, place: "suffix", space: true },
                { id: "dyn", label: "dyn", factor: 100000, offset: 0, place: "suffix", space: true },
                { id: "gf", label: "gf", factor: 101.9716212978, offset: 0, place: "suffix", space: true }
            ]
        },
        torque: {
            id: "torque", label: "扭矩", allowNegative: true, forceSign: false,
            decimals: 2, thousands: true, baseUnit: "N·m", format: "number", behavior: "smooth",
            prefix: "", suffix: "", range: null,
            units: [
                { id: "N·m", label: "N·m", factor: 1, offset: 0, place: "suffix", space: true },
                { id: "kgf·m", label: "kgf·m", factor: 0.1019716212978, offset: 0, place: "suffix", space: true },
                { id: "lbf·ft", label: "lbf·ft", factor: 0.7375621492773, offset: 0, place: "suffix", space: true },
                { id: "lbf·in", label: "lbf·in", factor: 8.8507457913272, offset: 0, place: "suffix", space: true }
            ]
        },
        acceleration: {
            id: "acceleration", label: "加速度", allowNegative: true, forceSign: false,
            decimals: 2, thousands: false, baseUnit: "m/s²", format: "number", behavior: "smooth",
            prefix: "", suffix: "", range: null,
            units: [
                { id: "m/s²", label: "m/s²", factor: 1, offset: 0, place: "suffix", space: true },
                { id: "g", label: "g₀", factor: 0.1019716212978, offset: 0, place: "suffix", space: true },
                { id: "ft/s²", label: "ft/s²", factor: 3.2808398950131, offset: 0, place: "suffix", space: true },
                { id: "Gal", label: "Gal", factor: 100, offset: 0, place: "suffix", space: true }
            ]
        },
        current: {
            id: "current", label: "电流", allowNegative: true, forceSign: false,
            decimals: 2, thousands: true, baseUnit: "A", format: "number", behavior: "smooth",
            prefix: "", suffix: "", range: null,
            units: [
                { id: "A", label: "A", factor: 1, offset: 0, place: "suffix", space: true },
                { id: "mA", label: "mA", factor: 1000, offset: 0, place: "suffix", space: true },
                { id: "µA", label: "µA", factor: 1000000, offset: 0, place: "suffix", space: true },
                { id: "kA", label: "kA", factor: 0.001, offset: 0, place: "suffix", space: true },
                { id: "MA", label: "MA", factor: 0.000001, offset: 0, place: "suffix", space: true }
            ]
        },
        resistance: {
            id: "resistance", label: "电阻", allowNegative: true, forceSign: false,
            decimals: 2, thousands: true, baseUnit: "Ω", format: "number", behavior: "smooth",
            prefix: "", suffix: "", range: null,
            units: [
                { id: "Ω", label: "Ω", factor: 1, offset: 0, place: "suffix", space: true },
                { id: "mΩ", label: "mΩ", factor: 1000, offset: 0, place: "suffix", space: true },
                { id: "kΩ", label: "kΩ", factor: 0.001, offset: 0, place: "suffix", space: true },
                { id: "MΩ", label: "MΩ", factor: 0.000001, offset: 0, place: "suffix", space: true }
            ]
        },
        capacitance: {
            id: "capacitance", label: "电容", allowNegative: true, forceSign: false,
            decimals: 2, thousands: true, baseUnit: "F", format: "number", behavior: "smooth",
            prefix: "", suffix: "", range: null,
            units: [
                { id: "F", label: "F", factor: 1, offset: 0, place: "suffix", space: true },
                { id: "mF", label: "mF", factor: 1000, offset: 0, place: "suffix", space: true },
                { id: "µF", label: "µF", factor: 1000000, offset: 0, place: "suffix", space: true },
                { id: "nF", label: "nF", factor: 1000000000, offset: 0, place: "suffix", space: true },
                { id: "pF", label: "pF", factor: 1000000000000, offset: 0, place: "suffix", space: true }
            ]
        },
        charge: {
            id: "charge", label: "电荷量", allowNegative: true, forceSign: false,
            decimals: 2, thousands: true, baseUnit: "C", format: "number", behavior: "smooth",
            prefix: "", suffix: "", range: null,
            units: [
                { id: "C", label: "C", factor: 1, offset: 0, place: "suffix", space: true },
                { id: "mC", label: "mC", factor: 1000, offset: 0, place: "suffix", space: true },
                { id: "µC", label: "µC", factor: 1000000, offset: 0, place: "suffix", space: true },
                { id: "Ah", label: "Ah", factor: 0.0002777777777778, offset: 0, place: "suffix", space: true },
                { id: "mAh", label: "mAh", factor: 0.2777777777778, offset: 0, place: "suffix", space: true },
                { id: "µAh", label: "µAh", factor: 277.7777777778, offset: 0, place: "suffix", space: true }
            ]
        },
        flow: {
            id: "flow", label: "流量", allowNegative: true, forceSign: false,
            decimals: 2, thousands: true, baseUnit: "m³/s", format: "number", behavior: "smooth",
            prefix: "", suffix: "", range: null,
            units: [
                { id: "m³/s", label: "m³/s", factor: 1, offset: 0, place: "suffix", space: true },
                { id: "L/s", label: "L/s", factor: 1000, offset: 0, place: "suffix", space: true },
                { id: "L/min", label: "L/min", factor: 60000, offset: 0, place: "suffix", space: true },
                { id: "m³/h", label: "m³/h", factor: 3600, offset: 0, place: "suffix", space: true },
                { id: "GPM", label: "GPM", selectLabel: "GPM（美制）", factor: 15850.32314149, offset: 0, place: "suffix", space: true },
                { id: "CFM", label: "CFM", factor: 2118.88000329, offset: 0, place: "suffix", space: true }
            ]
        },
        density: {
            id: "density", label: "密度", allowNegative: true, forceSign: false,
            decimals: 3, thousands: true, baseUnit: "kg/m³", format: "number", behavior: "smooth",
            prefix: "", suffix: "", range: null,
            units: [
                { id: "kg/m³", label: "kg/m³", factor: 1, offset: 0, place: "suffix", space: true },
                { id: "g/cm³", label: "g/cm³", factor: 0.001, offset: 0, place: "suffix", space: true },
                { id: "g/L", label: "g/L", factor: 1, offset: 0, place: "suffix", space: true },
                { id: "kg/L", label: "kg/L", factor: 0.001, offset: 0, place: "suffix", space: true },
                { id: "lb/ft³", label: "lb/ft³", factor: 0.0624279605761, offset: 0, place: "suffix", space: true }
            ]
        },
        concentration: {
            id: "concentration", label: "浓度", allowNegative: true, forceSign: false,
            decimals: 3, thousands: true, baseUnit: "g/L", format: "number", behavior: "smooth",
            prefix: "", suffix: "", range: null,
            units: [
                { id: "g/L", label: "g/L", factor: 1, offset: 0, place: "suffix", space: true },
                { id: "mg/L", label: "mg/L", factor: 1000, offset: 0, place: "suffix", space: true },
                { id: "µg/L", label: "µg/L", factor: 1000000, offset: 0, place: "suffix", space: true },
                { id: "ppm", label: "ppm", factor: 1000, offset: 0, place: "suffix", space: true },
                { id: "ppb", label: "ppb", factor: 1000000, offset: 0, place: "suffix", space: true }
            ]
        },
        data: {
            id: "data", label: "数据量", allowNegative: true, forceSign: false,
            decimals: 2, thousands: true, baseUnit: "B", format: "number", behavior: "smooth",
            prefix: "", suffix: "", range: null,
            units: [
                { id: "B", label: "B", factor: 1, offset: 0, place: "suffix", space: true },
                { id: "KB", label: "kB", factor: 0.001, offset: 0, place: "suffix", space: true },
                { id: "MB", label: "MB", factor: 0.000001, offset: 0, place: "suffix", space: true },
                { id: "GB", label: "GB", factor: 0.000000001, offset: 0, place: "suffix", space: true },
                { id: "TB", label: "TB", factor: 0.000000000001, offset: 0, place: "suffix", space: true },
                { id: "bit", label: "bit", factor: 8, offset: 0, place: "suffix", space: true },
                { id: "kbit", label: "kbit", factor: 0.008, offset: 0, place: "suffix", space: true },
                { id: "Mbit", label: "Mbit", factor: 0.000008, offset: 0, place: "suffix", space: true },
                { id: "Gbit", label: "Gbit", factor: 0.000000008, offset: 0, place: "suffix", space: true }
            ]
        },
        illuminance: {
            id: "illuminance", label: "照度", allowNegative: true, forceSign: false,
            decimals: 2, thousands: true, baseUnit: "lx", format: "number", behavior: "smooth",
            prefix: "", suffix: "", range: null,
            units: [
                { id: "lx", label: "lx", factor: 1, offset: 0, place: "suffix", space: true },
                { id: "klx", label: "klx", factor: 0.001, offset: 0, place: "suffix", space: true },
                { id: "fc", label: "fc", factor: 0.09290304, offset: 0, place: "suffix", space: true }
            ]
        },
        radiation: {
            id: "radiation", label: "辐射剂量", allowNegative: true, forceSign: false,
            decimals: 3, thousands: true, baseUnit: "Sv", format: "number", behavior: "smooth",
            prefix: "", suffix: "", range: null,
            units: [
                { id: "Sv", label: "Sv", factor: 1, offset: 0, place: "suffix", space: true },
                { id: "mSv", label: "mSv", factor: 1000, offset: 0, place: "suffix", space: true },
                { id: "µSv", label: "µSv", factor: 1000000, offset: 0, place: "suffix", space: true },
                { id: "rem", label: "rem", factor: 100, offset: 0, place: "suffix", space: true },
                { id: "mrem", label: "mrem", factor: 100000, offset: 0, place: "suffix", space: true }
            ]
        },
        radioactivity: {
            id: "radioactivity", label: "放射性活度", allowNegative: true, forceSign: false,
            decimals: 2, thousands: true, baseUnit: "Bq", format: "number", behavior: "smooth",
            prefix: "", suffix: "", range: null,
            units: [
                { id: "Bq", label: "Bq", factor: 1, offset: 0, place: "suffix", space: true },
                { id: "kBq", label: "kBq", factor: 0.001, offset: 0, place: "suffix", space: true },
                { id: "MBq", label: "MBq", factor: 0.000001, offset: 0, place: "suffix", space: true },
                { id: "GBq", label: "GBq", factor: 0.000000001, offset: 0, place: "suffix", space: true },
                { id: "Ci", label: "Ci", factor: 2.7027027027027027e-11, offset: 0, place: "suffix", space: true }
            ]
        }
    };

    /* setRegistry(types) —— 运行期替换注册表（授权后注入全量规格用）
       types 形如 { temperature: {...}, length: {...} }，与内置 REGISTRY 同构。 */
    function setRegistry(types) {
        if (!types || typeof types !== "object") { return false; }
        var k;
        for (k in REGISTRY) {
            if (REGISTRY.hasOwnProperty(k)) { delete REGISTRY[k]; }
        }
        for (k in types) {
            if (types.hasOwnProperty(k)) { REGISTRY[k] = types[k]; }
        }
        return true;
    }

    function getType(id) { return REGISTRY[id] || null; }

    function listTypes() {
        var arr = [];
        for (var k in REGISTRY) {
            if (REGISTRY.hasOwnProperty(k)) { arr.push(REGISTRY[k]); }
        }
        return arr;
    }

    /* ---------------- 表达式内联包（供 AE Source Text 表达式调用） ----------------
       把「只依赖 spec 参数」的纯函数源码拼成一个自包含 IIFE，表达式里：
         var FUI_FMT = <bundle>; ... FUI_FMT.formatValue(v, spec)
       避免表达式引擎访问不到脚本侧对象的问题。 */
    function expressionBundle() {
        var fns = [numOr, groupThousands, repeatZero, pad2, pad3, trimNum, padSpaces, nSpaces,
            fmtNumber, resolveUnit, convertDisplay, displayUnitLabel,
            rmbUppercase, timecode, twoDigitSec, dms, evaluateThresholds, formatValue];
        var src = "(function(){\n";
        for (var i = 0; i < fns.length; i++) {
            src += fns[i].toString() + "\n";
        }
        src += "return { formatValue: formatValue, rmbUppercase: rmbUppercase, " +
            "timecode: timecode, dms: dms, evaluateThresholds: evaluateThresholds };\n})()";
        return src;
    }

    return {
        version: "0.1.1",
        REGISTRY: REGISTRY,
        setRegistry: setRegistry,
        getType: getType,
        listTypes: listTypes,
        parseNumberText: parseNumberText,
        convert: convert,
        formatValue: formatValue,
        rmbUppercase: rmbUppercase,
        timecode: timecode,
        dms: dms,
        detectParse: detectParse,
        evaluateThresholds: evaluateThresholds,
        expressionBundle: expressionBundle
    };
});


